"""MapleLeaf 5.7 — Ezzzzzekki backbone + aggressive preemption.

Same converged-meta backbone as 5.5 (Ezz single route, both seats). The one
change vs 5.5 is a more aggressive premium-sell preempt overlay — fire vs more
opponents and earlier, to win the premium price race in the clone-heavy field:
  clone-dist 6/4 -> 12/10,  max_batch 30 -> 45,  min_future 4 -> 2,  start 120 -> 72.

Measured (parallel mirror, identical route, overlays differ):
  5.7 vs v27 (public clone): 27/48 wins (56%)  vs 5.5's 47%.
  5.7 vs 5.5 direct: 10-4 in decisive games (18 ties).
Modest, win/loss-relevant, no magnitude downside. Do NOT throttle premium
(that lost -8,465); TT sells continuously from day 6 and so does this.
"""
import base64
import copy
import json
import math
import zlib


_ACTIONS_P0 = json.loads(zlib.decompress(base64.b85decode(
    'c-rk<U2j}jZu~EL?gy(SYwWyf?A{$?HI^aEX>1H(Fu-mQAlN)i@)qR3N4C^om&Ia{Jhvr#{WLvt_r2%)ki}y0^Z%aw`|p4J<L`f*{LAN)50@W5p4=@?{^R%m`rCis|Ka}QKYst?KmYze_n$wX{QT*!zkRs5e*5Xo?aAU~{mbg|{=cW^cZ<&_zr4Fyodh4g{QUC$yI(J_?tlH}dVT*}^XHGhtX3aR7U!FP__$iVz5nyCtE=nxCySSpKR-6%<=x%?Ee^Wz?#*95eb{@;wnLv!)~k=VUz@Z2@Yw0SpKV)l*#D2KtE=5xU*k5O;WnPSZQOogzm@N=Z*G72+Nj+p+s?<I9=3Dxp2u#g&;I$-yQ{aq-T&|Hr!Uh+9z6M`-ukP{H>>R+vo~zM`DGRlo`3%j?{Bw5?!4zu`{U1EbNI!BwQ_m8y78X><}w(dhcDo9+4NxZ(!J+Ceu<6CWS64H?V4VgTKj_C<G{AjC)7T7`!s(*<cYM8|9JiBalpZNgcInG^KRkU;i$~tUhDjEXwBdD)U)HznLlMf8uKTOOJyE6zXikb(1F_HcI$2Wr`q%E@D5oGtoyCiuzASpa^NCRMq}_Ac=(Wb+@YcHVDg05LAcW1Twh(S-rWB7r`65vyQ_Eq_O+SzK1tpFg=-5ngFIk!%cU9$-WoPE7@cIZH+y&F1XVVF{lNI~lOI2MMn8eh)80;baObd}Xxz+;od2}7LgJIhH~+1lwWu9s#vfAr>bvAwGwDa?cGz8tm4<@zAGTd-p?{a)HpV|U!xSF!8~b4JFoD6xqf}|&)ZR}mf<3RP@M=52g(mC<*t9?%UodUX0EZ1^o@L=EHA7T*#&(44Z`Bb355)sizAgS)ep|ij4(_}uV0ifFkGD6M>z`LQH-G(tG1e}_$%o;W;;8HKX)em{mAP?G_hzcw6Uh}@0HCsbrRw*FZJa&U@QAeCs_FIHx+j3&M=#<L9WbzGc7(trBCIp^B^3*4w>(PE+cnI^zXzF_p6Q_(A=X})V1lj7)*c)#099<{1a#|MeLo&D<{>@1pylzBGckys{<!<g?sBj3NsqADX5&8>T{Op${<3;6Z~nD#fq}s!*F+g~NSHX_p&*b}agwJlw$z-*172IsPcaF)%e`%#)bZW7u?KFW-}x9`%XT2{`Sw;;CPeqhZ8%h(B`FkE>GSu0b#G4YpS~KyH8<a(K<VE9d5`W?_mrmB|1x77G$03LBg8IP?4HJ!Qs3ZsY6}55m`5-d2szBR8{$*jBZQ3|Wq&2Aqa7c@9vdJUXSEO3R@mK_+bikeLvIsJA3FlpaZr&XAl(U9oW%q>uDFV#b*@F$&H9)saLJJ$(hAcU;?a?2;3+|cvplGv80+9Q&&xR2cSw$57ch4t^e25BVhD(mzyA{92L=H#Tw~P01J83f0Ma3ypx8#;4A3J;M;Q8bW!#w|ldwJPWAH)<AN2O-`a`e|h<&y5B(JZp9#3j;f^U;Z?k}FVC$Vj3(FXKt;)X6q2B9}k%p4rLP0GE{?Q^z^O@A_RT6T{$u-L>XNbs^fZw4frBo?T0Roa+Q!4<%{Jz@yFguZ;;GpBUZD2Zq(fM!`lLB9U@46j5jjv_~J&d4r(turdSai0YYQOO~m4t|sTG%L`9-mCg_Lt3hXL?FG*H$UdGDS`RtjE>U{d*oME*YxnGBe1}9i;kfdEU&}M0v#$j_D#*tAYO|%XKXzUCK+#Dg{DScJ3|Sl2t2i~^d_q1oq+WmybrGEm1-XV8kJeIU<vrfbHe0NSjYgJi||I~Ues||5@FTOJ2Z>~_*C{toEV3AVc4j@#var%r=0s#pp;3j1c7kvgD11Y!b$qlg(<ZMy9PaWYjD4P_vgu%3U7=Ff5^s1U+)B=!M*@*7q5{@gqVT6i`fFxZuaTC#IyYf_Rf(R={7B}t1>dC%pEF&M-T&cN{RCws-^2tEp?k$a%Fb+wH>2QO0Dy{{quV}u)4*+yc>|7tGZ7aM^Z^4!!D3Dp=NP_LL7O)Xh6uqsx1oc@0eCXKGV#LL-2ZxQ76#WB+`R58>eQ`py<Kw)^kQ7lb@$hR)J~kdc(PQ1+(Z_TL(*8q0IsNADFDWx0$hbedl=bu=qr1LvAO7C6p#!h_-Ne&W4K!xOV<&Kt0?{QYbm8eD<S@b!>-2Sx?o|35-7Cgp6QnPH*T%K#1*_$V`QYAwmuFm<8v!VLY{JFYfX@4<It6yt*Yh^B7mu`u6L)tG|5dnimL}!8`b=8(nD`{!7O$;)Xx-8X_M+fYl`{9urG42CTppkc{S>6+N6`fZAy9ze=0VveqTSv!eTQ0QIFnA&FeW_*}0rO(x5hobh#FG|x;CY<@N_qg)eeS?(5eVYxJ7A7E*OZUl&ZRFY%~K|BnY#mK(dGA?B#T(qrTZr=e6I<g)IY!o&G$km9JpqYn3N%P!i4wj(dbS33(Y+M3l*oh(A7Klrn%>C8bQ-w4i_8-l>q;Z*4aM{nmsVDEBDB#SLGPVd*aprsN+>wV_Uc`u77f#G!M|2$QV$3!OLwII~y5U|*;puXK=L8Nz-E*>`UJ!v{UmC*mcQmuKHwKOO8R*@#0((ZST?2(s7P4+Zk#bjqy=>R4Tj%GyJJw>eE7oYT0M4$tDUWX|^c{rG#4h*TMv(7BHTW$sy(i$U%?k?==3P+G0Rg19-2tYjli36KSQSWGH4W^R0Ii2|^`zFpOz<|4_zz5>@MHk?G3qRxpUFs6q?}=&06!bq)xQ7g5Ti0a#$=L-&?Me0gr~DxI9rGrctlQG)GE$od9+_Hh*{%MDPFl$3WZw<)ZiTkkI3JW3AAkbZ4d^OMu>@pka&^+1|YEM1sfrjqIk_o$DOQl@U{@YlJP=tU~ad9k3irqMazDF#xC6T{rU*&n?xQb-vk52E_`vMnyWQBdby?Jay0h;?O_q{*{vMZ0%Gmco`Ze`IGTo8Bn1YW3sJkbXsso73CaovO98~>Yf>hSdcoXIpXw`9v=<7D)O0rza+c#3nbM7L#xj?Ho(w>F&Hi!&KG0L*dk=Jk5&4(L1oSkBZzT98@|7X@MxhZcPxQRON#)m44!3DSX{ad~FfH4%nK`XtDky*s7$$&juyUUWjy3~#VmQ8}WPvICiZXU5kQm*0*B#W|Iyi9Sp8=bn^6O)*(Q?8MTeo&@bITU(HL$LV0<0ltSeoKRuu)r@t}r9bOdL1ziB3m_0?lSO-bW(V5pQ?fu-&gWsd_e#fKu|wy;U2b5Y@`<21bnO>HI{ffT!?+*I7#|2*ppO1#fYPf+{tP3%?dvVHA~4#8=!Zsm0{%e9mRa^@xZ~1ImHsnIM)xUb%Yb_IiRv_k_)=WKSPqXgbQ#FTOF~n6h3{T9TO355jy%Dw6xg_P6^d<<k9^Q{8udb*IQ&5{f<dH|#LD6qZq$0!h}aK(0A@`hY^beJXDsO(Y1#Y1RM_l8<2(D{D955kX6B`@6%9s6~+Aj;m%bd)atpk25Wr3I_-hc_sOkc>IXuxK}|V!Sdzi|2ScoHDM{x5wl-Uh^Bz(B_S5-LxgD;nG(1Dx?9r+3&}lXRb)!ck#&c;S-^ebj`>*WA+jql<u5C4S}R#&y;2VP5@oFwp{-=jJRU$bj4L{uhgOJtO(={cPM=0XWyJS$Cf7HVv<s!Ar-o>0Hba?SiR|P_Ej}eCsi&arC6%~Suk4vd3SBNaTO>3y2GL_y#L{L(q?(&>Vi%kT8Lk4WeO>ga{YHdI?`QkN^>qZ#?-~yI^8A}iI(gzm`n4nTkxr=ZDI%$#jvs062@fAP@<zaj(c$85*iEg_(O6|E&>(3mG2yKWI1h79;B_<WGGnr;tb>h3Mq*n7*~2}3B;?F6f@lqM5VNp(SkXEs72A|KI|=q{CfEvE;q?WsO8cG0Db178(OF!JvgR^<=mH^}f0_kQP-9cqBDJcSExqsZy}D~<@KZRPkQ(MotGDKe^#li3aAOH<wG^-+s%Kt^kpE@y1Szi^o1kyq&!$=!FDI+GPeu~=(5*UqM$VL$xIe(F0#0@#$=;7;jwu1;J|37rL3UsQNEgbwtU=gFW^g@K)fd}nM(^smU1$BWz{TA6b(~0DBV}?$=H$PYcE*0<c@(5vWF!5FK~gpdOYT%`>to2I*_{!)WJE0@NXpdOjEcs1@V*~`0C7iM4>sf8Ax7UyXE@Ga$MY@81Wd*c1+NR@?+4^#9Ig0I41TfT4V%0=@q?-PgnJfzlk6Qq>_l@OvAd?gDV{w5Rd7RdG$jj&Sj3))QOb2-yk~zSfH+rf>gs+bA{5Iz!}GR!geWqqL@6XhMTcm&f#KS{!McKR0xylP&0EA~uI$r`?}J!tE9so-Dk&8LZX60cD<!8ogxhqEs>ZV&A&}N^t7*j0aiiz*SY=&h;7Vnwz#t|!hnJno?&7h{yyv5kF{BH)lup<f)#T2}R1AUESFjj5o5?N!91W&CR&3ggkbC3$G?M?G2`9(|#(;3T9cXAn+dmfhu?jaa$c+bRMh5j^dT=CCNael2A=pG@kyMc?aU~SQEY^0X<YBBIhZ@sg)pVd}V7tV>)QW=P0oa=4yebmQx_dBcEqfJ^sTmSvb2_OJNFD54^6n}ed=<Ou)Z$7>OvH7ET0~hi65EwR_{5%*MM$Nu95LzFdw;id%EL%df&py&V;cl%dBk?nOB7duNH&*Gx*r}rJqHZm7ly|A>YEFh=C#iEJ<6I(n~KAZp|?U$_RRg4P%|C=>ZMSWwqR34?s)3(^KY`E-gqJwoFJ14PX2R<7;E*gc)*kOrc!FC9$8L^Rq8pfS`?0Fx23&4X87&Xz$2tQVC_XQyuro3q-ymV$(W_Z@xV($gGDM{Ed)8J6MzDT*paEA2VLHN6l9>q71((oWT@3#eMhrb4wK_G>25T}Y^cc6NGW`1hh}R&B#yc+=0Xu&G5a{IQP3-`hIn&k0+e`uR&pQ`n~qbPnGjhk=C38Nvy-^6pa8Iq2NzsdIz52WqlU3Vgks1sc>tkG%6X)#KSecX?QQ{!MP#h!s2XwA<=P@+%3Ean3mO_sj1ioS3HCrROOlvatf97<J(+_T)->tY-X<6i;94m>5}}^S5z2X6B7JyDXQjF$qQ&x5R1Gg`)y*f3-INHQAYreayoBX9T@COE=vGHfTuwI_lv$fCYwh_l#ROYL5h`$A)~lxzQ3eV_0;_K=2IlL`(E#5F&D{}7)k9<jbPXr8lzJ890O8j)<|vbi<nJD9fvzdFfV$2NLXH%D6c(n$Ur+GG80~<aFe005Z29g;lPPxfD8N=3EM~|1Kp!s)Um}aBJQ~V9D2OyD{vdc~I924*fE|p15Vq6<O-M$!nQ6?3osn4P>QGga)OoTEhUTqfu;*J2@YN$$D>*`KwsdY^vc|~tG2d=tLsvv^Sc}=~h}gNJl2;r<kXjH$AZ+_GgfH6|h&(`I74gsPLps?Gaq{~s!>PIW9`fNA<Gk9rb--D5d&A7A=xReIb%#*4UX5W;G{vp5!0~XthrRoA;@*U5TI6$_4RVP<hh)+3T(F_S^C)J8Mi8l(e_09~X7%=Qf`H;t^J+jtHTWGpVU`1&%S`Vi_~(`R^8|ljiO0p&=b&XVJOxagDrhy6RzG(QQUZ#}VBiqtMZD|<C!e1trMgp$P)~)jEsV*cjiFd-ADp9l?<u|VGW(`N9%9ocXqXFG9&H2zAuF0PJ=$lbY<0}iKff#CFd@i+fxp1K)gy+|SVIUyI1do{xz#ecI6XkJR@D(}Ah{%Fzl(MgpCpv&?y8y7if~HJIacFagDU2dON6tlpcVxJ!E0ft^T{epnj*AOT>p+!Rc49W`)Yfo92I)lxtShL;z=&bJx57#1+7VmILyc;0I*1!S1UF5DaGSyDbuVl1hAgiFJ_}A==yVL&Nk(HDU88$=KBl=nBglVqUb3%B;y`=wVP2<l7x%OhEnE=1G6fA3{#J&&tXd*k&`D_SuU+^eJ!OsbQ{Sa=L6Bc>Rli_6fzB{mSC>D91dj)sR#I^ES8L?N0MHHNlPZQ1<hmMnkwc9qm|3*qB(RVi>*KUKuU+04S{w}KL4?z=vlcZ$%#zPCR*)wo!J5mMA8Otr69XvMLHo>rz)~4&A)Ee(9D~F<5ZiMAo^M4mjUxx8Y$&|&rFX1ScgSkX_!rlfTSjY-KD8*P0NThQ16_uu5`n4QYy{nVATjM1|_7g{8YefVt+E+J7J}YAeSV*;&UpY<MUP?Fg8VtrA_#GVGuH;@N)J|r>`^xUd}I$lmj!Q(guglUKaIS<_MAIOLH(!iN(AtWt}ajGEr7syE^kVAx0z^=*~QG8h5NtrL1;DWTD@jRp~{~n2h7h8JAhD#w`gT?hf$P)%AOjR=QUBet{vErbB54*H9T4l5-tzQK)lB%TQD(2B~?IbYp;jZt*y#8=$y@j@eyc>zxlm^%1qHE71i0v<r8d5d>?47;cYqd@7WgWmj1Y7KU&mRQ2^ws#xGHQR&6MoV`mDl4)ZwWHKdk?L}`ZYUOKu1xyk!6p;*e6pijtKnY<QFQT%o0(LZtBjp5<lsw;<TeO}0+)CxNZzV4#oa%`3udO!8)T6qva^h#upJ_`t1J8q|c|vRu^i9g>#U2P)u}MBD{5rG3NPDp{SYMz*f*H`{C08z_nERoXK%R+vq8T}RrrMk+=*_M_xqg5J_15`7X>d;y{T~sS&monm^Ki4&mUoG2+m=>nxo>*Z9-cxzh$u4Tyn~VTi_`jS_rv_fgD(i`L<lyY_6GuR%RUkCl^wi@9Jq&Ze@E=Vq59QMF66G#6RhMgUqz;+S_o0Gk6=4FJU5EgHwF#S%Qx|F#<adcrJWdKjTdvGa-XFA1Y|64lCJCw?J11<C8VP9x4)8Ko<a2}LCZHzNMSf>qt+C+x)Rxh{6V!MN~P54pdl+sYnnxDiqcWsS5rE)S5NYh*2P>27iI_?mbNB#;LYHn<yKdfAStCxtJ)|&>(=s)@k%lWQs}1q{OR4*+u!c(q}xwENlnaiBOO4}4*dfM<vm?pzF9rmQfcik>%xEzZ015seKe{dlP)~IlAS!{9)^MO02n5-6fxH)rD_5z_cXFnc&;@1R}MW@%EO-~!U};)9~BZ1tD{M%mmn|zA=W771F)UVdMBolNdO3-^#d34MQq{11>o22!yY?1^WzGGvl0gIBHGRw$Zw2v`mzPjc^R-%P^K!!`lJ@Or@_U=%@ld{ILn_Sfl<*4ivrnpdVd*{d}^~w^?V-=v5^jtXzjtWIdw#x&+7%~(g@bs3lG8i#%Xyi0^Qm8bkr0U(qzMNG$~H0@R6rMh02K5P!et$q8(G9uCa1t5gDx@)l+Ap>7}c6VQoKMCFKgT!lq$mctO;nw2Qbgtw>`@Kum8VA@xZ&SQ*rBAsK4J5~!JftP7wkwS5{|UUD+0l;@PFuiC4@tYM|u!Y`itkZVY#RAo?2Nm8E8R0tyZh(QBLy|2pp1LK!pfcd;cwh9up2zkOVU570Hlb{@xoBrXji$vlQNIWfyCMP~|(QAd3gzrW{0A6&JbGr+%ytdjy(nUpF$Hw%_M?7qbUSbjuF@iBIFJLC~q<h=BvRM9t%xXMQt#7UY$0e#I`7H7QH0&5<&^@8-e}WvjnH=_)Rfiou?LsZ~9TV%1S~Q9oedI5LfB<W3i6y2ax&h_>^I`dB%2cUkKqCU-Je94`aO;;P#TC%kOhos1wXo=r=dE?sLS}61gby4M4-`Q+8mtfbs}l3QN;W8N$y7QeW>KtM9ztZHgTpHf{0A)7G4+-KFq;@A8j<Ytk^r$mfEw14c6_p!G$A<+tz<0u{008MUXH^ch84^=jH}c0Mak}x_nBQ6HMuJ)zG5k36bv=w8JhMckc{$c&`z1K1m$AXDSj8V@%X(`f-Mr7?`x1Gl&TDXqxWJNcJ+K&)Wb>Sq@c;aVC5qE3-|#!Rv=LJ66wj5Cs_gYl{k!Mw6Wu;cnaA>1B<8t%ylodIC-Q-O7AEWOA(vcp&qp>6Ch#&kV_(CHeoB;#ss)ZNYe|9G7ICe^OR&$F%948mvV<H0``=4$ogZ{Ir4zL6bU$|1Ewo+1rK5eA*TrDaYs;+;6cOddqEys<@bDe@vK;mk0uF^N;MPn#ymohC@3{|ZW;9mG^3FTg^h$su*7OyqK{LzT=)7|sU?`u6lGmSb6I0{vy2k97@})mQpcj|(P^MYtJcRcN5Vl^XjQs;EPAf;t$dD3U>EpO;ezxn`i%D1TF4#I&X{y`0hoJCPbWm&RwFcYCEcf3iCHaz$Ygpusf}nOvAl}NP!*F6IxIl+$zRE#-f~vcTIT<WK4zG<I67Hnnv@+oX(3d!OAFG9e7Z8$f$T@lw^T4s08nN)VnHemt<1-?_a%I-#<qk=?8HMW7L0f4ih;Cj5I<9<-!@BDmtQM_o#aCFQh1X3D`>1X`)WHs_JdGtKuO>PLN0E~&gl#5KcBnlVu?}>q8N@HCrSsCYWSe0zmWS>EMF*fgaOH2Hr8J8K5?GUPI120li(yXYnC^K$<I9rK!ufcR<3h2nsX(J_0aRQ)mVwCA#$w5R=UQ(G09Ub{YukDSLsutsd%dE_pAl!7o9#8S8j~Zma$YR&fd|JZW)6{ijEF|^D0>@NJ=cSk5v7Y@h~6bzi@_=SbJ_9DJ`GqC=l}8$)g!4rP@{5^ek3(i#LVMS1x2HY=F3$j-qR>_!9M<4e?dF_H#A#)HAQUok_lhT&|Eg^^9!ftFDe<xAA1#L|nnooWy;o#2F;~El|t|)St-)&*40Dl@p9mq?@ric(D^%C+VyyY$+Ei4EQSD{R+>Wfc=`S7p;&x80wYBX6lC!V;xDFXjF=i)jzSIjnVRGa*RN0BQYG>FK4!84Ie^Y$?65k1e_tQoA1LIT<8D=x-f_jA|t+dMzonWF7({=bSQy_QdNg2?5KPisg4{Y-8_NfjyAN09eE5XI8A^@GN`0N%+Fk!ho*|Lh@!ycTnSl3G*MIzkdx`^2Ji(#i{)yBk#ayW9v{>9A<i7x*MMvd%<0G)K-KK5Y)-*xU6h4I%Vl?l7J?UffW>Z6MG)4xP`9;0JyXPllqy)FypSp&-OMjiN}!@<#TS(o^5T_Ik^$++#mi%^60?%6{ZLQ^^z^l=qbcc@!`kAcgk1mu92!))y^+g86VhQ=sDeSe1A+fSex4tnVY~ufP%44-Ga?XyWNG9Qo<0hPsoT!*b~c`XJw%lvQB?+$g!86ypn#I^L7G)~ykrPX01g64K@@jEP>j>NrmFQ}#!F(Bm^xMM!}Qrh)t8o7eaXWPC;3v}2iyZX`%^D_>KtDvQnJ)pLMx`3EhR)fIWb0rhhpEG<Xy<VN2MZHPa^5GoWzhW%%v+V59tWkwiF;XP4$Q>R}3pSB_$Zus}<85I+xg!-UgETT7=UAFQlx}UDyFp87G}9E|uNUK}-UiiMy8K^Q<b*z}UCHHC2hV^^6NRrC5-X(uu&>Zi)}DRYW!>a<oWbWE5jVLZ4%{kG>WvK%!7#T&J7#B*lXlaq=yT7ZgSEt(9z3QURxNP0o9wgDLudLP45L8gf{LjY&LuQZ$h}C_`k#PvO!`pbnavVaEEQH!s$b$Le6Acn7;-FA~^*x9|6~dO~>1_Lf60rh--3`>zS1uzV$DA4Ua~#x`3@vm(u|XC}RJGLtSq0@}+oA^~N#o=19;vKS*P1=fQ^fkbpf1;r$3HfI6SkM$Cm2du~=kC#&A{7il``Hsz)VlLEUSEE)c`J1z0^+qSFVd<$6e08NLd<oS=J@=jY4)OA361a*Magg(o;AT_OJ0)5%M{Vo`Dy*@b56XR|)vOwwY~{ofTQx^h%kNZ@#!9}WZ4eD5#VWzB#!-|+5t&^8u34wb=hSKjH*Pu#RA@P;yee~=o(!KH7A{_C!V;OG%QcMCAbK^>SO}6trAa+=zm^YK?jxKgq@Qcb=0u1uspaDcv2+|Je#SslfR)#YulJM((uzF)XoS#+>Gi{G-j`?Y9$B>YDquW4SFoO#hcq6<+n@rfn&23*T`HvzxuO|sNIY!W7(6xOxOdAe&3IU7efEIyoyy1VjgM$CiaLuKJvy4luD*{OA-M<u4az$!SQOQY49{vYh$t_WGE4olp}vR`NwHDe6OFPSsNf|Eg0gC6L8@s&V2z*T(y3b9coo{FN+?Z^9Fy(~2163WOJN*v*+;%&<U-Nk&>yE396EUfDFY>lmE%!Rc>`7zWb3bJ(6et29-5A)7k9NrbJkvnhM?TXuRUaT?z!p;(msHZ1a2YuF#R@5lYiv~fGpKjnTkZSpp)y?Vx^e+Qs@Qfuv>5Up;^?yQu@&A)!BuryEwMS0x90hn)`(>eE0vG`A?z'
)))

_ACTIONS_P1 = json.loads(zlib.decompress(base64.b85decode(
    'c-rk<U2j}jZu~EL?gy(SYwWyf?A{$?HI^aEX>1H(Fu-mQAlN)i@)qR3N4C^om&Ia{Jhvr#{WLvt_r2%)ki}y0^Z%aw`|p4J<L`f*{LAN)50@W5p4=@?{^R%m`rCis|Ka}QKYst?KmYze_n$wX{QT*!zkRs5e*5Xo?aAU~{mbg|{=cW^cZ<&_zr4Fyodh4g{QUC$yI(J_?tlH}dVT*}^XHGhtX3aR7U!FP__$iVz5nyCtE=nxCySSpKR-6%<=x%?Ee^Wz?#*95eb{@;wnLv!)~k=VUz@Z2@Yw0SpKV)l*#D2KtE=5xU*k5O;WnPSZQOogzm@N=Z*G72+Nj+p+s?<I9=3Dxp2u#g&;I$-yQ{aq-T&|Hr!Uh+9z6M`-ukP{H>>R+vo~zM`DGRlo`3%j?{Bw5?!4zu`{U1EbNI!BwQ_m8y78X><}w(dhcDo9+4NxZ(!J+Ceu<6CWS64H?V4VgTKj_C<G{AjC)7T7`!s(*<cYM8|9JiBalpZNgcInG^KRkU;i$~tUhDjEXwBdD)U)HznLlMf8uKTOOJyE6zXikb(1F_HcI$2Wr`q%E@D5oGtoyCiuzASpa^NCRMq}_Ac=(Wb+@YcHVDg05LAcW1Twh(S-rWB7r`65vyQ_Eq_O+SzK1tpFg=-5ngFIk!%cU9$-WoPE7@cIZH+y&F1XVVF{lNI~lOI2MMn8eh)80;baObd}Xxz+;od2}7LgJIhH~+1lwWu9s#vfAr>bvAwGwDa?cGz8tm4<@zAGTd-p?{a)HpV|U!xSF!8~b4JFoD6xqf}|&)ZR}mf<3RP@M=52g(mC<*t9?%UodUX0EZ1^o@L=EHA7T*#&(44Z`Bb355)sizAgS)ep|ij4(_}uV0ifFkGD6M>z`LQH-G(tG1e}_$%o;W;;8HKX)em{mAP?G_hzcw6Uh}@0HCsbrRw*FZJa&U@QAeCs_FIHx+j3&M=#<L9WbzGc7(trBCIp^B^3*4w>(PE+cnI^zXzF_p6Q_(A=X})V1lj7)*c)#099<{1a#|MeLo&D<{>@1pylzBGckys{<!<g?sBj3NsqADX5&8>T{Op${<3;6Z~nD#fq}s!*F+g~NSHX_p&*b}agwJlw$z-*172IsPcaF)%e`%#)bZW7u?KFW-}x9`%XT2{`Sw;;CPeqhZ8%h(B`FkE>GSu0b#G4YpS~KyH8<a(K<VE9d5`W?_mrmB|1x77G$03LBg8IP?4HJ!Qs3ZsY6}55m`5-d2szBR8{$*jBZQ3|Wq&2Aqa7c@9vdJUXSEO3R@mK_+bikeLvIsJA3FlpaZr&XAl(U9oW%q>uDFV#b*@F$&H9)saLJJ$(hAcU;?a?2;3+|cvplGv80+9Q&&xR2cSw$57ch4t^e25BVhD(mzyA{92L=H#Tw~P01J83f0Ma3ypx8#;4A3J;M;Q8bW!#w|ldwJPWAH)<AN2O-`a`e|h<&y5B(JZp9#3j;f^U;Z?k}FVC$Vj3(FXKt;)X6q2B9}k%p4rLP0GE{?Q^z^O@A_RT6T{$u-L>XNbs^fZw4frBo?T0Roa+Q!4<%{Jz@yFguZ;;GpBUZD2Zq(fM!`lLB9U@46j5jjv_~J&d4r(turdSai0YYQOO~m4t|sTG%L`9-mCg_Lt3hXL?FG*H$UdGDS`RtjE>U{d*oME*YxnGBe1}9i;kfdEU&}M0v#$j_D#*tAYO|%XKXzUCK+#Dg{DScJ3|Sl2t2i~^d_q1oq+WmybrGEm1-XV8kJeIU<vrfbHe0NSjYgJi||I~Ues||5@FTOJ2Z>~_*C{toEV3AVc4j@#var%r=0s#pp;3j1c7kvgD11Y!b$qlg(<ZMy9PaWYjD4P_vgu%3U7=Ff5^s1U+)B=!M*@*7q5{@gqVT6i`fFxZuaTC#IyYf_Rf(R={7B}t1>dC%pEF&M-T&cN{RCws-^2tEp?k$a%Fb+wH>2QO0Dy{{quV}u)4*+yc>|7tGZ7aM^Z^4!!D3Dp=NP_LL7O)Xh6uqsx1oc@0eCXKGV#LL-2ZxQ76#WB+`R58>eQ`py<Kw)^kQ7lb@$hR)J~kdc(PQ1+(Z_TL(*8q0IsNADFDWx0$hbedl=bu=qr1LvAO7C6p#!h_-Ne&W4K!xOV<&Kt0?{QYbm8eD<S@b!>-2Sx?o|35-7Cgp6QnPH*T%K#1*_$V`QYAwmuFm<8v!VLY{JFYfX@4<It6yt*Yh^B7mu`u6L)tG|5dnimL}!8`b=8(nD`{!7O$;)Xx-8X_M+fYl`{9urG42CTppkc{S>6+N6`fZAy9ze=0VveqTSv!eTQ0QIFnA&FeW_*}0rO(x5hobh#FG|x;CY<@N_qg)eeS?(5eVYxJ7A7E*OZUl&ZRFY%~K|BnY#mK(dGA?B#T(qrTZr=e6I<g)IY!o&G$km9JpqYn3N%P!i4wj(dbS33(Y+M3l*oh(A7Klrn%>C8bQ-w4i_8-l>q;Z*4aM{nmsVDEBDB#SLGPVd*aprsN+>wV_Uc`u77f#G!M|2$QV$3!OLwII~y5U|*;puXK=L8Nz-E*>`UJ!v{UmC*mcQmuKHwKOO8R*@#0((ZST?2(s7P4+Zk#bjqy=>R4Tj%GyJJw>eE7oYT0M4$tDUWX|^c{rG#4h*TMv(7BHTW$sy(i$U%?k?==3P+G0Rg19-2tYjli36KSQSWGH4W^R0Ii2|^`zFpOz<|4_zz5>@MHk?G3qRxpUFs6q?}=&06!bq)xQ7g5Ti0a#$=L-&?Me0gr~DxI9rGrctlQG)GE$od9+_Hh*{%MDPFl$3WZw<)ZiTkkI3JW3AAkbZ4d^OMu>@pka&^+1|YEM1sfrjqIk_o$DOQl@U{@YlJP=tU~ad9k3irqMazDF#xC6T{rU*&n?xQb-vk52E_`vMnyWQBdby?Jay0h;?O_q{*{vMZ0%Gmco`Ze`IGTo8Bn1YW3sJkbXsso73CaovO98~>Yf>hSdcoXIpXw`9v=<7D)O0rza+c#3nbM7L#xj?Ho(w>F&Hi!&KG0L*dk=Jk5&4(L1oSkBZzT98@|7X@MxhZcPxQRON#)m44!3DSX{ad~FfH4%nK`XtDky*s7$$&juyUUWjy3~#VmQ8}WPvICiZXU5kQm*0*B#W|Iyi9Sp8=bn^6O)*(Q?8MTeo&@bITU(HL$LV0<0ltSeoKRuu)r@t}r9bOdL1ziB3m_0?lSO-bW(V5pQ?fu-&gWsd_e#fKu|wy;U2b5Y@`<21bnO>HI{ffT!?+*I7#|2*ppO1#fYPf+{tP3%?dvVHA~4#8=!Zsm0{%e9mRa^@xZ~1ImHsnIM)xUb%Yb_IiRv_k_)=WKSPqXgbQ#FTOF~n6h3{T9TO355jy%Dw6xg_P6^d<<k9^Q{8udb*IQ&5{f<dH|#LD6qZq$0!h}aK(0A@`hY^beJXDsO(Y1#Y1RM_l8<2(D{D955kX6B`@6%9s6~+Aj;m%bd)atpk25Wr3I_-hc_sOkc>IXuxK}|V!Sdzi|2ScoHDM{x5wl-Uh^Bz(B_S5-LxgD;nG(1Dx?9r+3&}lXRb)!ck#&c;S-^ebj`>*WA+jql<u5C4S}R#&y;2VP5@oFwp{-=jJRU$bj4L{uhgOJtO(={cPM=0XWyJS$Cf7HVv<s!Ar-o>0Hba?SiR|P_Ej}eCsi&arC6%~Suk4vd3SBNaTO>3y2GL_y#L{L(q?(&>Vi%kT8Lk4WeO>ga{YHdI?`QkN^>qZ#?-~yI^8A}iI(gzm`n4nTkxr=ZDI%$#jvs062@fAP@<zaj(c$85*iEg_(O6|E&>(3mG2yKWI1h79;B_<WGGnr;tb>h3Mq*n7*~2}3B;?F6f@lqM5VNp(SkXEs72A|KI|=q{CfEvE;q?WsO8cG0Db178(OF!JvgR^<=mH^}f0_kQP-9cqBDJcSExqsZy}D~<@KZRPkQ(MotGDKe^#li3aAOH<wG^-+s%Kt^kpE@y1Szi^o1kyq&!$=!FDI+GPeu~=(5*UqM$VL$xIe(F0#0@#$=;7;jwu1;J|37rL3UsQNEgbwtU=gFW^g@K)fd}nM(^smU1$BWz{TA6b(~0DBV}?$=H$PYcE*0<c@(5vWF!5FK~gpdOYT%`>to2I*_{!)WJE0@NXpdOjEcs1@V*~`0C7iM4>sf8Ax7UyXE@Ga$MY@81Wd*c1+NR@?+4^#9Ig0I41TfT4V%0=@q?-PgnJfzlk6Qq>_l@OvAd?gDV{w5Rd7RdG$jj&Sj3))QOb2-yk~zSfH+rf>gs+bA{5Iz!}GR!geWqqL@6XhMTcm&f#KS{!McKR0xylP&0EA~uI$r`?}J!tE9so-Dk&8LZX60cD<!8ogxhqEs>ZV&A&}N^t7*j0aiiz*SY=&h;7Vnwz#t|!hnJno?&7h{yyv5kF{BH)lup<f)#T2}R1AUESFjj5o5?N!91W&CR&3ggkbC3$G?M?G2`9(|#(;3T9cXAn+dmfhu?jaa$c+bRMh5j^dT=CCNael2A=pG@kyMc?aU~SQEY^0X<YBBIhZ@sg)pVd}V7tV>)QW=P0oa=4yebmQx_dBcEqfJ^sTmSvb2_OJNFD54^6n}ed=<Ou)Z$7>OvH7ET0~hi65EwR_{5%*MM$Nu95LzFdw;id%EL%df&py&V;cl%dBk?nOB7duNH&*Gx*r}rJqHZm7ly|A>YEFh=C#iEJ<6I(n~KAZp|?U$_RRg4P%|C=>ZMSWwqR34?s)3(^KY`E-gqJwoFJ14PX2R<7;E*gc)*kOrc!FC9$8L^Rq8pfS`?0Fx23&4X87&Xz$2tQVC_XQyuro3q-ymV$(W_Z@xV($gGDM{Ed)8J6MzDT*paEA2VLHN6l9>q71((oWT@3#eMhrb4wK_G>25T}Y^cc6NGW`1hh}R&B#yc+=0Xu&G5a{IQP3-`hIn&k0+e`uR&pQ`n~qbPnGjhk=C38Nvy-^6pa8Iq2NzsdIz52WqlU3Vgks1sc>tkG%6X)#KSecX?QQ{!MP#h!s2XwA<=P@+%3Ean3mO_sj1ioS3HCrROOlvatf97<J(+_T)->tY-X<6i;94m>5}}^S5z2X6B7JyDXQjF$qQ&x5R1Gg`)y*f3-INHQAYreayoBX9T@COE=vGHfTuwI_lv$fCYwh_l#ROYL5h`$A)~lxzQ3eV_0;_K=2IlL`(E#5F&D{}7)k9<jbPXr8lzJ890O8j)<|vbi<nJD9fvzdFfV$2NLXH%D6c(n$Ur+GG80~<aFe005Z29g;lPPxfD8N=3EM~|1Kp!s)Um}aBJQ~V9D2OyD{vdc~I924*fE|p15Vq6<O-M$!nQ6?3osn4P>QGga)OoTEhUTqfu;*J2@YN$$D>*`KwsdY^vc|~tG2d=tLsvv^Sc}=~h}gNJl2;r<kXjH$AZ+_GgfH6|h&(`I74gsPLps?Gaq{~s!>PIW9`fNA<Gk9rb--D5d&A7A=xReIb%#*4UX5W;G{vp5!0~XthrRoA;@*U5TI6$_4RVP<hh)+3T(F_S^C)J8Mi8l(e_09~X7%=Qf`H;t^J+jtHTWGpVU`1&%S`Vi_~(`R^8|ljiO0p&=b&XVJOxagDrhy6RzG(QQUZ#}VBiqtMZD|<C!e1trMgp$P)~)jEsV*cjiFd-ADp9l?<u|VGW(`N9%9ocXqXFG9&H2zAuF0PJ=$lbY<0}iKff#CFd@i+fxp1K)gy+|SVIUyI1do{xz#ecI6XkJR@D(}Ah{%Fzl(MgpCpv&?y8y7if~HJIacFagDU2dON6tlpcVxJ!E0ft^T{epnj*AOT>p+!Rc49W`)Yfo92I)lxtShL;z=&bJx57#1+7VmILyc;0I*1!S1UF5DaGSyDbuVl1hAgiFJ_}A==yVL&Nk(HDU88$=KBl=nBglVqUb3%B;y`=wVP2<l7x%OhEnE=1G6fA3{#J&&tXd*k&`D_SuU+^eJ!OsbQ{Sa=L6Bc>Rli_6fzB{mSC>D91dj)sR#I^ES8L?N0MHHNlPZQ1<hmMnkwc9qm|3*qB(RVi>*KUKuU+04S{w}KL4?z=vlcZ$%#zPCR*)wo!J5mMA8Otr69XvMLHo>rz)~4&A)Ee(9D~F<5ZiMAo^M4mjUxx8Y$&|&rFX1ScgSkX_!rlfTSjY-KD8*P0NThQ16_uu5`n4QYy{nVATjM1|_7g{8YefVt+E+J7J}YAeSV*;&UpY<MUP?Fg8VtrA_#GVGuH;@N)J|r>`^xUd}I$lmj!Q(guglUKaIS<_MAIOLH(!iN(AtWt}ajGEr7syE^kVAx0z^=*~QG8h5NtrL1;DWTD@jRp~{~n2h7h8JAhD#w`gT?hf$P)%AOjR=QUBet{vErbB54*H9T4l5-tzQK)lB%TQD(2B~?IbYp;jZt*y#8=$y@j@eyc>zxlm^%1qHE71i0v<r8d5d>?47;cYqd@7WgWmj1Y7KU&mRQ2^ws#xGHQR&6MoV`mDl4)ZwWHKdk?L}`ZYUOKu1xyk!6p;*e6pijtKnY<QFQT%o0(LZtBjp5<lsw;<TeO}0+)CxNZzV4#oa%`3udO!8)T6qva^h#upJ_`t1J8q|c|vRu^i9g>#U2P)u}MBD{5rG3NPDp{SYMz*f*H`{C08z_nERoXK%R+vq8T}RrrMk+=*_M_xqg5J_15`7X>d;y{T~sS&monm^Ki4&mUoG2+m=>nxo>*Z9-cxzh$u4Tyn~VTi_`jS_rv_fgD(i`L<lyY_6GuR%RUkCl^wi@9Jq&Ze@E=Vq59QMF66G#6RhMgUqz;+S_o0Gk6=4FJU5EgHwF#S%Qx|F#<adcrJWdKjTdvGa-XFA1Y|64lCJCw?J11<C8VP9x4)8Ko<a2}LCZHzNMSf>qt+C+x)Rxh{6V!MN~P54pdl+sYnnxDiqcWsS5rE)S5NYh*2P>27iI_?mbNB#;LYHn<yKdfAStCxtJ)|&>(=s)@k%lWQs}1q{OR4*+u!c(q}xwENlnaiBOO4}4*dfM<vm?pzF9rmQfcik>%xEzZ015seKe{dlP)~IlAS!{9)^MO02n5-6fxH)rD_5z_cXFnc&;@1R}MW@%EO-~!U};)9~BZ1tD{M%mmn|zA=W771F)UVdMBolNdO3-^#d34MQq{11>o22!yY?1^WzGGvl0gIBHGRw$Zw2v`mzPjc^R-%P^K!!`lJ@Or@_U=%@ld{ILn_Sfl<*4ivrnpdVd*{d}^~w^?V-=v5^jtXzjtWIdw#x&+7%~(g@bs3lG8i#%Xyi0^Qm8bkr0U(qzMNG$~H0@R6rMh02K5P!et$q8(G9uCa1t5gDx@)l+Ap>7}c6VQoKMCFKgT!lq$mctO;nw2Qbgtw>`@Kum8VA@xZ&SQ*rBAsK4J5~!JftP7wkwS5{|UUD+0l;@PFuiC4@tYM|u!Y`itkZVY#RAo?2Nm8E8R0tyZh(QBLy|2pp1LK!pfcd;cwh9up2zkOVU570Hlb{@xoBrXji$vlQNIWfyCMP~|(QAd3gzrW{0A6&JbGr+%ytdjy(nUpF$Hw%_M?7qbUSbjuF@iBIFJLC~q<h=BvRM9t%xXMQt#7UY$0e#I`7H7QH0&5<&^@8-e}WvjnH=_)Rfiou?LsZ~9TV%1S~Q9oedI5LfB<W3i6y2ax&h_>^I`dB%2cUkKqCU-Je94`aO;;P#TC%kOhos1wXo=r=dE?sLS}61gby4M4-`Q+8mtfbs}l3QN;W8N$y7QeW>KtM9ztZHgTpHf{0A)7G4+-KFq;@A8j<Ytk^r$mfEw14c6_p!G$A<+tz<0u{008MUXH^ch84^=jH}c0Mak}x_nBQ6HMuJ)zG5k36bv=w8JhMckc{$c&`z1K1m$AXDSj8V@%X(`f-Mr7?`x1Gl&TDXqxWJNcJ+K&)Wb>Sq@c;aVC5qE3-|#!Rv=LJ66wj5Cs_gYl{k!Mw6Wu;cnaA>1B<8t%ylodIC-Q-O7AEWOA(vcp&qp>6Ch#&kV_(CHeoB;#ss)ZNYe|9G7ICe^OR&$F%948mvV<H0``=4$ogZ{Ir4zL6bU$|1Ewo+1rK5eA*TrDaYs;+;6cOddqEys<@bDe@vK;mk0uF^N;MPn#ymohC@3{|ZW;9mG^3FTg^h$su*7OyqK{LzT=)7|sU?`u6lGmSb6I0{vy2k97@})mQpcj|(P^MYtJcRcN5Vl^XjQs;EPAf;t$dD3U>EpO;ezxn`i%D1TF4#I&X{y`0hoJCPbWm&RwFcYCEcf3iCHaz$Ygpusf}nOvAl}NP!*F6IxIl+$zRE#-f~vcTIT<WK4zG<I67Hnnv@+oX(3d!OAFG9e7Z8$f$T@lw^T4s08nN)VnHemt<1-?_a%I-#<qk=?8HMW7L0f4ih;Cj5I<9<-!@BDmtQM_o#aCFQh1X3D`>1X`)WHs_JdGtKuO>PLN0E~&gl#5KcBnlVu?}>q8N@HCrSsCYWSe0zmWS>EMF*fgaOH2Hr8J8K5?GUPI120li(yXYnC^K$<I9rK!ufcR<3h2nsX(J_0aRQ)mVwCA#$w5R=UQ(G09Ub{YukDSLsutsd%dE_pAl!7o9#8S8j~Zma$YR&fd|JZW)6{ijEF|^D0>@NJ=cSk5v7Y@h~6bzi@_=SbJ_9DJ`GqC=l}8$)g!4rP@{5^ek3(i#LVMS1x2HY=F3$j-qR>_!9M<4e?dF_H#A#)HAQUok_lhT&|Eg^^9!ftFDe<xAA1#L|nnooWy;o#2F;~El|t|)St-)&*40Dl@p9mq?@ric(D^%C+VyyY$+Ei4EQSD{R+>Wfc=`S7p;&x80wYBX6lC!V;xDFXjF=i)jzSIjnVRGa*RN0BQYG>FK4!84Ie^Y$?65k1e_tQoA1LIT<8D=x-f_jA|t+dMzonWF7({=bSQy_QdNg2?5KPisg4{Y-8_NfjyAN09eE5XI8A^@GN`0N%+Fk!ho*|Lh@!ycTnSl3G*MIzkdx`^2Ji(#i{)yBk#ayW9v{>9A<i7x*MMvd%<0G)K-KK5Y)-*xU6h4I%Vl?l7J?UffW>Z6MG)4xP`9;0JyXPllqy)FypSp&-OMjiN}!@<#TS(o^5T_Ik^$++#mi%^60?%6{ZLQ^^z^l=qbcc@!`kAcgk1mu92!))y^+g86VhQ=sDeSe1A+fSex4tnVY~ufP%44-Ga?XyWNG9Qo<0hPsoT!*b~c`XJw%lvQB?+$g!86ypn#I^L7G)~ykrPX01g64K@@jEP>j>NrmFQ}#!F(Bm^xMM!}Qrh)t8o7eaXWPC;3v}2iyZX`%^D_>KtDvQnJ)pLMx`3EhR)fIWb0rhhpEG<Xy<VN2MZHPa^5GoWzhW%%v+V59tWkwiF;XP4$Q>R}3pSB_$Zus}<85I+xg!-UgETT7=UAFQlx}UDyFp87G}9E|uNUK}-UiiMy8K^Q<b*z}UCHHC2hV^^6NRrC5-X(uu&>Zi)}DRYW!>a<oWbWE5jVLZ4%{kG>WvK%!7#T&J7#B*lXlaq=yT7ZgSEt(9z3QURxNP0o9wgDLudLP45L8gf{LjY&LuQZ$h}C_`k#PvO!`pbnavVaEEQH!s$b$Le6Acn7;-FA~^*x9|6~dO~>1_Lf60rh--3`>zS1uzV$DA4Ua~#x`3@vm(u|XC}RJGLtSq0@}+oA^~N#o=19;vKS*P1=fQ^fkbpf1;r$3HfI6SkM$Cm2du~=kC#&A{7il``Hsz)VlLEUSEE)c`J1z0^+qSFVd<$6e08NLd<oS=J@=jY4)OA361a*Magg(o;AT_OJ0)5%M{Vo`Dy*@b56XR|)vOwwY~{ofTQx^h%kNZ@#!9}WZ4eD5#VWzB#!-|+5t&^8u34wb=hSKjH*Pu#RA@P;yee~=o(!KH7A{_C!V;OG%QcMCAbK^>SO}6trAa+=zm^YK?jxKgq@Qcb=0u1uspaDcv2+|Je#SslfR)#YulJM((uzF)XoS#+>Gi{G-j`?Y9$B>YDquW4SFoO#hcq6<+n@rfn&23*T`HvzxuO|sNIY!W7(6xOxOdAe&3IU7efEIyoyy1VjgM$CiaLuKJvy4luD*{OA-M<u4az$!SQOQY49{vYh$t_WGE4olp}vR`NwHDe6OFPSsNf|Eg0gC6L8@s&V2z*T(y3b9coo{FN+?Z^9Fy(~2163WOJN*v*+;%&<U-Nk&>yE396EUfDFY>lmE%!Rc>`7zWb3bJ(6et29-5A)7k9NrbJkvnhM?TXuRUaT?z!p;(msHZ1a2YuF#R@5lYiv~fGpKjnTkZSpp)y?Vx^e+Qs@Qfuv>5Up;^?yQu@&A)!BuryEwMS0x90hn)`(>eE0vG`A?z'
)))

__version__ = "mapleleaf-6.2-puretape"

_PRICE_FLOOR = 1
_DEMAND_ALPHA = 0.25
_MARKET_PARAMS = {
    "WHEAT":       (25,  10000, 400, "sqrt",   0.8, "log",    0.2),
    "CARROT":      (35,  10000, 450, "log",    0.2, "sqrt",   0.7),
    "TOMATO":      (60,  10000, 200, "linear", 0.4, "sqrt",   0.6),
    "STRAWBERRY":  (120, 10000, 100, "sqrt",   0.7, "linear", 1.6),
    "MELON":       (250, 10000, 300, "log",    0.2, "sq",     3.6),
    "EGG":         (50,  10000, 332, "linear", 0.4, "log",    0.2),
    "MILK":        (160, 10000, 122, "sqrt",   0.6, "linear", 1.6),
    "WOOL":        (200, 10000, 105, "log",    0.2, "sq",     3.2),
    "FERTILIZER":  (100, 10000, 200, "linear", 0.4, "linear", 0.4),
}
_SHOP_PRODUCTS = {
    "BAKERY":        ("EGG", "WHEAT"),
    "PIZZA_SHOP":    ("MILK", "TOMATO", "WHEAT"),
    "BRUNCH_SPOT":   ("EGG", "WHEAT", "STRAWBERRY"),
    "YARN_STORE":    ("WOOL",),
    "ICE_CREAM_SHOP":("STRAWBERRY", "MILK", "WHEAT"),
    "PET_CAFE":      ("CARROT",),
    "SMOOTHIE_SHOP": ("STRAWBERRY", "MILK"),
    "FARMERS_MARKET":("WHEAT", "CARROT", "TOMATO", "STRAWBERRY"),
}
_SELLABLE = tuple(_MARKET_PARAMS)
_LIQUIDATION_ORDER = (
    "CARROT", "EGG", "FERTILIZER", "MELON", "MILK",
    "STRAWBERRY", "TOMATO", "WHEAT", "WOOL",
)
_WEED_STATE  = {0: {}, 1: {}}
_WEED_REPLAY_STEPS = 8
_SHIFT_STATE = {
    0: {"last_step": -1, "due_step": -1, "due": {}},
    1: {"last_step": -1, "due_step": -1, "due": {}},
}

# Preempt parameters — P1 uses tighter clone-distance to avoid misfiring after P0 sells
_PREEMPT_ENABLED            = True
_PREEMPT_FRACTION           = 2.0
_PREEMPT_MAX_BATCH          = 45
_PREEMPT_MAX_CLONE_DISTANCE_P0 = 12
_PREEMPT_MAX_CLONE_DISTANCE_P1 = 10   # P1 is more conservative: market reflects P0's sells
_PREEMPT_MIN_PRICE_RATIO    = 0.0
_PREEMPT_MIN_FUTURE_QUANTITY = 2
_PREEMPT_START              = 72
_PREEMPT_STOP               = 680
_PREMIUM = ("STRAWBERRY", "MELON", "MILK", "WOOL")

# Price-floor guard: debate determined that a 50%-base cap breaks capital timing
# (SELLs fund same-step HIREs). Only gate at the absolute $1 floor: those sells
# add zero capital anyway and waste a market-order slot.


def _get(value, key, default=None):
    if isinstance(value, dict):
        return value.get(key, default)
    getter = getattr(value, "get", None)
    if callable(getter):
        return getter(key, default)
    return getattr(value, key, default)


def _copy_action(action):
    action = copy.deepcopy(action or {})
    return {
        "farmer": list(action.get("farmer") or ["PASS"]),
        "hands":  [list(order or ["PASS"]) for order in (action.get("hands") or [])],
        "market": [list(order) for order in (action.get("market") or [])],
    }


def _seat(obs):
    return 1 if int(_get(obs, "player", 0) or 0) == 1 else 0


def _farm(obs, seat):
    farms = list(_get(obs, "farms", []) or [])
    return farms[seat] if seat < len(farms) else {}


def _align_hands(action, obs):
    action = _copy_action(action)
    expected = len(_get(_farm(obs, _seat(obs)), "hands", []) or [])
    hands = list(action.get("hands") or [])
    if len(hands) < expected:
        hands.extend([["PASS"] for _ in range(expected - len(hands))])
    action["hands"] = [list(order or ["PASS"]) for order in hands[:expected]]
    return action


def _shed_access(size):
    half = size // 2
    return {
        (half - 1, half - 1), (half, half - 1),
        (half - 1, half),     (half, half),
    }


def _projected_shed(obs, action):
    farm    = _farm(obs, _seat(obs))
    private = _get(obs, "private", {}) or {}
    projected = {
        key: max(0, int(value or 0))
        for key, value in dict(_get(private, "shed", {}) or {}).items()
    }
    inventories = list(_get(private, "inventories", []) or [])
    positions   = [_get(farm, "farmer", [0, 0]), *list(_get(farm, "hands", []) or [])]
    unit_actions = [action.get("farmer", ["PASS"]), *list(action.get("hands") or [])]
    tiles  = list(_get(farm, "tiles", []) or [])
    access = _shed_access(len(tiles) or 10)
    for index, unit_action in enumerate(unit_actions):
        if index >= len(positions) or index >= len(inventories):
            continue
        position = positions[index]
        if not isinstance(position, (list, tuple)) or len(position) < 2:
            continue
        x, y = int(position[0]), int(position[1])
        if (x, y) not in access or not (0 <= y < len(tiles) and 0 <= x < len(tiles[y])):
            continue
        inventory = {key: max(0, int(value or 0)) for key, value in dict(inventories[index] or {}).items()}
        if unit_action and unit_action[0] == "DROP":
            deposits = inventory.items()
        elif unit_action and unit_action[0] == "PLACE" and len(unit_action) >= 2:
            item = unit_action[1]
            tile = tiles[y][x]
            structure = {"COW": "PASTURE", "SHEEP": "PASTURE", "GOOSE": "COOP"}.get(item)
            if structure and isinstance(tile, dict) and tile.get("kind") == structure and not tile.get("animal"):
                continue
            try:
                requested = int(unit_action[2]) if len(unit_action) >= 3 else 1
            except (TypeError, ValueError):
                continue
            deposits = ((item, min(max(0, requested), inventory.get(item, 0))),)
        else:
            continue
        for item, quantity in deposits:
            room   = max(0, 100 - sum(projected.values()))
            amount = min(max(0, int(quantity or 0)), room)
            if amount:
                projected[item] = projected.get(item, 0) + amount
    return projected


def _public_signature(farm):
    keys   = ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON",
              "COW", "SHEEP", "GOOSE", "PASTURE", "COOP", "WEED")
    counts = {key: 0 for key in keys}
    for row in (_get(farm, "tiles", []) or []):
        for tile in row if isinstance(row, list) else [row]:
            if not isinstance(tile, dict):
                continue
            for field in ("crop", "animal", "kind"):
                value = str(tile.get(field, "")).upper()
                if value in counts:
                    counts[value] += 1
                    break
    return (
        len(_get(farm, "hands", []) or []),
        len(_get(farm, "unlocked_quadrants", []) or []),
        tuple(counts[key] for key in sorted(counts)),
    )


def _clone_distance(obs):
    farms = list(_get(obs, "farms", []) or [])
    if len(farms) < 2:
        return 10**9
    left, right = _public_signature(farms[0]), _public_signature(farms[1])
    return (
        abs(left[0] - right[0])
        + 3 * abs(left[1] - right[1])
        + sum(abs(a - b) for a, b in zip(left[2], right[2]))
    )


def _shift_state(obs, step):
    seat  = _seat(obs)
    state = _SHIFT_STATE[seat]
    if step == 0 or step < int(state.get("last_step", -1)):
        state = {"last_step": step, "due_step": -1, "due": {}}
        _SHIFT_STATE[seat] = state
    state["last_step"] = step
    return state


def _repay_shift(obs, action, step):
    if not _PREEMPT_ENABLED:
        return action
    state = _shift_state(obs, step)
    if int(state.get("due_step", -1)) != step:
        if int(state.get("due_step", -1)) < step:
            state["due_step"], state["due"] = -1, {}
        return action
    due = {item: max(0, int(quantity)) for item, quantity in dict(state.get("due") or {}).items()}
    market = []
    for raw in action.get("market", []) or []:
        order = list(raw)
        if len(order) >= 3 and order[0] == "SELL" and due.get(order[1], 0) > 0:
            item       = order[1]
            requested  = max(0, int(order[2]))
            reduction  = min(requested, due[item])
            requested -= reduction
            due[item] -= reduction
            if requested <= 0:
                continue
            order[2] = requested
        market.append(order)
    action["market"]               = market
    state["due_step"], state["due"] = -1, {}
    return action


def _actions_for_seat(seat):
    return _ACTIONS_P1 if seat == 1 else _ACTIONS_P0


def _future_sells_at(step, horizon, seat):
    actions = _actions_for_seat(seat)
    if step + horizon >= len(actions):
        return {}
    result = {}
    for raw in (actions[step + horizon].get("market") or []):
        if len(raw) >= 3 and raw[0] == "SELL" and raw[1] in _PREMIUM:
            result[raw[1]] = result.get(raw[1], 0) + max(0, int(raw[2]))
    return result


def _preempt_shift(obs, action, step):
    if not _PREEMPT_ENABLED or not (_PREEMPT_START <= step < _PREEMPT_STOP):
        return action
    seat  = _seat(obs)
    max_clone_dist = _PREEMPT_MAX_CLONE_DISTANCE_P1 if seat == 1 else _PREEMPT_MAX_CLONE_DISTANCE_P0
    state = _shift_state(obs, step)
    if state.get("due") or _clone_distance(obs) > max_clone_dist:
        return action
    market    = list(action.get("market") or [])
    if len(market) >= 10:
        return action
    remaining = _projected_shed(obs, action)
    for raw in market:
        if len(raw) >= 3 and raw[0] == "SELL":
            item = raw[1]
            remaining[item] = max(0, int(remaining.get(item, 0) or 0) - max(0, int(raw[2])))
    prices = _get(_get(obs, "market", {}) or {}, "prices", {}) or {}

    for horizon in (3, 2, 1):
        future = _future_sells_at(step, horizon, seat)
        if not future:
            continue
        shifted      = {}
        trial_market = list(market)
        trial_remaining = dict(remaining)
        for item in _PREMIUM:
            future_quantity = max(0, int(future.get(item, 0) or 0))
            if future_quantity < _PREEMPT_MIN_FUTURE_QUANTITY:
                continue
            base_price    = float(_MARKET_PARAMS[item][0])
            current_price = float(_get(prices, item, 0) or 0)
            if current_price <= _PRICE_FLOOR:
                continue
            if current_price < base_price * _PREEMPT_MIN_PRICE_RATIO:
                continue
            target = min(
                max(0, int(trial_remaining.get(item, 0) or 0)),
                future_quantity,
                _PREEMPT_MAX_BATCH,
                max(1, int(round(future_quantity * _PREEMPT_FRACTION))),
            )
            if target <= 0 or len(trial_market) >= 10:
                continue
            trial_market.append(["SELL", item, target])
            trial_remaining[item] = max(0, int(trial_remaining.get(item, 0) or 0) - target)
            shifted[item] = target
        if shifted:
            action["market"]     = trial_market[:10]
            state["due_step"]    = step + horizon
            state["due"]         = shifted
            return action
    return action


def _tile_at(farm, position):
    try:
        x, y = int(position[0]), int(position[1])
        return (_get(farm, "tiles", []) or [])[y][x]
    except (IndexError, TypeError, ValueError):
        return "LOCKED"


def _trace_actor_action(step, actor, seat):
    actions = _actions_for_seat(seat)
    trace   = actions[min(max(int(step), 0), len(actions) - 1)] or {}
    if actor == "farmer":
        return list(trace.get("farmer") or ["PASS"])
    hands = trace.get("hands", []) or []
    return list(hands[actor] if actor < len(hands) else ["PASS"])


def _weed_repair_action(obs, action, step):
    action = _align_hands(action, obs)
    seat   = _seat(obs)
    game   = _WEED_STATE[seat]
    if step == 0 or step < game.get("last_step", -1):
        game = {"last_step": step, "active": {}}
        _WEED_STATE[seat] = game
    game["last_step"] = step
    farm         = _farm(obs, seat)
    positions    = [_get(farm, "farmer"), *list(_get(farm, "hands", []) or [])]
    unit_actions = [action.get("farmer", ["PASS"]), *list(action.get("hands") or [])]
    active       = game["active"]

    for actor, transaction in list(active.items()):
        index = 0 if actor == "farmer" else int(actor) + 1
        if index >= len(unit_actions):
            active.pop(actor, None)
            continue
        age = step - transaction["start"]
        if age == 1:
            unit_actions[index] = list(transaction["intended"])
        elif 2 <= age <= 1 + _WEED_REPLAY_STEPS:
            unit_actions[index] = _trace_actor_action(step - 1, actor, seat)
        else:
            active.pop(actor, None)

    for index, (position, intended) in enumerate(zip(positions, unit_actions)):
        actor = "farmer" if index == 0 else index - 1
        if actor in active or not isinstance(intended, list) or not intended:
            continue
        if intended[0] not in ("BUILD_PASTURE", "PLANT"):
            continue
        tile = _tile_at(farm, position)
        if not isinstance(tile, dict) or tile.get("kind") != "WEED":
            continue
        active[actor] = {"start": step, "intended": list(intended)}
        unit_actions[index] = ["DIG"]

    action["farmer"] = unit_actions[0] if unit_actions else ["PASS"]
    action["hands"]  = unit_actions[1:]
    return _align_hands(action, obs)


def _shape(name, value):
    value = max(0.0, float(value))
    if name == "linear": return value
    if name == "sq":     return value * value
    if name == "sqrt":   return math.sqrt(value)
    if name == "log":    return math.log1p(value)
    if name == "log10":  return math.log10(1.0 + value)
    raise ValueError(name)


def _market_price(item, inventory):
    base, equilibrium, scale, below_func, below_target, above_func, above_target = _MARKET_PARAMS[item]
    if inventory < equilibrium:
        amplitude = below_target * base / _shape(below_func, scale)
        price     = base + amplitude * _shape(below_func, equilibrium - inventory)
    else:
        amplitude = above_target * base / _shape(above_func, scale)
        price     = base - amplitude * _shape(above_func, inventory - equilibrium)
    return max(_PRICE_FLOOR, int(round(price)))


def _is_sell(order):
    return (
        isinstance(order, (list, tuple))
        and len(order) >= 3
        and order[0] == "SELL"
        and order[1] in _MARKET_PARAMS
    )


def _impact_score(obs, order):
    if not _is_sell(order):
        return float("-inf")
    item = str(order[1])
    try:
        quantity = max(0, int(order[2]))
    except (TypeError, ValueError):
        return 0.0
    market           = _get(obs, "market", {}) or {}
    inventory        = _get(market, "inventory", {}) or {}
    prices           = _get(market, "prices", {}) or {}
    current_inventory = int(_get(inventory, item, 10000) or 0)
    current_quote    = float(_get(prices, item, _market_price(item, current_inventory)) or 0)
    later_quote      = float(_market_price(item, current_inventory + quantity))
    return float(quantity) * max(0.0, current_quote - later_quote)


def _demand_per_day(obs, configuration, item):
    town            = _get(obs, "town", {}) or {}
    shops           = list(_get(town, "unlocked_shops", []) or [])
    turns_per_day   = int(_get(configuration, "turnsPerDay", 24) or 24)
    shop_interval   = max(1, int(_get(configuration, "townShopSellInterval", 4) or 4))
    demand = 0.0
    for shop in shops:
        products = _SHOP_PRODUCTS.get(shop, ())
        if item in products:
            demand += (turns_per_day / shop_interval) * (2 if len(products) == 1 else 1)
    if item != "FERTILIZER":
        center_interval = max(1, int(_get(configuration, "townCenterSellInterval", 24) or 24))
        demand += turns_per_day / center_interval
    return demand


def _order_score(obs, configuration, order):
    score = _impact_score(obs, order)
    if score <= 0 or not _is_sell(order):
        return score
    item     = str(order[1])
    quantity = max(0, int(order[2]))
    market   = _get(obs, "market", {}) or {}
    inventory = _get(market, "inventory", {}) or {}
    current_inventory = int(_get(inventory, item, 10000) or 0)
    demand   = max(0.25, _demand_per_day(obs, configuration, item))
    excess   = max(0.0, current_inventory + quantity - 10000)
    urgency  = min(1.0, (excess / demand) / 10.0)
    return score * (1.0 + _DEMAND_ALPHA * urgency)


def _rank_sell_slots(obs, action, configuration):
    action = _copy_action(action)
    market = list(action.get("market") or [])
    rows   = [
        (_order_score(obs, configuration, order), -index, list(order))
        for index, order in enumerate(market)
        if _is_sell(order)
    ]
    if len(rows) < 2:
        return action
    rows.sort(reverse=True)
    ranked = iter(row[2] for row in rows)
    action["market"] = [next(ranked) if _is_sell(order) else order for order in market]
    return action


def _price_floor_guard(obs, action):
    """Skip route SELLs where the market price is at the absolute $1 floor.

    At $1, the sell yields effectively zero capital while consuming a market-order
    slot. Terminal liquidation will capture the inventory when prices recover.
    Gating only at $1 avoids the capital-timing risk of a broader threshold.
    """
    prices = _get(_get(obs, "market", {}) or {}, "prices", {}) or {}
    market = []
    for order in (action.get("market") or []):
        if _is_sell(order):
            item          = str(order[1])
            current_price = float(_get(prices, item, 999) or 999)
            if current_price <= _PRICE_FLOOR:
                continue  # skip — absolute floor, no real capital value
        market.append(order)
    action["market"] = market
    return action


def _terminal_liquidation(obs, action, step):
    if step < 716:
        return action
    action = _copy_action(action)
    shed   = _get(_get(obs, "private", {}) or {}, "shed", {}) or {}
    planned = {item: 0 for item in _SELLABLE}
    for order in action.get("market", []):
        if _is_sell(order):
            planned[str(order[1])] += max(0, int(order[2]))
    for item in _LIQUIDATION_ORDER:
        available = max(0, int(_get(shed, item, 0) or 0))
        extra = available if step >= 718 else max(0, available - planned[item])
        if extra and len(action["market"]) < 10:
            action["market"].append(["SELL", item, extra])
    return action


def agent(obs):
    try:
        seat    = _seat(obs)
        actions = _actions_for_seat(seat)
        step    = min(max(0, int(_get(obs, "step", 0) or 0)), len(actions) - 1)
        action  = _weed_repair_action(obs, _copy_action(actions[step]), step)
        # PURE TAPE: MapleLeaf market overlays removed (keep only weed repair,
        # already applied above, and terminal liquidation).
        action  = _terminal_liquidation(obs, action, step)
        return _align_hands(action, obs)
    except Exception:
        farm = _farm(obs, _seat(obs))
        return {
            "farmer": ["PASS"],
            "hands":  [["PASS"] for _ in (_get(farm, "hands", []) or [])],
            "market": [],
        }


def _kaggle_submission_entrypoint(obs):
    return agent(obs)
