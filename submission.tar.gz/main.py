"""MapleLeaf 7.2: heuristic Kaggriculture agent with compact CMA-ES tuning.

The compressed action tape supplies a high-output production schedule.
Observation-driven logic repairs route-breaking weeds, protects inventory,
times shared-market sales, reacts to opponent production, and recovers value
in the final turns. The submission runtime uses only Python's standard library.
"""
import base64
import copy
import json
import os
import sys
import zlib

# Kaggle's file-path loader may exec this source without defining __file__.
# The packaged artifact inlines heuristics.py; the guarded path edit is only
# for readable two-file local development.
if "__file__" in globals():
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import base64 as _sub_b64, types as _sub_types, zlib as _sub_zlib
_HEURISTICS_SRC = _sub_zlib.decompress(_sub_b64.b85decode('c-qx{YjfK;vi5iV3Lede6|<5oIky>aJXIb?NnGRDer;#w%(`?KTB2+o%c4R`cDz&h@9)#y00{6R$(dy9Y-(%AA{)&{qtWOafM&CKe3?b*UATyoS!bNachStd4bz)w;f1rYmxYsP@!(xY%QVgw@hI~qN$R~1=hNsg3Mbx+?vLF@<NP}E(qy@ayhS*Vym;n){CFG2v+n%i<3}%B&gauO%Dm9a7HKlO^5$tWUXJLKUN*Xp#>;8c_0F&3tZ|#r5APb^o}$G9i05ItpufU}cNNW+@hqA?c;jdufjl4}kSWOauEN`B$GeZBan^1m^La9hW(zO+JWsM^8ntz=;@f#RTC_nVy1Gcx2T&7b0)oG8<K=B93qivozKv&B?FO*{-|8fjP8Nk3KAA?N<St4dy6EO&IRn&I2BeX6m%j+wlNsm?y-~s+1Q)>QMI)II#Tn3F<FnVvbd0_w-v0Z&&fx4H(&1zpj~?(9Vquo^zB7r_Yyoz^!_Op*N8!|)B@1+V0oHknb(hgqIP<~`v=Nch@F5ers2}%uo<?_I*Vvn+$*nVzPaCbPctHf;;y=$PFMb;RwC#f{NxA?$s7#kLW_dFA(2sizNrX>$m*ME<66{to@S^*o5ss7jBI|muqiIBq@6pqU*&54`z34szCHHBJ25J;TjKb}lrGkFWqI*Hu7{}w;-xhd4R9r{5|G=O0-8AYfqKwdoSH!A?+s<3g7BR8t9y~jdPRyb(?V#-?1pd}*Wsn&NCHm314M*3Itu4so=w_b8vqfi`jBZF|A*v7$;wkVq!1=3q2Htl%YAC~$y0xGYSwM=yX&Qy&ht6F%jmIH<^)?zoqT}o~Yx6J=nrU(m+B+E98w|?>vG+E-iMWFvq$<25X0dSGMA4j{$Ei0>uHq3y3=&1sl{JWi3(VP&X9J!^pBGUI^5TCnE^qJfu(Q8+a)xmQhr-z+^Sj=F#MgY~W|mwwXbxpGI<E(B_C6e*2Pb={d+#BV5VI*Yp2Sz+LJQL|yv=-kYy?roC}1*=FoCvc{&m3D(RJf8f|daPNz4;WU_6t40evfrBCjxOK+&Gp6wJ*A__mB>!l#j_3Q*>fWxs*s{teSj56fkA9p1%B+R$8T@yuZ9rLU5>h2A)xOrn%Dge$#1WMu$R@YLk-Cd-*<s+hPVdI!x&2gMn&ufsgN#BXR%!XHCjU18iCn&ZR-=svU}<>j@a?p2ps<K2h^?=u1Xgnw-)8p4LjISsGq>6>txMLtBWaZ6kz^fai^XVM7xVUU8!H11mXi1%aC)s5ifbTD{-avr?j`|n`?@c3vDygoQP-#gkLcw1g@Iyl_>!#p7%nW5+{82rD{XaU|{v%-1kHk!?5qX7+y$pmR#TsIm&&~*3Y5l>IjM51ZIb`Um>p)QGCtZ#^TnyHYfXpF`;;nmeN3ZmIvjFsUQy}@@eAmLTywLWr_3Xm>-WL<iJIk%kB>;x`Fm-Cn=Et*0yqK`h0!(9^d1mrcQGfL(>aFc}y+;vD)%}GZl%M4Uskz^3Pk&;}rBrT~}BDxEGCanq5d|JoC1#m#$-^N)+lGAG1YW79b$DD%RA;I&`4A>de&@$@|PEU_dy)9s9{w4~9Pz>gA26lRrFb3nAT4iFar`|Lik1-Eh+r8}<o!*a~?QIemFXA~qPiZRr;NeFmnl)S~^|?rvwD>}GkoIDw0r|UQ%4ID9C<X$WFeO!bOH9s{+5|k+>I@9H7xgGgh;*<T4oDOF-1SbQP~;ciN`UBN?YO?e|Nkui|52m{5)-5Ip)hqJ8lUDaEQTK-^0x_e|0qfqSOxI)<%~=Y7RaqjQsRII8Nc!eA<j?>OZ4?B4aYo((1*+9GcdIj%~+X9n-k|rV_V8X%O*4fv_%_QhiCS5(vhY>GD@b?n0b94FIew+JQBoOr7L+9K#0~z%s}puPs26?mc@0lyt;-iQGCpp-_(r|D_VL><DQTOFplo@jOu!KPic9N*kFRJ1CN&S7(B@J5vwf72teZry}EqB5(stCp+D^9l;)M5uU^0Vbi4b~llcVt-|wCNI?yV4>+Id}$=Q}n{s3|}indNp51>@u93CH^l0+-`gC3ML)<2>kOJwcm;S{+P9h*7Eo#Ol7GNwm_H6!^{k_l5R;Lbb*iui!qsj1)cKN2iqyG#}fNK`Um9>>I1S!YA6Fu!$<j}HG(`hX1quO&2%gaM%*4jy=-8E6y<Jn6_nib*%lAYrsZPe3as$wQ^4Th2)aqb{k@-Ea2~*v{3`&TA?xury<4L)h>zOO`1XZ!$&G<>I={g0Z}1F;Gi$kj<kJR_5+ErmRs|#&^9x8y^1splxrpcyy*%#pqci79j&Q6-<y_V}Js+RyKD$^{?OUwW|OjzUd+d1K@TYU^2Jiyca)K15VPAwSxiPuK6?;_ke984f(VNE}jLGC9PP&r^N$+w=2Qm)&#u12gZE>>@x*>8>eZK@;9}0VfThQt(XmM2GbZOA{o)pWzwFW2K>9g+nli$i2ek94{&0?5OQOa>_QVmw8k;93aYBbHcVtJ3%!W?CEPUnIq6T^l>otY6y9OJ&thmpK))!1xg)>*^2aI=d(2<F*fvaJ6$VQz!Cb#uhUr+32p$Lg*kTj2NHt7&@xeSIuMKNfI-f2xS|z4}fku&jl_l8Xv;itfulKwHrXaZ9%ii-M5X)gO3Uf%s4y@|WcgU9Sz#F@TU6Msx(rw5Xf&*ZJlK0GO(K^pI(KXy2OwkZt3E7!~h<pX;mEic~Bsd!!9tH>J159)1o=}XH`SKFpE&HvPNpeGWYR0y33^Q9ZUQ<&3JU&k5^@!XH>QqO(^xVUO{a);K7Mb}PygxYn)pWntt>BRj{rmCp;pWh1=cjwW{{s8%542ee{eA#jTqCc576GdxyuS{<K>Awv0`Y6%3*?vKvF^-W*?rL~$t|fp4i7!pDwVmRWC2UpExUEo_|sBZ!-7P=39`h}@h^K?4Vd>3)Uoyc$KrdaD1@c3zNa}<|D~aT#Vng9ur<Qj4GCLIVo05g#L$NqHAbigX4W!=MS#f7eH33^i!e8-jhdrCkrg!t!$|WWoX)R9?*4Y(f0~&Ytn?1%Z8(Y%izCN$Le>-Oq}(gXBJoqhOF(d&fFWAG(y#d=NAdIw9TtE+a8G-c0J+9_+5f2wU@uTVRUojn5v@#L$Ow98S*vx<-xfIuTaK6K{({-Uw!AT0weKV5Yg>XDDcL)0TNeB#%}?=xfN7kJ$Q{7ID<@B}m?EL~*AHSwvIS{e$~GxDJYf7{F?Jid^}Fl!d-&I|%wu}iXgCJ7F^-zQzZ>kGYi|G9Bt=5MASPb(poc#VYCIsoXFd9hjqHE|7<kmoK4C;@g;vio!dKCP<?Tm;=1v)C1ezFFKewQ_dtcOW?(e}_)r94AJ*}tfd6_P93M2YfkuFS-GF^EuN_4$6be$i+-#b4p(e<KNN7r`m5p?ys&mKkB3qzNqWDQ+pjn>fBf802}tQg0bLY~cbiLSmym!r%LUE9xV>3Uj0S1vIny0)wMCBP-Ro?3Jb-oDMPntU8r(DiitFOK6za_=n0`8d|gSATo^G2{5+E634U^z(7-t&p$h-)|gqe!Ur-o*x_@{Bv;X$bIio^D*bZM&nq=FM|HU%MHgXawYrA-me3mnEKxZ%U@fo-=XTv$-zJWxff7l1$!a#&^CIf)Z~}b4@dj&g0mB?EDNaHj%v`Y{@6P`f?aleIxrvN0oLzn?btsZ?7i2-T-aFJo*}D1KN!8g_hw*vdZG2WhB$kFe0=`yU|>2~iC9Cw**kqdI6Vtw44DkmD}~r$joVXR_SGEqvUz;NnKSrZpW#|$<Q$ySqAbHn;jhnI=PG(ci}VeWLT&HUG90Hc4M!4<2`Qf<YjnKmdXv_<k06HEr|<^Hz*3!jOuUaG7$4z5gfod?Qc_5wLs;@@k(Wp+9G*EsHNm@sqql?L?cTu=War0juhD3XBe*>LzD4ra_CB}0^W7u3N&XHq=`%p#Cb!7e@;-|_7Ed_0K$K}|-GRpg3kIDmL13QAcxedlNhOrB+7uMU=)3f=RrOI!^c}ANjE5~Oyx!lv>K1*PuEiGpUVR%GT495FN4C*9MbOT@SG!&>e`oj4JY0fzpJ8O5Hwqw2e9#_^Cpn9kUWd#F-+S`J+io~$Wwh)lWs7`GD<RyLs99zYAQB&M*ds;+(6ZXP-fudWC{e*l9+o#zQi#y)avF9ic|y46=#WaI5fdDn&%YpIh73n)5}@-7QJC_Otw%h9+LQ<9^7~x<1bg$$_A7wr+?^<7xmF#TcW~D1w@O<M!BeJU%ZN7w8~^i7LkW`X3fSKn&l3w6<aTV%s+JM5S|!3P1ztgzqsAXgSf@l-&ZLe<%Z_Sk1p9N#8fF4tw2&X1ja!V@hfk%Z{i>+5k)6uWGSu3d;IfHsGoI7sEDtQVJ|c0|8F@|BB(Ko;hxK=NC3(${(&>$Y)Ra(Aj+1yidH(D=%#fdFRC&6r>z$!?gj!L~YAd^m=R1-dlDtz^3hu+1io~}^2?c^gF=Y)gP6_fiZN;jPt4Jsr6d@%u;u$9#FnJX5+stfxL=JIX22q%WMF}wKQP*<nc5^eP3es`*c5N-P0<ZQ2cU?8n_F9#I?SeL`!mP}mU620|9zozZ;D+_pL14{M0-4=$1|QRfOz^zxTU&@%+eTde>WT9PKcD-qzAsQ$t(bZJu6YGs<Ubl}>SMY#t!V%ub&}FL5bdO+E2Uq^(iIooCe8c6_1o={6z@KlgP`cqJHH!jVFBIo>ks?q^jgM*L#KPc91iegu|(>)6%@vmvik22KD?);q-dP6GiRHBWHfRU{!H-8AHm+y!TY^KvVEKT$G?-ktbxzo4F+WMNh>^fdwhIGwjx`sUmC&N!w=`d?}LN4@6L1E*>P+s7n1vw@aNjbW0F_OO@W8t_<8;A^S0%?BU;n8LJWOrsv;qI@XYZo_%VpwKNZuywXrE`C<dd1JJO!mW7uNY0U)#mGe4XTf?p4gUJLNa-WfgN&mF^b2H5}mu=o0O@910rju_byL!1d>Mn<(6d;2i;39SFL5$H78{_)Y9gSQ_}_s$QFk9fRjeacRv^mWK-qG!OdNbYB6*U9`0Va5YWj^1%TM8DdP=vm?A_A|D;4@Lj7Ez;sb9mxXb^*+A;509gPnJ8b@_{z?~0vJL|X0VD+K-?H9^Ol?7)5~P3e#k71CtMxGdF>Ha6fQ2v)0T+FE$osZotI>N#Kt;)Gpf843$DQZjP*XMG4?qlQK(h&RDqJtzf<W_X0jMuB9YUAWg1)w=caUv^AnLO$Uxo9`G9+#DYryb;4mt#44^E=g0k5tRh#eb_9W*mF~dx)kz8bT87)x0I8)>-lEf@xSJUJYCS`EKzv`JSZ@bGmQEu6oe|}N#m=;8uIjsZ`W5$$T?3k4SRgVj;_xqOiMoxliRRU(g1wjp2LZ@Ly@%V@$yPZCSkj<TpT>md^aw4c81HZ_;{*q%mdw1~W+(A~2ZM=+%zZtcKN{X7+qpBf{i>_+F)U!T>G#3i0j?RPgKTdKMG?z1!)ZNceEA`D2`}-uf$t9JAPUn=?Z%Njds;;=;mP+9u{*c<6XueQIB3j~1c`emZ%o1hrbdq#z>Ml5gk<2tY|C?6;u(-j9Z*iSp8)U*SP@2ScxyX~rcyY$;)xae6mIx|yonLkdr;SWR9#2V+?9v~okxMnECixL<7DD5+(k!IJNJ|=(KP1m9zLLMUzv05Eu9E@{B-hoF|ETZC4?VTjFKhCuZ~SS9YED9AF(_<+f+O96*`VL})c%6jrL*SHZ|5z^c+WVr!%am1Y*?Q8@|dQ+ja%9Z>Y+chu!@aEA)p-VDohH#fa;5hs9-*|AnS@hs{eiQaThHXBD}^}&XLKFDB9O!Ts;-<Ave=A0UF|oz!PGv;P5a5&zWEgBR>a1kfo@zY2deNzJnUpkgvRHG;8r2U%vcj-V@4ug(F&fS{ceN)W@&GDfzzigl%YNm|Of7ag4U7{~}wL{w_bs;anKskf3TVKnD>cy>!HnC<ieXoALoLcJ&>th`XN6dU*&|K~6<n6|njqsot9%iOq;3eJ5iil5x}a*sEZnXS@nyThfI#V!un4e%A8k6WWKTy#@9N<_Ii^@>rrwKbES3UGIV$QrFvNTA=|5?qS||Pjci6MkaxcQ(_jdQWk-(Rsi0LN!hk$q{6&ndWlIAPYZoiWblh}*F@B4plrz_`Q!!++wb|g^9Q|;n59KL4GDHzfL^i&>|Xg!ERS1yKku^e8;<e^oLAOJ6dXWGzsIv>lt*q97K;05gcpo#Sd1cC3xo!R_!F1f;yC$CiA|f2iMqXp0<hu%Ung1B%`R9DoG1OEZ`0GFR=$um(<6Y7(}PxzBApLPN2oC%bCREbwx3@-4E=Q+%7a&rm|NBeC~j6xD%BfX6o^pkH(0@u-Pfm-9dIax2|?V+n0bmujotu8)6MXo9PaH8n*5fyV?p>NRfR$1_{FY+r$2Nch`r=cD=uGrc3<ZkJuJ7_^5~3bY&|p1F}r(Tcmfk4zDwG~-bI4$SYk`mD6>ZV3;Y&6fKrojlNU0#G09U7rK;Zw5>qKP%!Bly44Fosma>mVWZvfCHWUl!uNr`-vdZ-xe9`9-nVqfkhj}z0!?f-FM#d2Ty(yKJ7`0Sz2c<eKCFX`)-wNXz){_n3`)ym?>{xT<H+B4rGf8;2c;H#1s3_zolH^urbJ~={#L|o6*_K)Fx@`PG;C)vL!dt|T7t}QG3US+fQYLPjzfck&X<g=@`K%-kNM{;CY?g3ro>15}h5`K!j>@s#ftR5|ZyKi5!!5HN@B4TaS~ZLPt)$HndDZb2t4adO^}76oQdcPoCCCS)DwQO!6Kai}yv0u6So~7+81Vk0Ad9bNAx&mp!i^zF1@9H>d)drTRt7n%)B;|+(?H%}&6k`gLYV6eAH%dt6G->PSC)ur+og?W$cN<ZS@AisWTw9S&D>6aR9@&WP)^4Rg!vac)-U<^hy*y}MK5}QCoYRz#Iv>aM52B$sdNC3{w##)D1<l|yl$$+?jeq*<INGORs@tH(nCP2jWIWV&I=G4aa+f`#gjG<zVaL{@L;%8)By#H$67iz)T^U3p==t~lUBZh&_i0wn!b;~5n>9hg5Kg4rqoO=JS!T~0#<6qtJ;c2<b@NJV3Uk?RoCeG1%VB{zwZ_npnO<!2us`MlrT_0i&|zmj%CFw-Cs|S0IsIUg83^nF=s(hQMzksqXrd}X;frw@wBK#Ag?VH<zU2p0%ty@paK~SGWD(4fKpj_O{-<!d-ckTMOh%XN88~Xha-=hv-zO`6cQV+(Ipgi7%@iPy-VP^o}tGhd4zX%%tAWIjTNtkq6NM}sn~dB#0jq&`!#sW(GR^)n4K1I;3jZvQmQW2i(9hbx!Ff%1^P3*%y?-dzzZ`XP)8lfU{g!`xo;uC(7t3O76v_N!0<mdhWxqTy@XZBtWz_2ib#1n*Nd6p$p?v6TYjN1*>8+;g^|hrBUM~qaq`Qo3b}+P_{28#nSjmH>6|z;Cp&98zesixEHT?ddSrgsZqAe-u?or>G-Lxib)T)V9i`YCpF<ff>kFnG?RzTxglcXBY&fl2J>khfqZVR_E@kx$+ukL0{$KIDrMsg>YKq#Tbma0@32>3I=5g-iV>Kt-zB|?UGmO{vI}N2R>HsfS)G3<U(-Fy&impB7DjP5Ff-6z9Ghl;Wa!1sR87c|SANWq}jd7b`>J&z1K0)$e;UnXE%EeL9J10V*!;U>FCi=;yq-u(;GWIetHdlkN0jheZPq7HJ*=%)?V~)F4jIJh#*C+pk;+?v(f)SC)LslBqL-rh-&E%f{!)+aFDYc95uyZ1O?27wUW|L*e7^ahUvFZA`So~%WQEt9iO&SH?kB(8H@h;`|naB++wi3}A>DSY(FjSJRW{!r<b0Sby0Utk;DhVUQL@a~CQrG*>mP^~_(pwixEhS>KZtMsLF{s?$(ZPiP4MpFoqD&NTJ35zm+geet|8(KA1*ILFeK<Ke#DNp12fqzY^8yl8A7XcuB5;0QEn>ftP@G@2t0Je?dhA>EC^>+t_uv}jg1%LI(lR6jBT=L5+)8gnOlj6RohbzWz-0x9yenlH%PUH^w?dQOQrXdNVQLg}Sg;@EjjwAUa756mR%SIQv;?*MLAM@P5lXgYJki*H)|QQ?->R8p6-)6gF7#0iwv^JP4_JkhW7Kzy7CFxs2(GBEA?Kbaf$5j`U%TZcc?I)mgQ1D3L@KmV&4#)V3%;CVdF6b*F75B^M{bzOmZL$?^w|bzVEqJQqc<z6W$T)eMjB&h9aSB;Ff`42J9$|G`fvUE@*RSIr_mfG_^7G7g8WOR0!(jJGouP(<ni|j1gZlK0#t0YB+1-X0bV&(3q?Olz+i(>6l|C;Dj_c_(#rBSIDxI~Nx(R%AA^)9hfY|i^fyP!`FJM!t&<yMWi_qGeSXX)S)(pCZ-oq`(e|*geq%@WQdbesG&HU4j@RJt?B>l2Ai8(8Aj|`es9e)uyBO+jc)NM~oaM_!H=I*Vieja$ZSc}9U5Y0GPMryqjJ3FmNmL0=Rl*?>*kR1B*+W6Iu%|{<PW0myGnd=S(wCPENfb2i7XyKA2e+~T`Q3%pc*y2sG`D-eK;L2Rz2|zMjym_oJyye`a}&P#l+%S^`|k$(zn&Z)sA@;rmGx3`B!0sw7E=o8k)>ko3NxqwXe?hEcBNT8CADQ{6=d`uhr!qz>c9@ExGOGw)hnA8yK1SgD9KZEpwdJv{F{cim*cS57nwpUd8&#FE9(J8%<UORPG*I~h~0_zDub>jk^1hiF!S;k7u0CTMo&2yK*~t0kKp8@@_-aKiH`!X)@WYwd5Iv_5nnL=_52qm5p9IGfHBV#R%r!QHl&WP*;qU(swit^r3Cs2QQ2H>YG;Ad?J_Zn2Ps(+fpZFuUAt5?7D;w!q^nN~8kS7kFkj2e%&O*kzPrj<AWZjUeIP@XeimwERyKK6Xkkf^0p+pLk65CJnSXv+(H~PzSXFT-E{3cLyXEr1LSbHGMUtFKOWe*ii`80r*UT4JSZEcgah*z6H3^!$p{F;6G#<?}mtVR<P)=Z?<2tec(@Gx=DWN)TO<bdf=3gXw+&wLO<Iif1hoP$=jL3{l8I+5$oH{ntWhfb?#pz4YFfE|C0P<nwpgAH)-zKXyw?^@+Y>U!ESfcSv`c^bWiKq*K5tEG`@W<t$Dm1W0ke+WB0=Uvl@qEq9ZhMs+TR+oH<y9F*&Ndm+(x8mKDj38FhW;vjA&Uvga?LWn$tu2D*A(Z~DstF^Cpz+VXU8tNx{AS=fQMBAhP;2M!oM^Qxf~?ATNj3|M=o2IRCbS7O#5rA{)xA2eO`hpELT78R*X~CfoQn{PXgdlw{k!qr4H4kl2=S!zqbl|?nUjcEXG~uh;B5Qcd8vYYwp@}RKG6HWT~X?RLy5o5Io|#REe+TSr)}Gt8}-m4o=IQLSfTcr7>B-VcXZXyVFGUGUqiOr=hjr`NhIf!Luf{$08;L%=to#lYnq$lq)Mr2nsOvi1RX8;ey+lmpVz!IY4Ivx??BL-Ab?OngI(#mBK3=Ksemcf#);L^j2$SXggaKr7TTvVK3xWmMI;oT5PXMxFIXrB+#8IC0HB;uUM^_y_lO;MDmVu6)!0@v8y!PL9OC>*>uiXT7JiS7|H`-PK+E@;3Ina_I7k@Sf5l3t2tGT=B$gZ#7)JCS1KUF70H&cmvr2kLespZj^bR1a?+zJ-z&&Ofy<_<@lgW-oh8U!+-g1>oC0I31_e>rp}f|Rb|D@6)aJv*PQN#Nq?zwplx<C6)sY#_V&hu3-#W(hrf`1fw+|`F7QRA6X}gcT#M=~C+J5oOZ`k|%9vxCzx5;ngFwa-w|B{C<)k&q_C<e4*8)VVJ|C)f$x_+rRM0pElT_~tL(*K4?P~ADUUl9!|(f^%-L2}>)o!^lkf!nfnvc;1^YDh`|2tW?vaZbxETB>?6T6xB<y9utQ2|?MhoBXU{0jdq(SYll@BP92#q)zQrsE?|c9IS3o6`0}OHwNPC<1oFy6o#o-HJtFsI(MY)9D?8kPznyD?2YgnkL_7iuw?zPuJ_$54xC;cqFbj9Yvo3L)Xwb4eDo#vQ;uJm;6dp)X)AKD>y;qZ#tryn^W9bRxnWt3O4yYdKrjv0pyxLmMwcuqjM+=2d5sElw<5#nZsaY*p)7KS^<J~(!G1-0)Ryx`Zo|5^>qaiV+Muj9C$HU@{8b)5x%L&lam9w&imk4q8SZd&5})Jm7{H8-8Wd-~>-?Fn)r1fdoB0)tuV8w?FfNmqKXSqbi4`<3(PMGBWaO-tW=sv>x>4OU(p~aHT<+=b4c7#lb2ENp^PT2x{(*msiGEf(w)*lx9f~H$SA#4$c-m9vR$B+05Lky#{01gIulbu>_&@O7V02GXM&)K9*F!Ioiu3d6I16<azrKqJr&|zJU}wbF2;m@Zx@Cw;*GJRkSYMN5&XpX6DV?3&(T79wF>pRO11LI2hHgxwvm+z0W*X7SPvOGcmV={Uu!(J|E`8zy+^A{<XW(QHIOLFTdBHi8jle#j%5%@F(negIaqLPdKj&NntE!OSmNqhfZCwecES+PgG%+j(0Uu*7%E=~6uhUf|+eaa=P2KFovq@7;UD=6CHH4Z5zq}LARs*%G&ZfIb6)ingk(Q^KR)r)R#jVr~t&>sa?0|=gqYdn^r)f|T-?XD#_Lqznw~j`X5C#qnvx8l_@uy|7SQ#P<Do#f$ec88BPcik<BH~T3Kyl=WxkgD8%scx)PPZQ&`{PzYARmK|qOf4B?MZ!ZR48VpRfS0>Te%~=klHqv`$!4Q-F*NAW^a^ah;scOpR=Wjv4^Zcl5-#zMJE^w{$oBL#Ol~BCF=e53S?DBd9^)3`b@D~sqI}O?|e$rwG^9kcXk?u8gZ6Z=dd~P4gm~3<2%Ngjz{aJ#V!8)aoQQ;vS`cgEDe8aTiY5MmwhlxKhLSt7yqly)EM#kWsl`z#i?iZ=;S@lJ5=mX;lsA5OCwV^Oj^s<qXmL&)yYsa8g<&&1V|WAM`Jfp#oS`G3f@TTerNUhmlUFreNioR1;WOPBVSW8XHUo~4F_FC6v(b?b-#xgu6!V2OJUP@fY5CqeIRwiI6RV=4su9x9))r){ut7XQJ*jo6!-QJ*T;6cSU5RLd)Rf?kF0dF9mMFZ`x|3XeLUfJsXD<X4Bn>R+HjH~`V*^-aPq*7(5roL#*59j!D+WHE?H@g_eb<pZxFM??*Qs%I9aX5xAA4s?s>XYjtz~7oU}nFi2;(zU#;CN{DC?L<YI<h_bowDMXD%P>7C=P3yxuJG{?TwN^XtWsK}~(6V^(>`pfy^znrFjwZ>;Jm4g>J=s3}}`gp_SrlX$Qbb}g`PXGPZna=83>Iw;?y6S(2dwN`ZN7}c~B^53sqk~wTvvF%rf>q1ADJ?PS)Rx3IEpxQ~4mERQnmWW&-<Vc&SDLTT)nA#01Ap~_Kx1!!p-yh``h;%{hw$@_YMKy*tbCCg?W`s@nXbd=;Kq?3G1O^-m5eyDMeNzid9uX}(U-;1^tWz+Q)eBny_v0RA8L<7N_o>>-R)?+IrU4ktpRJ`DCX6DuH#+I?ke1cyUXg4yMT<n|J?VToRtdtR$X*fR(?dSn0@nbmRqh40*M)up;3occ_fbE!L+PuLk2lM>R2M`lz!TH-V%0o_?dGIECfY4fM(~LvjV6g+_c(5bCX79^-K~*SzGU%;<K7Pd3GbD@<!GnOUx*;xweGw^wY-T*ER;U!`P~O>W1xN%QCB<<h_4VgjOtfE{jyl$@-<YbcLi_@L0G!vXrqX$ezFRZ>%GJY#9BU7!CGmlxwT+aGL0BMsKOg%q_zGYIDHBdEu=5d}x>b+U(u7jDuofZNX)8cJR9kN-6HYqMYXv3(igBuh(apd9JGz>UBzEQ!9r)Q2@xlv!;@-CXrHeR9c~cP8%ncNsjWsnM3HD!XkyEyf>~y>&lubQfmrV+a%yCZg_=UY@WvW-nQPlJ1k-G@yXWuRz_^8i!s1*&xyI6@u@H2cwAoX9shphaoQ0lF3*;9+3<txwx)BfIq#N?MoX-IBf4%x-`>DE0h3n1wluNT=zdTH`R6!1o=WOiED6uEr`w%pbTuNb8^IU}J<3W_S3)8CfE!9>`y|_IM3c6Bpm}537uaqnn@O!?9evO??xs3-vmMAnf`Ed8QYjF=xdN!@#uLn5laT=BnMY@FZt;Pc`QeG+6(3L7p{rfwHY?)0a51JHP7_@6u0nIX*btf6hPlLy@D66Ujw_Yx0IDrfzKy*Z-1T1ubY`JAj?LWS+aa|yqRTUo-|<A7CKG)?eg~Zbb}h{fzHm9Aa{}c&a!PN~jWB%gORm53fxS<bP%xyjaDhNb7X;9p<eR&+_Q@{_(}UdgPGC2axI~j^meKVG>WcSpJf`~%jt0NWRn0%>d(tnXhlI}C;_7xqJn31!e&CuMaj;mO^6eeJd4px}CQ=fTP=blZKe}h;BhfESV{;2OhF9H#{T*^_`*d>w1au1-$c%2R1-&={zB2-!NupJ+F!3M>=ms%dMr}+J=Qc!7Xl!M8z%m>Yzr^%}Eb+}6TY1FR=(t1%O!l2#CCS)u4M=d!8LOYMzQG|Tvn8b?)--Wr5tXj@OPYjZou4bLYBW4CUF%RHBi9HxgLg?cZ!P%557HZ~8t7sL+5|dy9lZUpclz3L3(ajIPGY$7?hti>-(ws}>rUPcOuUNgdR-&0bX{-B%q!m4yV}rul#QfMW2rg%v{AAGTym`48m5GUF;=eW{|AlI|2z}X#Jz>lot)8S3$i#loK7f2cAfafCgoQcVw)RTIr0t6tWTx_#WZWHuH}|h<$cvd_p6^u6)KN6>pq#Pld>R~bA4->K<NrqRbmY^4r|a){}0%J=N0$3f0wgA%(d>;hgPXuYYSl2jq=04riK1`4cIqvf30KRR_*3fB4!;9x9(^-qwFdaY`e4zbrbbhRD6G5m8qO8;q{O~qD!sRCP6cj*VgLj<dcRKN>BA}XPvgP>hJ1&MlpGJEeu?-sj1~OO}#fMbKZBAE+O1N&*=PeOJy6)iQAUO=+XrN*e+z<<z~I^cMChM_}`N}hE^K~=*z_tzLb8byJ6=orrlx=r^l2cY%#qWfeo1_(QqL1u54AHhdcCtD0iYGZHmb?8qc7NQRmf4p^&0t+++nSG^x?({9U(RUMY_M4`a?OWd')).decode('utf-8')
heuristics = _sub_types.ModuleType('heuristics')
exec(compile(_HEURISTICS_SRC, 'heuristics.py', 'exec'), heuristics.__dict__)
_ANTI_ROUTE_SRC = _sub_zlib.decompress(_sub_b64.b85decode('c-l3Z*%GSSl11OoS8TUp2m~jv0}MgI1{*pR5b*&)QItjmX~gc^%Ue~~Cln->m}}<Dk@@%U-(eWs;^X~(wEtMw<bn+2@P>@idt&{u4#_3F{z<Ic@lX1n3--ky!MgcJ|7e~5;Qu!M{rmUtKmS~UTNo#Q_SXG~wf_6gy@%KT9zXrd{-1yTVTQ^~66HVC|DOEU4=wv%`{&Q^^`8s=wU3AYUrO!&ZuRe;X#eL!`&j#XKw^)SdfR$vy@YFEEHb<^Iw5UaXUAe+s9(mL)JRKAT^Q~r?gG9aLc-es`f7DA?$ESv0+hYaWLoFgI2d1!z_z5zFG+mHubtY;-lF3O)$Xi?XMt^ui|YpQsJ$Q@*{!u%zRd4XJq<?t&WmnD{=&N5CBQzvrN<!JU0?iL2|dw3)gxHy@6{YC1IF|Aq2Q=_P7a%A-Z3O+vM(WVZYCiTXsyu(X}_uiyD*_+eUeRHsj}9ia6g|)>G~}^ja`MDVzt*TzQC0}|GheGfqpI;>cM;sYU9%GJ8WJVc6trXGYW#QUTJ4&b#_-?03z|Uk?F8*jz1EQ$gGi0&vVDG?J9)56Z<Wk$Xv{ueXX1<eVw^;jIoZHe0$dobxx_)Gct@Nth{9S96q9YfHohm)|4{$!yM=at#{x3#)ex3gz<CLBCm3zAbpKkTilSyy8uu#kub>Oc{U%PNf_wXV`8G?JJ`KE)@<9ekCHa&lEu0--*=9EmgtDzW;D7drN?U7J5JHldhmL*`xydpk~0VQpJ5th^ILU5(gK0a&^J>1><K_ickLl;4rb9wC+G7^Z`Y&FAbLJKUYC&XMSH5A+Kf0ock44N`6Q*<3Tl>*nC8V{MOmA(C_O@F-#ZKpeN7RN%|8wVH-DY0!Kymc`o|HFIMAe4ehboJavl{k%NhIQ*?keT8{ko^Bg>)j>38jKQi8bDrGaTZX|%Vyy~}ooU2gmwm)Hfc{E|s88_<`{m8x^lVs$OC196Xl@^87XM`oq3>*&?iGGy<qD4<YzX}lC1rHIM-u34~nl}|2J3C5wr%^j{eZS7O?%g#H8sp<<%doxn&JZ8FVJmV1rq2T`b1ouU=?a{j$H*KDjL!b_1uOqJ>H0lYT+nyOndH3nfN^@W3zIFt!S0R3_?#DSoL`%29cs3mefzh)KnIO3y<36h2;?e1eE%v@)*HscP{73ve+Y51G^uOBE)w{iSSz_*k;6y0vEe)4-tW*bvs}HEsz*blJ-go`1ew(G$+`sih0K#mmb~mu=v#l!B_*L>~r|Da*NvpTqMtCn>SfbB%#=BD8*9kU0b|L41ph|X2y6NHpkB+l;jm$0SenGZMzlNcWN1u}}Ce@Q|LzFHtf`{n*@-kkG^D?t)vb%kV32afY0oTt|Pv1f?coIKh2)7P>D}0N`1A#rTa07lHX+l3ibgBh+?+hBVxINo0ck_Xq-Hmd4tJA=2p{*cH<+F}F(N~j~?q<&H(qbcHKX+(&!FV!EOhDQ)3nwjeJ>D1zi-~B=lBNov*aP@fTX%!qioM>TIW1SC@Y2xE(M-H_)uBW0ShNcU$nXunplkGY>>*J($bFVyNA-M5k|xyswlC-uXui%V)2VX?BtT^J?GXss+vOFKaySPy1*7QLZw_R!ZH4cIU9|W1&yMB+#z3jmcX?ZA?a%s-Sf*1~!t~?nmbLcb9xEL;jmkD3hhKfebB}$zDfbvI&V%a1d(BcPyCJ<h@f|l3C`uwjhT3&=0TLV_<}-8$%}=l6{vGz?v6-umllXHrh56Q}J<=#Up?bO4P?ojba?0K6LhKC72Qwb&t*9^E=1CuSfsH<$ghl!^j$l63@9xrCn4`{gzrYe|#$CJ3?&3@g<~VSX@!P3`O?EOf8@Kx4`M8~AS*Rgv`y5`K<?%^eEBuyIw_P2nt+gt-va;a#8fiWm#@P7t?i(Y2lVC58(kHpwZe6w~b^SuUw!ae-zF8|PWwP3@wWgu%XpOwLuUCigzO_0`Ypn!sz`LY#DG4(Qs$g0(b|Za75X-|yDmvs%m_%f8`rw<;2(GDgJM<w+wE*oGJh;Ew_aW{;Q$Ts@fTk7HArRy~SFJXW8uDUN<xBTE-9`J@rx`Z3$vxR@N(^4eX~Cv;r|&e#NjToEF}n7uGS%sm-GB1xT4bKX<=vaG)ibGT@3G5@H<>IKJ!a$C1YYTPtbACzt7?>OX8kpRo68M6#_Mf&JKj|BTj7gOmJ{AJRy!<HHVUl<Rmq4-b+={r!MwWSp1nuYC}EqPo}$t)>V5C$r<X$Ode}S$m-^L~p^Tn<SrA>2PwEAJngki=w{@wRpKb5W9jtm1{=_%pq`pPd2{%{<id@wqMawbj)Aj*5f5^P2c!@q7VN6_8+Pr>RP!Tt{m%(@ciQEnk1@?H;#Nyj=3n;xLV^`Ht52n0BJ$g7^411~EuiP3?M6@PPL7)gPI~!`>t5!CRaTnY{Qe(Gf!R+4BO40-I=B?pqCv{}0`f9`QxYbm_=Sg|C`YksCJ6w$Hp2?cbHGkX*y~pdIRpUy2Oloewh^sw6-=R0|wXR!F8BDIUMHO7wopsaHpg@~a*Y>q|Q?3iPic)5<8{~8y-$iGATTKzeaN9{RLEurXR;L<07<Ep~Qz?`;6tZ9<vsd#_S;>^q?fA215?_I_5p&)kF^dBC@<})I*2L)+*Q`B`cON7`1&md|G<auT$lsXVZa!>F)Lrm$@*pJN%KPRwOHiD35Y0I}M!WZbcuxEH3^I4}*)ar5HkZ$HbnY|t6<H1^?@nu9E{t}5GAj$HgNjyIl$*=#3F?UF&i*jF4kQ<lc#N^Ph7V~zZ#)|61Itz};Z(XNZz^8*x|}hM>TKK|)sznxkO{*am1oVcO63aH-9GkpYV)Wf_G?eAny!a`$`2KfHnQy7^*W=r=@Uig^7ADnOv*v;(h`=hChO>@kJ5fD4_Zf9iDGhSsr$n>*c`E;3Qii~V9C#WEi3Cwo5U<OYr&(-_fj>(AG{cNpy@X&rPk_xWt6BCS@z`h$jd^WW|D!lu8)aGts&^BQ@7S=>QT%oxJ&b`+MzD*XT9>C(d*&ta6Ue7Fuo?o*?s0x%ZHw4pJ+c25A3IRm(jJ2=i^S&f9{+<C`j*@G~N@1*?5DSa~o%7io$0x)9V(>cvCuunKD!>;d0Qaw;a`K-%9mr$qX0q<~A_jKi78z#M)@Q06U(CE|r<neGjWwZP}smy0%#5t($SYMon^!(oykV$c{R>oc#ANrN`AgO^|~VsGD|;(@*@g=<QLBSe4Dg!s}PG?)C9dCPUyn)f$sQrHzm$@?A33>yuzhh6<UZpm^Zck^H1DgX_e8d9!yO6goWhzL7i>zGag}Ihk<w+5;M-)5Ghdx4AvRH${9!?9TwOpX809SB<PLmVk|HN`ON*q}Br5rnG*YT|Q>teXsjsg64oQg?+sXENamhbjKqoAIusYj5jr<NdPIeUk%2qMQ{CC;!zO><;lvm>&7!ZwfLztQ)VkA@4aqPq|R2)=hMZDb5VfHQE5)ZC#nuQXxf_%O&CIFu41j5$i~hNJ#<Es_2Uq{4&$h!vrk@XT$%gPxY@Rh%w0Z~HtW{Wu6-~Oxm@cio^3VwHPx!Zq;$S>#q2}ZYu6Y^)%cs19M{jUI$u_qws`3)&M$P1EBrd68I_ccZnHLdHTcbZYPMT$+dN#xH%Pxe<4sbfm$MzP-}z5}7mP9&jAP~^kWbk=z6{Ur_-z?0C=Yeigl`0oHuxBfF1Wa1ny2BI7&!5Ism^sTG#=EXeE50$?g{OwU3p>*hMt~v-AZ<c%!Toa$Q*zAquQP4mKr9HYwjDrETS>{7(Q9vR?)6Cn}`m3b?DqCPsOKnP_*L`WGG8LB;}ec7QtsBa;vhB2!~T-sQl=VuDKX%%0_jgFx{FTSgpE6B@=$Jn!5FVpHfV=;-2~s{6gmQd!NKIFrDup+S}M)hHF?uYKRfdxR)S6n6kP<EbPungwvse?We*FA;n!O$Y_n)XP2Z=X$TSNnIcx&t*ZmDBd+<RxgmV7=H4m1ik`<EL94+Fwr*j+Y6$UUprrx2t?<$;I?Ra|%G<~O?OD;VF~a9=5h)*LTfVRG$9`4Gumio$)}<<&uss?RO=6Ix#%#{4QO*16@YGjE%h6uP^a*YY@72lTLr>wqi~_WK*r}l<kOyvpl0CtCH_k<yfO~9kO86P!ze1Aw4u~lvw5IpP4Oh^M>5wZivAGFdJL9z;@EkbZXOpC7rg9aM`GVe!#~p|ZLq%K<x}RWKIT+(k*&grFKst3CZlEO6(ZNu+$3731a%$||3G6D(`<s`@in=b}iLSA!S3!KgNA$tA6n3Lw+ApJB_P`!{zV9D|p<JTNVhLdIi~O|5%d~OACsn<UR8nz#gwM0SpwQ(+>MNfv53Zx`^%hk2WV;bnrK9DuYoaswZYrT3H1pm_9T7dUqz=3Z1J4)TInPy$W=9{KeNsYir>ZjTa;x3x+H#L~Pcm$>T~Vg=PIIchGZfP)d@44>ehNavdKZ877UQa9A4?itarEjtm-^DmaOjjryi-N{NS|?sdrRZmG}ty#LF1S8sw#0QK2gXz6VJo5(#TFTyj&iVRrr>t_YXobYjG$=7f+<cx7s`%A*!{A#I)|(v~ane+<BSW^@*TT;|Xbf**mr8FCnc(AX6o_Ja`5_r+_so=2Y~-8|W@&m|DbL>VYUJfoM&9@Nk~8c2@7O^gfy=y{nMzTk&|7ufDq3VCUM#`xubY^dACOo!6>DPLyK|b{u;^jf-zZZ=AGdW%iLGakTx6r2F_DH`2$!8ccYiwe^SCa=V-r(;(j1?bsXVN=1%Rs?)>oquCJhuI;ea);n%V53TIe7M@I_*ROm!-2>O5#`4a(YZYhLp^;m{R_AqR83Hvg?2mnFfz$oA5DVL#D(Zg9Hi$xr`fO)q&FpYaU3O}8ErIpXT)vAh6OL*CdaBGZ>CCOL^y8SP@**V^e5LNv@cR?ER8m>L@szUJ@uqf{-DAiu+B8oTz_;Cq=XH_j3gubTK%o921ZQ?VzBxn0>CRgl^+S%~jXhgVus}SXUO!1DsOcEjN~&|!^je6tac-7SpER@Vt0hs78Dybeh%NzTP|{Lui~dj+caguB`z>|{XI|F$E8gaYYU6N!Vh7BHy3l++oIDzE)DudUW1#zMKo~6(UyOTtA_s4k33`wrEwX1dF7c_9DjF_Nk$N(&>FDr%?nH_eFfjD;6I~>qCIHqZ7D$Jr$7ve{TXFXz*g1zfTi<h`Zk?eriuqec_mVKLA`86CcCzaQyd8QIkiAP5n&@#4i>3{UH8FXbpDs5nRq_TsUCUzJO4&CI>*A=%4CY3ouCKiXQC^O>YmcTJNKtC*=IUO;uP6N*cZ(N3pIgq|JZ@6)4xEsX|6ByK7A!Sb(}{8zIJ*n_TiY0<>5Dh>#^5pDHJaSvHDM;&o+7u``~&$0bg%TPe(eiPMR+E^Yv<vH?FMmrK$*t4wd_ibR&dap7WNpAdn<3Y1unC*R@r1ftAdY?Vj-7`13~vh;yB(;#c8rdiOXK727H~*fo+*>|134U9S#oY&jKa_2XA|D*b=ikLAlj@#4v0=gku@%)FkU>^+-6)xyxNyb@tm_){@KUvqHH2=<+31QiC@i#Tj3yu1|BH9kBtDTJCz8H>{XA3L>=!<mj>hv$FGYU-%jb>XmIrU5t#pf}8N+cx>^U;)2nV?gEL11C%tOt)sXb4f6Fhz^*s9T~DpM^_;=lwJ|wzZ<_+&0RDEC^Qy)zg{p`Oi`AA3jQdf)(Z=_7D<_eN?1BXJBAy-iKe$(0EL%T|q1+dqU40ATpx7j{vAozfgp&5y18ct+CB$gU(F1~r-X$>HKaXH}uw2L4KyK5d>i|rLs~y@B>atB`MCIJ{^}|+@AD@iveuc85eyjYX2bU@RDumVXdr;?L#jg%Vc!N1l)cNvDz?S*-W_Qfq;FG$HWbqqNgk#n_#Nbh!sf_lVSz!P3`Q^(U)-HY=r%;E;?YhDCLoOh06f!#ImTfWn{4_cseoYA)A55|xwAncvrOo)8k5l6Soo!ey-GffX)JvCMf6O3tHsxPkZ#$ff@;5HDd90rg6wY_1jmo1${=N|0R{6Yew)F9Fw+2?$B_%=rT8@;oAH&1e78V{M^?bOvFW=@^EI^bNyjg{<BdoWwO8`8oF85hPc_)(YyPNSZ+YJ_&-kaW6+?gXP_9ZIU_#5<TKvO=L4B6s`55Y*Ji;imUB=CB8bV7dITh=dK;c0Qt%ay6utssL2#oAbL;I;-K>RvAnjk!I4tkk5@mp3D}-2qq?Y_&Ge?7&dPiN|MW8SE_58l!hcV&!S*@7`^<M<cAePhL;?gaVLgoA-nQ7q*$dUO?lZO%wk!8Z_sc?A+JNZgpqhQRn)gJj-irH=FErzCDIRg!&ZjUIA*qeA#GLg9WW|zgQ72oq=S_?5?{;Ztoe}eL73j;B^aeZEGTafp}i7%eBgA`n~}}so1y&lN*(R+r9Fklv=XS4nT#2YVt4_;jJZGd=>i4rFCmNn69M7F;et#*z>W<xYQSV+w?Yp{pt{K8*quqL=u@$;yb}FRTiXM11qNv^t+f#V&6^jo81~V>I=!31p215o>9gp{b|>jmKx@O!umuD^YXkMIffc8*w#&6mdM%K-L`|`7?|Jz7c0L!O94}0y4u?NDX{Y<Z{TqI3c9hWcEL(<bm~4?5ZkZX4N6u|h-Xv(QB%&R_L?{=qZjTXvovAQ{N4`Ge)J3E0uI_H2`hDg9~PG-Rf>}-*H~nJJ?%WRSL;VV%mY;xArJB*B`=>qFBD$_Ub{3A1UIzDdc67wVZl;U;=pch&${^3)yYV>ylBi=l@b6oxlBoEfGK%x)s3inJg%i(vOjoYtw8Q}AM?d@^BVUQWr5rf-|d{zEZxnnzPEgSI_UWF^h;M6t&RG0r_}_XZ?V`-=p0&LnY&{u>iwx&ywo}=Gi3^wo^ZSDc%y_`5d)+{zjk1Qf_wA#0ECBR@=33X)4$m3SGj$^-FoN3tt{Kx_gCO-N{tJ12Ro~|D@z;s!>@U66%OvhGi`A%ZRi{1wL2yD-8hif{e*KjcYyXQq|mr$2U1R+5QgjU>rt;C<Tj)p51;uaMod$$A(P}G9K`N?1BDd*p6}~}mmFIq4k#9!f8Pe9?)s~R@?1;7#GPfT*DGWRHXF-PFPEi4+qPh4Tg9w(s8kr%-9oW1DGNI7hlCr-hv`_Xe$H2r-JFf|QKf(T0DwjS76n0sjGnxU?fG9p+3@3?gg+holKu+jhMQ;F+srx)!<h+fl}dSZMr-ruXWU;BT_Dp&hw4}2PIvH9r7#37fbDKHT?i!T&aW~5);EtPa})Zb%ZEN=$Z9Keg7Ho2eWy1N`#taOFW=0|wRK7@!{>*9WzaYjy$-zUw2W`}z9)fqcVyk(=?RyCo_HPGc;XjgBfx>`jGByFwD80G(1>K@YRO{Lz13|Rek`ni=XIhO^yWWR@1T$Vak5lD7xd+$jcNUE?d!+qq&Jn~5BoqK^Xt`$yJtp*YBh_V?gz(7kA!fyfy=`iUVfku?Icch>klFT2o%Oh$o532GW;T=@h{S@Rr>R*-*xUo<8=U&ts#Z-;(l6P<4*YkY|Yjq5*@(W_Wf->`&J=7-gxKgXcgz|4&3%8D%_G=F3x1fn)!%oG!ib<$2W_z-4c=M?145(be*2YoV}ed`goHs&%a%sSap4|J!ty)`o`XHq@j(3B&4mY$uDqiqkBAoip+u&G0B8&EK3tlROH8Y);qVay?s=Qhdr6OR9m}_j{t`k=UKVss`+HueC&_dX!h*yo6K{+KFF=%gRR>uNe5L5<NKvr&12tHMzk}gfO;!17Iw4KCBP1m>wNh{+{d)gr56ujI?4O-y<BN6OLAlLgMdNB<@{!rHSd>J5rlZJQT9dsjt;a#GpoK`Y2(b;FDdX{5v}RFB_!cg&zk@w>n=vC?rJZ$SK&UL6327pPU7Zx4UL35xrMtRsE*5J;rX$73Jv<b{eMak)MQVTKW2wr-%P|sgL6t|t#F@%@?*%D_WR%*a0kiHh5R@v=rzzrNR=W~|HO;oB0oI54Vw*qBt{@x-5g_?YB3&1tNl&j9^XxKMs8Ri4;P9_wqMF)WOw6bU)LD`m=miYs7QyCJazYSz6iqhu357O9?-D2!rT3&W_&v!g-y!~hm*4%eX4yznx6^m*>B7TQK)nGHdsqW&B%<CWSKnHo8dZf7mdZo&Nq2;EtMm2h7Di$ZFG`TGcJ}{%Jxf74i9ea>W<hgigR;YI}%J?4ceIl@$KuU*0f7`v(FRE5DrHj32tQfLhAhDNl=Cx|J7Zq@yz(bZ9@)dyIjXRtLKfjSogpHVL(`uWpUZV10a4Op)opR`d+W6*~bZ)!weQ;f`cHk{re@jXw7=`3aCv#NV!&JOxSqqIoc|}4q^`_Ud!G>fIr+-4>;({8)E%T5YM$xR>{bu!Fu}_dl`8x&8u1FmO#H*JA4v_*bt(KyqEZ$dCz+_&^c<IC0(@!3+<R*sdx8MqgyzHj}71ELzf(lkM-&NN4JVK(_OtxOr2w)Ppb?6f$7;GeYN@7AUPQkfscpp=I2KJY+^^)*82Tq5FfsK$&pUe;1l*P<)3k@g$rx;QO)J;8EL802M}2}>&mq`7aIJ!?v~HsXjYZqhvn!-Ri37Y<QC-HQ2ztZi=S`fuh*?6Rr-5xbh<0jQ0Z}{Gc)|TfYR>hWKRbMe_Yi)ujo{=y|V-$#Z3#IZLM3Che7XVdcm(GS@$K!U0ng~jdzV>x${z0;<HstvuiC!X^>rR8Y7FG(CO<Ummd#!sTa2@D3tSh+j@7c0lqGUq+c_bMlgq^3WsL=?px4np&xwl;>AYe4I~uWqk2N$%@>t>+F(Cs=XIcNTt+6@<W~oVSe8CjUY!KUff;Omvj3eVC3OFNDdw2FVi$+(j}NnBEkM;g5BfZcI>;8XG1k$())jlTito`VS<+jN()C~fm)8Txl1l@3b{^s7yD;q@YkeZp@V$pGW5poTo;wQ4>-nIhzFU_Uk@42Ef=Nfu`GgB?*Ikj9yU{QOY{he<TU?)&F9@~_M?nINk*my43R^igH!hcHzwR-5Wr;H77sh(G^QUg}gI@hQTO+Xt{o8Q!{^QK(X}^kWW@9A8jj$uh;kVrF<)31-VNA0l-REp+!8~sde39>Q-0ID(IJv4^L&QH;d9EX(uPA_=e&ie9c|Nm|x$0S!KC5U?c4|~GGP-r`#;d(oD@~L^j+JD9<@Np|9(B-?A8lGCU<5fk`!>zL+ulP1R>Egqzk`eOfRMO4x%&oinAx4eKknTXu^0?t(Q>7khx#ul>KT=njd~5HYOnNjVQ!DuJujpytPQvC>6;Iw*7GO&pU46S*`$s(>+y2Py30y0>>uaDli(8fU+s0uG+Z}2Cm;4(PSpfw>KC1DeT$IM=trX3B4XI6h&jKmGY%T_$}6SO$tPy!;FMVf8;iO%-==|r&O52KEzcGEKBb>t%gXhA)N4~0lHarD(kkb)sIdNyViq#gl)m?3jmp(Kbt|rydH>Z+%V&>Qy(?-~UgzkVQzk7uZkub&fjh0W9|?n?z29F(u;XDmWh}+()Z4YC<2?!J=1xM%>6`k288+RFA1nEw_%tcuCtzLY)yF{sH)S<p?a9rE{PLj!UAT+7$?oG`C0uFeVAX4j#x6oX)o49C(^D<#o$8F&tEp#y!>b^)LR{czX|ot+rOe<)n_e<I4r-fr>8>9iRu&2uzI(v1V|sb@O;%CzcGI1Y%9VKaU7mo&HblUA-%;2J8a`$-H$S*7@)&nE1}wg<_5dzHC@n?M-X7WZLZAv;tH4|Lv?5OdUltYM($^2vPaz{JzHit2&(UsIK3J^$x=xqURg9qo@XLZlzO-yP;>wV}INop~ez$*uY?Dly6LdFh+6yOXJf{+x&|2f2<?nl$-Y<sgUj3ZrcNLK6T{h(l{*l&s*GrkPJrz&M5~#<|6LyjA(X4a6okP@FMmVS|jeB{vUD%~nZOjGvXR?|u4q-PL%;{w`cM5OBY}KDES09r`o=I!5ozf1}24KhM8uSYGlf3g~^qlGz87NOz%y^=|Cxg5Ufrg`=iRF5|jk!%vcvYb4#$7(_c~3|LeYQlHU2V8c*>NA1D@Nel7A=2N7USF6y_cpyU6d<FgnN8m>zCdv<4~{wnwQ1E>dfo%02ud1SM=6Oz2*{XOZz%GF=}p<Od$3yU{>?k5|Ku>XRF!wbHXp&QUCqBZAxqlo#T3F8qsioRVs`z97me>aTg`>CdCzQ(sJ1HPk*(U{`2?R?FLf2X8m-Tl`cbgaQ?1mHNTMG>8OoDYoqFal`1s}C1U9G*T)hDx#FT7^m_TFLSwxzWG43=kzn)Ex=1eC?YtQuwjG^d0NF~rwN-@LD#r?oCRF3#PBFu@w*2IY16gr?e35VV$wLF3-9&#iErQqMby^0mS=mpIEH%TV+k&}DQGiVc^-w|O323c9J?2<^_Z;4`OFJjd1g*)jcTp?zZ+TX<^@hGqzK5t?di^HQHiKz@S)Pxbne=Hay92-xsb-t#_XqVsmF5E2;EBbYqGMvV5pqc>UbaFm!Dp^P&52-0+;IO;>H+Kb-JrQ0NGM`V)r$a9U!KM$eVlZo&VwV-`HEolZnfe!+~0grrgj^pxS-$pebtjsL)cx|8VFP!;XTdo)h%%Dl}g|3^6~HsOpw9rYg!Y;$gkv_-8S$0Vk@5nkwb(v6S?0PaC#;8w^ZEA({}Ian7gnJu4?vWI!+fVJur3jQ{lOm_LS)xwjXC>TVa}{&!~@pef1Hczhm+C?mhh)%E;?);79e>LD<!$MBfJZ>1d+(59zPhkMOP)h`BriD;#%K6vL~e$%}f|^c+fbq&o#&AFztt2leZVQa(?~v$4ulMW8%=f5C44n~d1M+TG<`f1h-Kngs?h`N7-m-Z^|WX|@HI-@^|NGa-|0=T|1Q5Ak)+8OJPa^PSnz{b0kN_wtV)Wp6idP?>z(OM^OmwaH_NAnQk+SoIb*X(_PjT=59Vi}EF@m&irX2`6l$o9vJ2tk>`QUtlv*u8_vIywV&lJs@s&RT6OFK-<Pa86>&*In{2T9oV)_>INZOm*nWx9$x;6(^A&$>0+&v287hNk(v(9hCAaBG~dL~TI1N3hqdk<3}56`U$N^j_Yb6Zs+Jmz$ei!d&L38Hn|bR#kRB%Q0@qu=1{?r+&J_hQT)x`dLoupu&-KTvbIPBUlVuXk)pQlX+u|fabA4=B6COP7HwpLMoIFg6xj~GNJ)M9LGFYlK#%Bj?)#$D?pE5(nSUEATk;qk(Ql_NrhgCAsF6LWr*~`&OY@!)ALX2Qt7aOk%k`&TPT|S6N#4rAHxAn)<hBMB^<-K_#v<|h}$|eidyIcO*F>mCE$B1`%Cb*AbXl=YJr~Kw|a<4w;8q>*y8l)>89aT;^_#Hk=pboiUTbrVYv?NP%2Prgr;P-p)_v1}9px!fK$^$R1#LLA}bCGuRQrCH%bdl}pb*8eTIm_i!$mQ<i(WTr;trnM8yG0)k5}$jr=m97MqT`1ANDs$93IblMmFdYmEr8Ep^tr7kI3R^m-0W}g>H^+^*IJ4Bf&#n_Z$XPfuU#)9It;pMWQzn21S_DYgLq0tbEc>t)3|l^^MyV;ZqUBK%WW74sf9(oy;4y<YR4l9><q{JRle&&5ml%HyW6r0>?E2#1>Cfw0>VQ`8*Oy1O{UdmZNEemYcafJJo8=O)a%_3+p*t2BA)rJ^R)u1;C|(|l@4@m5qNtFV!6V21!cE6QFJOFc>0)f8mni!eAUbOZ5k#Pzprou8*SOSYA8V;AdB~OPt>!)Yps^F**i9m^ci#x%_L}aX*5H%ux%)F?+TxbYq3>I85sn%(q?JqvXlH!S|3~O&X8xuTrJ6Kopi7BD95)~PlYYHtD78-{cYUJzuw~40UD*=j%6zC$?aUu&{wkfmf_F(HBw%tJIJu8qBBkTBO1@a?bj#8Xw#ydmll44`?LZ}atlp@nlYQi&rd>naHcSJ<=6A>%$3e^G0$Zm_@rx9uvh%9dQjwGZ+e<cwGLvCR^ZFC?N!Q1ueA<F0Q&<r>gLtebjS%%+CKg!|6bEdr#+l>qq9{kfR_JQ_<n?ax7p#UhTwwwS$2Bedrqx@gr216`Y9+9yP;C&sM+I2{+dcX7uRR%XA3OrQ@dKd?X__^L9T~OcWjpL5S8AdL3w!dCT5F2S-`Z|bk7u_G;+Rw>h_kU2rc3LQ6;=hYb3Xr#+Pwx#FvkO<5q_YUu$f;jtiv<boAu~Z<O}Lqa|7O#n9XCm-X%QYG(w~hRne-%c`O&bsnejzO$HrmHAYz>c4q6hr5kxaSJB*oj|VOjchQx%|~;#_mH8jZQRK2PgOa6i;?@=Ul9EFzf;(0azco|;6LC${{shpvpx')).decode('utf-8')
anti_route = _sub_types.ModuleType('anti_route')
exec(compile(_ANTI_ROUTE_SRC, 'anti_route.py', 'exec'), anti_route.__dict__)


_ACTIONS = json.loads(zlib.decompress(base64.b85decode('c-rk<O>Z38k^C<__d(6>CdIvRq_!oPGZZMw4ex*$46rr~81`Yjw}t=va>V|qs*H?`%=e1o40vlbTUGD-WkyCu{`h}qfBX5DfByBCv;X?>?7J@?Z{Gj(>H72im%HuR!{Y4kKmY50{{8ru$B+N~`ImqE^?x5f|9JM{<JZ4xAHMtYm!GbG`1t+x&DrAY-R<sdac;i;{9(KOH2A~k?e_iS*Sinf>-)3C<>c${w>P&xoGq5epMSc$egEa%{po*PJUskoG3?l<kMI8U<<s#^gP#3(w%dNb|Ju?YZtw0teEoF%YVu(`44=0*H>Y==Pv3cX+~8HF8N-*JK24_qy?*jCcjjRKj_vq$K1TiA|AxHj)6Mm}EgnhKm&4D^n<gzLZ`}Wv;W$p(@b#M?P77ev$H7<TN8z|`ucz-mEs5*<?cH?YOurki7`RxM(}nZ-_RDnP*ai8AU-!c3n@R836i$a`JhYQBI`!_|^?o@Xe)O~x2OUq%;%Tt#OAli({8czvV8@}UF{|IKTk?+mxPuWJ42GF4`x||>_M=V*ZuH#oemf1Hog#Hbf`J9wz&%L$X)@}7Hm>NPiKp(+Qhg-lZ{k@5L%2U%z#K*MrVrxr9mfxkC+=tTAvbWRac_C>{+D#p`#zsec$W?w{_o&TU7s6%_y&(1-zSTeV>t##Y2xze^VI3dn%Tb3-h!zmLVjuth(0ZNcYAZQeRu!UAGUY*A8$VX_xMccG<fBgB$i0|9W%|r;m#hk$K69mw`1~S=PKVk$hO~$Uj2#Lot{SPx*r?bevK9hFzt-#I55A#vK6d3#W96D0{3dauu~>7@58XSQ6Iwr1WtUy9A!=l{1iQqjRpD?K9G3>qV=e*6X1vXO)ff5{-8>hud;!tPae-d@pIaoUIk<d9|!&9gzErI`_m(>DHv~l3z!hgGHze$aiO6~P_kz>t6!hi|7r5Q4=kv)3TM|11K(D#hw~UPUrqq<$5Zd_7U49~amcP(>5#10568C-4y^p$DYm_(bEzS;IC|5KKyTM3Q-fZ!l|kWFi~~Yu+@+}X36qIh9mHHH*kW|SpYXmA6(zV;Fc>jdm^pN(AlB~(vU+{&>tla|kJX{8HZ#Wwt51J24%A0r)8h}a;E5A@x9>LID|6*EY^CTiCa{#Yz++?$RREA2B9&=BiKMqWvFw6(#^%HI-JiXV^}F#CNP!r;MniS%OL2&XW6?q@u!Ccxk4FkY6NthG{n)Xmx8?>N8CAzY8IDv8g#c`2wCql6^e`x=Sf@PbrzfJTX868=d9LFxQ)ULe&%hfhv1R*UONe?k8(tsV3J`4~%W40+w_mrrHKsP0-nh)zSbHPp^ZniR?z`>X-CuwuQ$m-*4!LiKWXtpJP?KxW9q648Gr&&Ih&H7z%7o20#+<6xrVk=i5vIAUsi7fq0+n)55=T#(*2eL}@$QZvr@?85t9P(F5wEplG_%PGnfAZ90=!<QzJ6+E)$l`~o*G(-qT0)hFxmwAb>?vuG;lV)-D~XXTSdYyG7!<G(R^7w6b?@zBo<f)#2!J1tKu_LmpsB;DwhfaB?cGZ?)LWPYmN&v@%De*PtfD}`2MVH(w*FP+}p(0($Tq)rkb%JI?+<5L+#xPVMp<-q}TFsB1G&BhKn}>!3U%s^)?hrQ^ed2EexjK*Am*)!~oO1mNo*E4RVHnm;}<APi0th>m@+snh4O*Y1B2>L<A-dXi?+Lf#zM1=)9e7bo5P6i^?`&!;C)Zg91(+ixW?CV``)>;FC<u+qtZ$i)8BSGRHrH;kR{cd4UAfv@s@fqBJL0j$uv66B!@`CE}U{Qs@2P;$;_^icu(jbTl;1*Y*Z?e#n3XH8GG)GDyIUGput~fpk~XG&_&MrGN+w4m*a7638By`RgDxnz6x;Q6-X|OcO?1tOd4jXvV0X7S57VlWPzBywTWo$>NJ3#Axxq_(moE0^4VHrS!7HY!rFAs^Eusq?zq->;<^&UArPR&bG_!xo-b*<_(3jNe4|V8Kl%!mbUUrHW~=BEuL^n3&5Bc&b7=qI}kM({>lLh22`hS=7*o<=N}%aw4{PfQ)+;mz5NXmySt#aX>X%U>$?j4id9D0W=IvZ)&Trj%F8I^Vt~7~%~0!<xOcp;hPbb1>;q$tIBrz8NHpy!)0Eq-n08c6+DJGA;IceU@WIgi{^QM`_AAfxjO;Jtw7nKMe7~ii-nSG%0trJOMrPL8DF%x!2_SHgw#Cr{FFUS7u;B%jnpCn)GTbC&k#<y+QZl|zCi>72o`53Oj^{8)B|C>WFT-ObW{`?$PN|Vx#jvP#*pP~qxDxTf+2)pknYI{_J;Ra0kJV4J=4dgpYB{j%g5f*Gx6NbDOb$&3@6^6>|5kHLB$v1Fp_(}!IYq8l)~j`78_?Oy`LcR@*op_&m36854iB6b3aW$?N!-EC%gnyOf;m$sJm(`fxQQC%ly@B4<kU_lHaW~&TGh%9gV=oU_DFeSvxWW29<AVRuf5}g{7zGqn!^tVHb&%z6TWROT&a8Ip<l{O7BROm&T@>6dzb-)O-k8iO(p%cq)#%3-LB$8jLQB*Pl43gH@X(`6TNGV*AYkul+YaND6~Qi#}?OVQNx>LJPHb?L!I7a$d+hx@0*nIhvlpfwCy!5k3{$f(8r7e3>tzw&p-~unzt2NUhrZmC{Lo7L_?#_Yyv0FBq)vs7VJu2wc3AXtDCG1Db&HXCUAi{Ch)ykrYOvONrhT6;wK>Agg69{E>VbaDaLU@=<GRM3S}~9`p`Iy&(Ny+iSrT$5tv>tp;@nk^}0RhfgfbYzU=dYN+mBQE^gaK<KjY0I_Kk}Zs@kI5+avd$$}ki^34<gC}vXu>t5w5)By65mziUAQ#Yx?N&^%|8b9KpH}sI^9Dm4;@J;W9lFHLuAIG}A47aAOWsp;CF1hPEe2W-2ZOyIXk7maTZnn2DLumFY;nW6MrHrDBv@6MSb0G29lp<a&+KRyj!eb3n0zrG1ZypL9SO(wO9{~{I^c4)C<EFli;cOcAghvuX7PgAUgV)xDN<FiSnJth|XcZ4Q!{EfxmICqw!vZ-?2j<zZ#9?}kjQ+RO6T8Gm>5imLG(VJZ<wyjWtRK`t%?BqtL%L@9C~&Dh(nVpa7E}4ARbs!8835B{W5SV94TlA!1<M`YJap7$qUlHwp>=B?qB*qD<eDP8uSvAv(m*6#$(shD%^*&{4KDz1Ef~f=YO|lj9Iv5LhiVXmgtnGPJ<B^lJ88gJCdtP~QIKlF@klVPoF2fjk#CzSU>TCScN_Z8uB+FHxnLrsVZGlJ%#aPb3y}HSj0(pzkOuj}-RGuNQs$J0016Y^uPTMIMklF$Il61Tmd(OwKGC4F{Jm1;3MpaK#((o17j98Z=!liDKXBxZ9f*ci<0P{ix+T5I8-%SuId5MO`0`!U4<arO!?_@oLLN##HZ2>Mhd@(OUgCOTb}-$+E{G*p8CWJD045#8jo`$Rh~+~4%m=B1jG$-xg%@muK0$H{TU?&HS3vD0P;=M;MX<zq2tP2Y{z6XqOOf%45fIY5W(_cH{d$XvbuUg^s;Z2Hi$-fIEn<*fDd(A-HLjheVR~%L(>EB4QH77E?Ug&&Bn+*eDB>{ZdQ#+SHneIAd?e;+rV;=%vh?yG%?Xfc(QT;ah4?tj@ylU*-UhJD{J0AsA*k_77xt}Lp?V%jotq+JE{c4^n`BxDwU6^|Itak0()sNID6)Lom5N&hlGqB;kq{8g<YbySf>x3lros(sRZ2NXobf(VC3YPjy_~nirajDfVcdq$&ugQ*D@xgkRFQ-sP4>JvG;D8J0z+d?4I^5$_`O2bWkTJL2=NZQ9nuw8`>iFr9y3Y&=p@ccoaD}hgQi9T8TUvFs<I)UtO7~QSX%?Eh5}<dVbX}w_{lNb6P{q6dESX|lq`$nG*&f~yY>3I@clSFzdRUyhFa$xeF4QNj5N~^se=)UmQ(Xm5QmG3E@IaiB^eb-m3i-;5gn!-?K0sgV&)Mlq(YMoBiN+-@aTR)62@=Bw|_QLg*Dxw*&q@3eL$k%;#<R`N*~DTDYS~4s~HW*?vi;EwSXfq?~BfT=uuTBqY)KiS`O67%2&tKLynr9gzljF;%Y?%KYX>NV(cVug7F4*?+@W|HnAw|1SfBLOwvlV1^y;V?vjeGXCy_&mrX%*A<!+5bWtS!Xp(QtmIn{o=Oh`zwyqxv71!y>FNP}F?$;bxb|_GUg%Ubw%2L_cmSi`A=s8;qZjy)qa|kxImIp@{17GOXwkDZW)+JE=?z~@pF8EWnJ=BM?AFOU+hlWx&ng}FHvVT4N!1F|UL6LIL23B+j>!}26>Xpg}@zUus#AF<$#jCHI9?fk{!pMnwwylU7CE)7iQ381C1-kh=LIN132Ey|O(`c$93LLx0&W90>1{ZpljMBFkRA@?HDEjbvm4{}b1>&qz^0+=)PVjmmlQURaLb@J?0z0W3fn}+j3PT$XbaM-r9=}Nq^Tk6;DoV~vOYK^am!VPX6U7q9Y)A_J&N>;-M1@yihx{}g<EIOW95wLEuVPnmz$-))NoS_5bhMiBBWhAsrkZJVz=aer4=U+_v?yLA219{F5#Ttlo#;}AQ(9tWl?t`#S~()mSfg?&#X<vZoCa3SdMKmtRTOx+&iMS)f%X|Ubp-7)1NCr1ULrRlom(LBB>>>XT(;-Spf}{~<9YM4Vz-xFys~Ev-R7!mH6**w5X3E3*2@vF73xYfwAg8;wm~B+8${~r^!Gr=i|4X8a<c7e8CU&#lGR9f-Fjv|Q#KjAyD<PHukD0Fzf?`Sg*}Sw5h_y}iNZyr&{Vi7)?l!*Wz-L$oY>Yq03tqml0gW1rE3@J`drk8*TkNJNK-ZbstDDIQCDgFx`bjSIm6sQ2c++I{xew}8L`SB3QGypT~~)BVUY5G_@mT;zii|~^TaTw(C9~ig+?!$eHG0irqO@q24+3_tH!odOOhfXW&ZS4nVO#K2?<0ZHq@}=??3)A)1&2i@3v!V_*2o{fu!1ncX@eBEbhu?U{RV^IRZH&xMU;cmr7EKCzsz&uKCmP8@z%$FV1PRgIa~dHUV-vB4TVKszN5>v{Cn*#g4jX(ZjJwXzR`tZ6ATQOU%*-`{MjXfkJbLA~wb7xwyD%iT4Z5N6EI^v?O3F6F)5Com8!zCpw=m{8+3s*d(+-UB6k1Us!`QD*Bn?C>QDSEL;>h-<|4dL<<U-#8UEjF>77pV)Gh}+a9&UnIDN!tbpvGPYLbkM1=VwHu%XEeSAn;N;*sE(xgU;x&l%Z7%iYQAp-S+>I<-~&E5Q_z&V056ZkI;5=T=>VvV`b3EPE4osy8ob#hnTfncc_Y8;;6)_&N#<{*G`&0}}OMTz>i80qp!5ev3>(tNp9#(|U&0v4<XSXv)$NKQDC>qxk~h;B|gtHsEm7EXjnyR7FT>{u1{_eA47!T)dLngWLQH{~Y)CqgDD(BjhV1O<>(T9Mxur0-gNS?JZrA;7I3Lu}M*lKtK2?@F0Vu^3?8SFXyn*(GMluz5Z}%wp9}@-f@)yjDCbsZGACFHqR21NOZTOU2O&i(GUoQf~@e$p+q!B8P^^?Fo#H`Z3We?U53|m=!{$k1(mfR1i<c9r%KvdPwQy{!~r2Lh?L9DBL1a7c<UASbHs_m<ikp5|8I7O%!U<m@E5dZ%WH7$pjJVE2b)2UV&nNqIW=87ow^F&ro5zPTu=#!7CF%E1Jgye$RL>g@!|@Mx#P#m7293kjYHA5K<GuD#OQ?dbctBF++{z_Jfj;_02(x3KGm@-0kRoZ<?>S)|ylT++lT^i1)(Qr%T(QK4jE8iJ6f}h0<iwX;sIl0CR2{YaQZg1*y~=Mof_^44JDtN51hwDpmu*Dg0^d29Z{385<3x(ks*>IKAsmSvu!yXP<z&z~`@J6~gqLpsK<E7)3o=h0uP_e4eh*O#)wwqqK67g^uMKh2f~N0HpjMl|P~-UI+lyEE4?;-_XlE%Jnidskh_l)s%uQ;T!VoNKDJ4ho*a)0I#pa8B=?q&;y$N!}JEISEkk`ER=inozijcCLUm!!((odT4oQc0HJxTd9_k4ou8lxAb7(QbyShgw5IxbBDIG%OjBx5xghz5lQp8|$$=hdiM8cMlQl9%`0-|wC7HWs0&FtWk6bMg`!`i%R`wy^lyMHNx`*0w#v~X(B)=}<ew`9MeMfFb<94t)d|KW85`oCV<A*1$2*64dmUqotL9$TEOQMcB7hX|?GGObg;+9kZl<6;S2~M`@tS9LqXd5-RX<ZSd)O0A7bf0X0SLNyKQy)|LFmDY_ld1D<z@F1R`7+9C1l%XiJ2fdrlk=}Lx-&v=TIf(p22zm^#UG7Lv<x9ibj)kaDA>*pbf_Zm6BGy)qm7F2V3fEMfd@3i5aL8Nu9v-&-ab^64~b8lNTo``M1^_Os(f3mDJjtj*&o*6<_ttR@|vk15f`kH^kO&}AzxNvS)xzz0tnU#$KhZq`>ZKHjOXJrLwAwfIMD%Y5R(K7bQh&%h5F&~6U4fP^HwRzSJ9xcs<zcMD&pqNgLrZ=mJl{8G*nLQivshA3n<`+GhK#~%F=Qr>}oI#ku07AX!^8gsV1G6ClYi=7Hp;Tg^;ww@WX~uFMy#Vbvh#-!qct&{}-i6PmiKXXD?7^tC~bSs-UUMu-H!@!dZjn5-NHw!FW3@-94aYH8Qe-HO+F<7z2kTsY&Ji<jGWQCX&UN>y0K;CM0F`=~qq%N2{4bf!yiui`|$j(eQ~`wGo(AH4U6;p5o?()~lII9j8*hCbafCFsrPNPMGnhlBMRXaa%{H<}K&jtv>EfD%bl0rF$4sGj>25YZe9OX+h@)YzEE90sukW)n*|ergH0X^3}2mEd@zf4$*`GA?FGv0NOkWiDfi~Qwz>|1+pv7K3jZtKE*mj^3Y|GgYXFO5GlGe!vW-alo0(UT2h?RC6^l2M0uFG?Xs`Md^Kn9aT*fsRf5JLs_8ns#E5qWG0t?=5Q-$x4VOafGV;<nlDSHcbXI~^D4O{%6>Nj!<}r@V{)N_xyF$i&(9#>}VveylksC~tm<zH~Ono~n*5;kr0#L`sTTv&{>8HFLc*Mu#UYFp1vouoHAW|-vR7Nhys<qOZ#v_-b4ng#P4#D5P2*&Riui%xOC|L+vC2B%jFR~DAp_cgCoZzM8pvj_2__iRyszz1J-TbVe=32=%9&5GF3Qj6qP}vGjRXR{D&DO)TSqUhg7nDI+LSG^Y)nBx+Ht^Q4et3^sWWtXl%QD+@mU4#4g%-AAf<Qb&OpVd6g`P;+X+i0rXu%GyHEh+Dh#(iGeaG+7pdt=MZ3v669=+w|J?sU-U@|$4mN_9};jlz6<E_O@SOG${u8ATRnpQ~$t6F?hnY92x@M~9B_t)DJI|R;^P(O#EpU#yAT=axUl0+boX)<ip>NCgbTA}#hcGe&~1+z4&5<82CD&$;im3#h<MHOch_`h!?ZBeE{PNIiF9Sn>DxBsDF*Ie`V^!z}&LjY5wY+b`odpwozZtwNFu<4$e7de0$IzHbD2ZkZoKRIJ7f!{hCKWk)^4%)-l_<n?>{8TYDByiptX6n;!yKHE;vtUQ_>?hP@deqUNO0zLLH<CD#pK@EYCsf%sK2;w3{S*)D!;^Ap<N`T+eri;W5tKm$B_e|pM7G+~J4uL&W`<SSQ@fU&K?e6NADZ}7#W@U_Ry10dg*4Yq;%IC!Wh)5_)3H!F4d6mymR_WwmG~vEeH-@i(mUuAOEH$vkG1NB@^Y*j8-1$CdK2>yDOX*}?CLTj_5@7eQECly=5!_J$lp#jV^&&ijGM^w2{i5TKDaPhZ?w6=K8eF;X;<s26sZW73RmJ%@$dpf`lgn@!f1$g4f1{pOSPUNF*3q4r3t{r&$Rv2jJlmx>?YO>b~~w5D2N~p$`6tOLQ=1hOkyC;Q_1}VIFwz$45EtiDQQKCr&+lI3PTG=Q?9YQ3`<~j56Ehz^fdh{C}#2Eg_dXN##uFm3Uv*Mo>FD`KzBTzv9yxAdgwObF09}n73rs-7#WTOYFtky)O)+igaWAVtz~xG`(^+o3z?N2yMCU@t|UZ81S$^%`y6<h3h8arvmCGneH?YB)XWjCy}|__Ux|$Yu@M_Q6bnlfBI`?Q<eJb@`O2JxTL)B8z&b;SH>|G{I_?!Ec$QdK=Z)3>C-(nJT4I|v4?L)v8UiZ2`~>C|Dc0nKHf#DS15E;eH9{UG;8o83scXn&wEzonHw7gN2)Jr^*mEjV9hDuGj7bxDf;OZ*Ee={LZ6&bvE;}HffrLKCZwbInGsRA%CvRF8D*C&stbef>gHY&=(IWatTuCdMMRqc!HIlr8{aRf*b3-=nstr=rN*l)dWO%OCvH-!-TxU>Kr36THKC$(nBQ~416IfCxjO*sbGZUJO1&OO=gXWXns5?ES=hR(8b~}6#_%muBbJM%2asGC^x4a~7Tx(+6g)fu<s3clx8j9@1`D>S$Lx)Ka;AByJ7p{R@Hg`>$XC^F&N})5NSH_UWP-&w8J6Bh+R<ekNu*6#j+_A+_v9_cET9t%IxRpev+#92k&37(B=&Zk5&H7Q_@C^)k8j=!AZu4HuENABx3SE}P>&79VJaW20*yzSZ>elYhXD$~C61<OL4hHiIe`QP=3J~)`EmCbcn&+;mu*n2QC4Jl;%aI&>^mny5g`noMjTO@{sKrPt)Y*<3rGWm$QU)X|KF@^OhyN>~03e^mb-ZFZWY$E%<&JXY28c0KjA@8K*Z3a1;HBN=O3lW`MJY)iI>RdIJJ;%O5<0Qn?Fmp=#l)r!L~j^2H(>lqqf9qU7@3L}DMMhTj9VDdCiDoUmR+3For+k6l?7?Hv<kOXrU9=c5r%Fel#sYa#Qt|FG3rE6ei}`KrR+-q+g#OMlStQ3Ya`9I<M*)F)<DdM`?%o>2o0jbLSbo~&iR+qP>e}&xgM<Rq%b}aRP8Co`$L36C-*EflrKhOSBq5urk6`#<=ROF)xfyItRzzsWX0CfKNfA%Cg~6yL3o}CVrSPpAtnxAWLUz_k@Pyu7&r{?+JUiNOK_&5$;?|xl;C_8)>(!@kQ6;nm*4b``dS6fgqFNSBJ0Bjn<@1;Ohx00Pz|*=vxu5^%2Los&w#uvF~UUd2#WwA?ESo*2u2DcXQdLsnvS=QoFkPXj1u0-%AMH@mn;+)?v(g8;jq~Ip9;d{WqU440ZxD~#&kyJB}5sPi6}3~OI+*O%VZ7H`J*^>Ebdm&WO1qcm;E!cX+N22ScRvVm@Pu>l8T+UO7GDxI|`UFHWw9dj1I~m_g9~z%gh{IC5T+wvSL_*5QyG2m1Q<!iS2YQnoW=HLF~tOlF!|syUaIr%8G7**kgcRumZ_ViP3LL_a7!J2{K#<@13n=zkGD%G@W@eWlL2^%ya-=S&?8<rvUMCKLo?n`cESnnC6zMMi89V?Q1|QEK8?(%5noZWKdIiSH7<5-88IOEL!OCyCec%3|ej?&@!CZES$+Vgjl+s^qKg3b7qe>0hm`*aQ866z&Tu{sbU(?@cXQHiXocrB~Ry&^Xp&tRLHWu>?Ym!0;-^vPxr~boI~i3F@W2kN`Cft5%ddthr*;WTSr}_skB*GUNKP;Mk@~(^V;6D<;iMfGAG+JQ`JJz?<>IXxbmGjuaTc4%$6Y4cb-a2HESQ1<zYD}BukYoleGW`E9s;>e=-!+CuVpoYLHaX^AkKV+{r||(?#5}M+c8BC`^h(i7zcVlUDrQDiUge=u&MMDK(h>(dP;IZO@G&$wl=Lv~5YYGFP28MqI_@(x^sC%ptaDxT5=|>JLh?Z%z7`irS}KLDjY`PF5ESsJ3(mx~c0pu0f&l;J{54P>x}?y7vtykAQ0&5Y$TqD8)_7f{G~Lm&O3Kln{v`Cuh$!C=Hq_uLGZ)h_2b{vsS&$hmpF>%&anLREQG<hAw_ff@<D?ztjq{)Te_D+6j4dYMofQUQb0^ti3vHDqA7^oJ~(`C={FOdZ~75%9s-CzJ}<DSg<{$5VBl}TxAC_<t90TWX}ghS3}fix7EXMHK&)?MrDf6G~K;<5e79+wN@y0F6YqeQw`5>Ng5(0h?2^KVPJ;@CML21Q-V;X5GA+ycg#Z$s<G`dX%)#dOi4{`Z1?*0`%03CttFFFwL&F-n!<je#ab(bopz>z)D@<U8|LNIG6ZQCsJTcfw7SYr3ak)YJAAuY_`9vZKdP*KlDJQohr(-W;v@Dz8j_i~LAvzUy+3dRIT$7-JsO`f%Wfc50pb#!IT}xv|3mtnR7+1};4x+nvo5R>mq1YMv2G>3f4e0uONmu(NF?CS#;b|cmAur8<&uIhC%r*S%-K|c3p*h??&1p|U3{A)!Uz=B(nw%KL}{WZTTsvF;-xzw2VwnCkSD4TX6VJ<&x_Xalj;xfblGF0iJ_w91^F5v!pyI--U)^AA{B%<9V590fX&OwQ-pRoQIHAemI*`Rn)H@1!n15y2{+}`31*D(ToiS(9*Q`0EZ|`Yj+E&EpPMwb^c6c1;jk8GEh4(8Y41cvrI<J#<btajU`+}?EXF9GRgo%@3Ob~mu87t^bw;EAELh$(iJ_pJ0ll-*xPdm1szN=*_q_^QIT;}n5)QU0^c4>+89{1?FQ+l)#`eK?pd>C6t7Zkpx->0*0sr8|*}FF@^#O1MUP80p-`#$aTji-Ac&(jcXH-1Ns}?un9CIC?t0?*8<Q-?-%ES#lIXjbnZ33Q_YMx8(VfNaJg<+cBPm<V~$W^3gR*u-KmZ74smZNw^G$`4Yh`ks(;glsBH79&GIn{!&1!Xk1yq5-q<*FmCeTHkC)clM+4f0xW%YsX5K!`Q=O6|SS6hQ`>X9d(=3;Jd)2QmSvw}JzTjVM@#`2iN{qCD?Ad9nm8DwN22Ia)L<PUotziRytKeriWVgz#EN#J)JL2oO}A$<O{X^>shPysyV)pnqT)O+ZOuoaKb;C)hDMzSDIGln<n-unfw>e;)oHVUXVd')).decode('utf-8'))
__version__ = "mapleleaf-7.2-heuristic-cma-lite"

# The promoted defaults below seed the compact tuning space. Historical
# experiments and promotion records live in Git history and docs/.

_BAKED_BASE_PARAMS = {
        'weed_replay_steps': 11,
        'town_demand_pulse_period': 10,
        'town_demand_check_interval': 7,
        'town_demand_single_shop_bonus': 0.0006157003847131392,
        'town_demand_multi_shop_bonus': 0.42366855104471457,
        'front_run_lead': 4,
        'front_run_start': 48,
        'front_run_stop': 669,
        'front_run_max_batch': 20,
    }
_BAKED_OVERLAY_PARAMS = {
        'premium_shift_enabled': 1.0,
        'premium_shift_start': 287,
        'premium_shift_stop': 682,
        'premium_shift_fraction': 2.507174265974758,
        'premium_shift_max_batch': 5,
        'premium_shift_min_future_qty': 3,
        'premium_shift_opp_ready_threshold': 4,
        'mirror_max_distance': 34.86886877003725,
        'fert_relay_enabled': 0.0,
        'fert_relay_lead': 3,
        'fert_relay_lead_heavy_animal': 5,
        'fert_relay_start': 353,
        'fert_relay_stop': 610,
        'price_floor_enabled': 0.0,
        'rank_sell_slots_enabled': 1.0,
        'demand_alpha': 0.21164025445907636,
        'opp_sell_enabled': 1.0,
        'opp_sell_start': 45,
        'opp_sell_stop': 704,
        'opp_sell_batch_cap': 5,
        'opp_sell_base_fraction_MILK': 0.12226358671010273,
        'opp_sell_base_fraction_WOOL': 0.19196433115965672,
        'opp_sell_base_fraction_STRAWBERRY': 0.26729391318181406,
        'opp_sell_base_fraction_MELON': 0.5838257424438272,
        'opp_sell_floor_fraction_MILK': 0.46780182162339207,
        'opp_sell_floor_fraction_WOOL': 0.11239281181508977,
        'opp_sell_floor_fraction_STRAWBERRY': 0.07987627492305109,
        'opp_sell_floor_fraction_MELON': 0.41240677828767486,
        'opp_sell_ramp_start': 697,
        'opp_sell_min_supply_fraction': 0.10081480241978077,
        'terminal_soft_start': 708,
        'terminal_hard_start': 708,
        'shed_guard_enabled': 0.0,
        'shed_guard_start': 420,
        'shed_guard_stop': 487,
        'shed_guard_batch_cap': 19,
        'shed_guard_threshold': 94,
    }
_BAKED_FR_ORDER = ('MILK', 'WOOL', 'MELON', 'STRAWBERRY', 'FERTILIZER', 'EGG', 'CARROT', 'TOMATO')

_FR_ITEMS = ('MELON', 'MILK', 'STRAWBERRY', 'WOOL', 'WHEAT', 'FERTILIZER', 'EGG', 'CARROT', 'TOMATO')
_GENERAL_ACTIONS = _ACTIONS
_ANTI_ACTIONS = anti_route.ACTIONS
_FR_STATE = {
    0: {"last_step": -1, "due_by_step": {}},
    1: {"last_step": -1, "due_by_step": {}},
}
_WEED_STATE = {0: {}, 1: {}}
_ROUTE_MODE_STATE = {
    0: {"last_step": -1, "mode": None},
    1: {"last_step": -1, "mode": None},
}
_WEED_REPLAY_STEPS = 8

# Route-repair and demand-forecast settings. The compact tuner changes only
# ``weed_replay_steps``; the demand model stays fixed in 6.8.
_BASE_PARAMS = {
    "weed_replay_steps": _WEED_REPLAY_STEPS,
    "town_demand_pulse_period": 24,
    "town_demand_check_interval": 4,
    "town_demand_single_shop_bonus": 2,
    "town_demand_multi_shop_bonus": 1,
    "front_run_lead": 4,
    "front_run_start": 48,
    "front_run_stop": 669,
    "front_run_max_batch": 20,
}


def configure_base(params):
    global _WEED_REPLAY_STEPS, _BASE_PARAMS
    _BASE_PARAMS = dict(_BASE_PARAMS)
    _BASE_PARAMS.update(params or {})
    _WEED_REPLAY_STEPS = int(_BASE_PARAMS["weed_replay_steps"])


_SHOP_PRODUCTS = {
    "BAKERY": ("EGG", "WHEAT"),
    "PIZZA_SHOP": ("MILK", "TOMATO", "WHEAT"),
    "BRUNCH_SPOT": ("EGG", "WHEAT", "STRAWBERRY"),
    "YARN_STORE": ("WOOL",),
    "ICE_CREAM_SHOP": ("STRAWBERRY", "MILK", "WHEAT"),
    "PET_CAFE": ("CARROT",),
    "SMOOTHIE_SHOP": ("STRAWBERRY", "MILK"),
    "FARMERS_MARKET": ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY"),
}


def _get(value, key, default=None):
    if isinstance(value, dict):
        return value.get(key, default)
    getter = getattr(value, "get", None)
    if callable(getter):
        return getter(key, default)
    return getattr(value, key, default)


def _copy_action(action):
    action = copy.deepcopy(action or {})
    return {
        "farmer": list(action.get("farmer") or ["PASS"]),
        "hands": [list(order or ["PASS"]) for order in (action.get("hands") or [])],
        "market": [list(order) for order in (action.get("market") or [])],
    }


def _seat(obs):
    return 1 if int(_get(obs, "player", 0) or 0) == 1 else 0


def _farm(obs, seat):
    farms = list(_get(obs, "farms", []) or [])
    return farms[seat] if seat < len(farms) else {}


def _align_hands(action, obs):
    action = _copy_action(action)
    expected = len(_get(_farm(obs, _seat(obs)), "hands", []) or [])
    hands = list(action.get("hands") or [])
    if len(hands) < expected:
        hands.extend([["PASS"] for _ in range(expected - len(hands))])
    action["hands"] = [list(order or ["PASS"]) for order in hands[:expected]]
    return action


def _tile_at(farm, position):
    try:
        x, y = int(position[0]), int(position[1])
        return (_get(farm, "tiles", []) or [])[y][x]
    except (IndexError, TypeError, ValueError):
        return "LOCKED"


def _trace_actor_action(step, actor):
    trace = _ACTIONS[min(max(int(step), 0), len(_ACTIONS) - 1)] or {}
    if actor == "farmer":
        return list(trace.get("farmer") or ["PASS"])
    hands = trace.get("hands", []) or []
    return list(hands[actor] if actor < len(hands) else ["PASS"])


def _weed_repair_action(obs, action, step):
    action = _align_hands(action, obs)
    seat = _seat(obs)
    game = _WEED_STATE[seat]
    if step == 0 or step < int(game.get("last_step", -1)):
        game = {"last_step": step, "active": {}}
        _WEED_STATE[seat] = game
    game["last_step"] = step
    farm = _farm(obs, seat)
    positions = [_get(farm, "farmer"), *list(_get(farm, "hands", []) or [])]
    unit_actions = [action.get("farmer", ["PASS"]), *list(action.get("hands") or [])]
    active = game.setdefault("active", {})

    for actor, transaction in list(active.items()):
        index = 0 if actor == "farmer" else int(actor) + 1
        if index >= len(unit_actions):
            active.pop(actor, None)
            continue
        age = step - int(transaction["start"])
        if age == 1:
            unit_actions[index] = list(transaction["intended"])
        elif 2 <= age <= 1 + _WEED_REPLAY_STEPS:
            unit_actions[index] = _trace_actor_action(step - 1, actor)
        else:
            active.pop(actor, None)

    for index, (position, intended) in enumerate(zip(positions, unit_actions)):
        actor = "farmer" if index == 0 else index - 1
        if actor in active or not isinstance(intended, list) or not intended:
            continue
        if intended[0] not in ("BUILD_PASTURE", "PLANT"):
            continue
        tile = _tile_at(farm, position)
        if not isinstance(tile, dict) or tile.get("kind") != "WEED":
            continue
        active[actor] = {"start": step, "intended": list(intended)}
        unit_actions[index] = ["DIG"]

    action["farmer"] = unit_actions[0] if unit_actions else ["PASS"]
    action["hands"] = unit_actions[1:]
    return _align_hands(action, obs)


def _fr_state(obs, step):
    seat = _seat(obs)
    state = _FR_STATE[seat]
    if step == 0 or step < int(state.get("last_step", -1)):
        state = {"last_step": step, "due_by_step": {}}
        _FR_STATE[seat] = state
    state["last_step"] = step
    due_by_step = state.setdefault("due_by_step", {})
    for due_step in list(due_by_step):
        if int(due_step) < step:
            due_by_step.pop(due_step, None)
    return state


def _town_demand_now(obs, item, step):
    pulse_period = int(_BASE_PARAMS["town_demand_pulse_period"])
    check_interval = int(_BASE_PARAMS["town_demand_check_interval"])
    demand = 1 if item != "FERTILIZER" and step % pulse_period == 0 else 0
    if step % check_interval != 0:
        return demand
    town = _get(obs, "town", {}) or {}
    single_bonus = _BASE_PARAMS["town_demand_single_shop_bonus"]
    multi_bonus = _BASE_PARAMS["town_demand_multi_shop_bonus"]
    for shop in list(_get(town, "unlocked_shops", []) or []):
        products = _SHOP_PRODUCTS.get(shop, ())
        if item in products:
            demand += single_bonus if len(products) == 1 else multi_bonus
    return demand


def _future_quantity(step, item, lead=1):
    future = step + max(1, int(lead))
    if not 0 <= future < len(_ACTIONS):
        return 0
    return sum(
        max(0, int(order[2]))
        for order in (_ACTIONS[future].get("market") or [])
        if len(order) >= 3 and order[0] == "SELL" and order[1] == item
    )


def _pickup_reserve(action, item):
    reserve = 0
    for order in [action.get("farmer", ["PASS"]), *list(action.get("hands") or [])]:
        if isinstance(order, (list, tuple)) and len(order) >= 2 and order[0] == "PICKUP" and order[1] == item:
            try:
                reserve += max(0, int(order[2])) if len(order) >= 3 else 1
            except (TypeError, ValueError):
                reserve += 1
    return reserve


def _existing_sell(action, item):
    return sum(
        max(0, int(order[2]))
        for order in (action.get("market") or [])
        if len(order) >= 3 and order[0] == "SELL" and order[1] == item
    )


def _repay(action, state, step):
    due_by_step = state.setdefault("due_by_step", {})
    due = due_by_step.pop(step, None)
    if not due:
        return action
    due = {str(item): max(0, int(quantity)) for item, quantity in dict(due).items()}
    action = _copy_action(action)
    market = []
    for raw in action.get("market") or []:
        order = list(raw)
        if len(order) >= 3 and order[0] == "SELL" and order[1] in due and due[order[1]] > 0:
            requested = max(0, int(order[2]))
            reduction = min(requested, due[order[1]])
            requested -= reduction
            due[order[1]] -= reduction
            if requested <= 0:
                continue
            order[2] = requested
        market.append(order)
    action["market"] = market[:10]
    return action


def _front_run(action, obs, state, step):
    if not _FR_ITEMS:
        return action
    lead = max(1, int(_BASE_PARAMS["front_run_lead"]))
    if not int(_BASE_PARAMS["front_run_start"]) <= step <= int(_BASE_PARAMS["front_run_stop"]):
        return action
    if step + lead >= len(_ACTIONS):
        return action
    batch_remaining = max(0, int(_BASE_PARAMS["front_run_max_batch"]))
    if batch_remaining <= 0:
        return action
    private = _get(obs, "private", {}) or {}
    shed = _get(private, "shed", {}) or {}
    moved = {}
    action = _copy_action(action)
    for item in _FR_ITEMS:
        target = min(batch_remaining, _future_quantity(step, item, lead))
        if target <= 0 or _town_demand_now(obs, item, step) > 0:
            continue
        stock = max(0, int(_get(shed, item, 0) or 0))
        reserve = _pickup_reserve(action, item) + _existing_sell(action, item)
        quantity = min(target, max(0, stock - reserve))
        if quantity <= 0:
            continue
        market = [list(order) for order in (action.get("market") or [])]
        existing = next((order for order in market if len(order) >= 3 and order[0] == "SELL" and order[1] == item), None)
        if existing is not None:
            existing[2] = max(0, int(existing[2])) + quantity
        elif len(market) < 10:
            market.append(["SELL", item, quantity])
        else:
            continue
        action["market"] = market[:10]
        moved[item] = moved.get(item, 0) + quantity
        batch_remaining -= quantity
        if batch_remaining <= 0:
            break
    if moved:
        due_step = step + lead
        due = state.setdefault("due_by_step", {}).setdefault(due_step, {})
        for item, quantity in moved.items():
            due[item] = due.get(item, 0) + quantity
    return action


# Activate the CMA-ES-discovered configuration (see docstring above).
configure_base(_BAKED_BASE_PARAMS)
_FR_ITEMS = _BAKED_FR_ORDER
heuristics.configure(_BAKED_OVERLAY_PARAMS)


def _route_mode(obs, step):
    """Classify the public opening without relying on hidden state or names."""
    seat = _seat(obs)
    state = _ROUTE_MODE_STATE[seat]
    if step == 0 or step < int(state.get("last_step", -1)):
        state["mode"] = None
    state["last_step"] = step
    if step >= 1 and state.get("mode") is None:
        farms = list(_get(obs, "farms", []) or [])
        opponent = farms[1 - seat] if len(farms) > 1 else {}
        opponent_hands = list(_get(opponent, "hands", []) or [])
        state["mode"] = "anti" if len(opponent_hands) <= 4 else "general"
    return state.get("mode")


def _run_action_tape(obs, tape):
    """Apply the shared heuristic stack to one selected production tape."""
    global _ACTIONS
    previous_tape = _ACTIONS
    _ACTIONS = tape
    try:
        step = min(max(0, int(_get(obs, "step", 0) or 0)), len(tape) - 1)
        action = _weed_repair_action(obs, _copy_action(tape[step]), step)
        state = _fr_state(obs, step)
        action = _repay(action, state, step)
        action = heuristics.repay_premium_shift(obs, action, step)
        action = heuristics.repay_fertilizer_relay(obs, action, step)
        action = _front_run(action, obs, state, step)
        heuristics._detect_opponent_type(obs, step)
        action = heuristics.price_floor_guard(obs, action, step)
        action = heuristics.rank_sell_slots(obs, action)
        action = heuristics.premium_shift(obs, action, step, tape)
        action = heuristics.fertilizer_relay(obs, action, step, tape)
        action = heuristics.opportunistic_sell(obs, action, step)
        action = heuristics.shed_guard(obs, action, step)
        action = heuristics.terminal_liquidation(obs, action, step)
        return _align_hands(action, obs)
    finally:
        _ACTIONS = previous_tape


def agent(obs):
    try:
        step = min(max(0, int(_get(obs, "step", 0) or 0)), len(_GENERAL_ACTIONS) - 1)
        mode = _route_mode(obs, step)
        tape = _ANTI_ACTIONS if step == 0 or mode == "anti" else _GENERAL_ACTIONS
        action = _run_action_tape(obs, tape)

        # Shared opening: preserve the anti route's inventory while adding the
        # fifth worker needed by the general route. Grouped animal purchases
        # free the market slot without changing their quantities.
        if step == 0:
            action = _copy_action(action)
            action["market"] = [
                ["HIRE"], ["HIRE"], ["HIRE"], ["HIRE"], ["HIRE"],
                ["BUY_ANIMAL", "COW", 2],
                ["BUY_ANIMAL", "SHEEP", 2],
                ["BUY_SEED", "MELON", 5],
                ["BUY_SEED", "WHEAT", 9],
            ]
        elif step == 1 and mode == "general":
            action = _copy_action(action)
            action["market"] = [
                ["BUY_SEED", "MELON", 7],
                ["BUY_PRODUCT", "WHEAT", 6],
            ]
        return action
    except Exception:
        farm = _farm(obs, _seat(obs))
        return {
            "farmer": ["PASS"],
            "hands": [["PASS"] for _ in (_get(farm, "hands", []) or [])],
            "market": [],
        }


def _kaggle_submission_entrypoint(obs, configuration=None):
    return agent(obs)
