"""Aether 1.0 — current rank-one fixed route copied exactly to both seats.

The 719-step tape is tetsuya's public episode 104466724 seat-1 route.  Both
seats issue the same farmer, hand, and ordered market actions on the same
steps.  No opponent identity, hidden state, heuristic branch, or recovery
delay can move either seat away from that route.
"""

from __future__ import annotations

import copy
import os
import sys

# Kaggle can exec this source without defining __file__. The submission
# builder replaces this import with an in-memory module.
if "__file__" in globals():
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import base64 as _sub_b64, types as _sub_types, zlib as _sub_zlib
_ROUTES_SOURCE = _sub_zlib.decompress(_sub_b64.b85decode('c-mc>*&4FSlBUnsRs3#+h1l#zL_tag!~qo*83gqJL6E@#5KsY!Yj0Oo?LKIafG5o)g3OFB-pGIb>tEb4IL2mrwEtM)H8QRAPjo+Ad<%(>(Z$UF#Nj<XCV!kT{?k9E-ZB1z{=5F~fBoxUfBDxajMF~{GdbeT|J<FDF!;}Paq$m-{k0e={b66}|LOgC{hfsO*gF3GUw{5ik7;tx%|FM;PeS|n2dy`oI8HR0fBqTvpJD#~KY#vC(qokTniDAb&)xBIv{F9|{^<a#BTc07Cw%<cV)!2?J|^CuWA?KENsd2r(lA0&FFqds{I4a}??sc&pX<>K{#?!2^@Be(l=wewwDr$O$Lwg`|I_z>ck@4{{|SRXhcNa2Bu6v-{XGc(#P=Zeug5=!*bFT1nEd_u>o5E0{Mp+_>t_lSnfWC&?dpI1_2>7CkLf)Q{@XGC{^xN5{o|K^|I_vw{a!kO{>Ov=KD1l^UkBBH|L=pp@2P{d|E^a5`b!xp@_O6fk5>QBWBV2QbMAje|NHmp&RszBuCV!<m*eabU79oGviwYl@&dUHd>KF0`F+dT;Oq0LF;LOwn0(1vmuSMLQIe<k_4P)^<Xu<jH+S(Wr-|Kvx1WVu<miwt@)3Alc?uvSWWO;w5<v^v-|t^--HGhjrzWXj)Q`x`K=liGbkS?6T0eFiBYAu!WO~1C$3sSkXlhuT-+XJhJdVl>tlO`B9}L?6UTxsHByvYW?uBBOyX*S-+UKQHO{2f2JuRBZjWnL=jKz@jCV}4G(~z&E@q3J@=9T5@E-~ye0rd-}Q2Ok2`4~psWd^ES#jmDMf??BMy;g$;vESF5E0p#Ey0C$>(C&V9wY@Xp$(kOu$}ez~9Qo|C&MTQfe+5WiRSmu2wQ1yzRbSzC^RRi%xcM?RWp1=RAhkhdil&0goWoZ%-81~zmXYfan;+dB`a(z*AJ*r=U_vigOLD-c_$YcCIf_;@uF9~N(K9<FSq)FwZX<8K+n`SMCf<0Ox8{Ams`i*O#%GpM-d6ww0`A|QLk?JmU9-=I`3+ziL<e{KZ4)ll4ab4E^ibyb%o@w*5>$hpWFhAA+g%S|pH04OH^eU9^)+XB;?6KNE)R0-W=-!`ty$i^__g3r67Xm}_KW*owVsE0seB!*mKgz^_$G1~S9fm9jJGA=?p6kO^2}c4a;bgGx8>c^x<~7c@j|aXW-*`U#tIqCMc*~pix%GRDRwc#xgarQ(!TK5ZD@n+GLI}_jaX-N)(l5r`>vdB!Pcojw~?N{R=x6&(iht7u#4xDnfa7xu~e{#5)iLJfPlSle-|sx<QRhO<+z{j!pF37tO3IoP<~Le*^#ED1_ETZJ$i)u@UrODI_9QW!U4VpD-$btj0WfP^Fl3d)#J1Ss|Vv<^VYpXXCv(e;0rfEyNS*h`R-+<yMuQd%FrY@mJVoC_G(-8J9<s-Letvy<lC!ueFzTn<;fR^aOFIvXES7H*RVajI4)m(gZ$Lm>gasgq1f=$yids51UqWH)oV=KP9+HvDPDXox6gUq^l3l7Qj)bb>*^M{Wm}ptN&?mIC~$U=>dOOQXJdI$#^mX%e(6&WeymV6-70VT6DRo1{In&b)D*i0we#5XrD3c&+%DUiz2jtz6@di23@REqD`Ua%PxA^`Zr80hh}#*CL#ddv*eeU`1y=)_8|k~0?xFFV=rt7B@u-g=R}ndPw)Ac{93*XCGG1!OH47<v88Ch@`tYHHSVf_LC7a^-?)|9Wt43~<Tfop(kKJ0Fs)60ARm+dzSXgv{$7>X%jUzZ-S(WxUSsY5t7a_;*@2AxTmrbfzVv9T0b-<ew^QZE8xjf`cf}_^y^?X0Q0DLrr#_!UWOZY=}OO?}f&3H*)dKq94kRJsr`xkfY%`Ovf3#FgRrUF+}@<esQYXiH-Zg=bug|xgty3{tC2^^1u0>6jblP%+2`^tTFe#Os*%PRYLLvu-NncE<Ap%OFK^$+&gJ;>%4Z;HkKC@n7B&#2@4w;g`Z%W{Q2leXQjy6U+*Kkf$d1Y2!uzb&RzT;|aYvf;BR`F3L+V<nZQikEW+?~lovw_|=qh%Xw;o4a`D#NPCSHj%4|j5#|P@0}%Fk-pZgS{*Fn@~rDb{#&<nWKXx?L<qJ_!fc=4kGckG65NqX_2Lcg7cVl-q*95rlGR~-15XDV9W{oDFjfos`C3*KVkN@RuK!MH2Q_oFx2(rN<=&Mfa=Onr@A8BRcIUBD8z)LC@YTna91Yj|@##K@w^Dsz)px^hX(zNs7VulmPq&{B7gkHr{0#kKJGy+IEzoa=Ut49wYmSGfVzU<8QJc#pc>%D!%Ly=Wp}@QI%>{=l-m%`Tn(XU0*yWm3IX7^luLX50S!H;CxHfbRO{DR<Ug<8@-T=4I-wZ)T1uISMd)dC`@-!6c0D4Flg0v~0nWorx6#sDpj_xuW3~UwN<Gp%o&9mhqT2KNJ0jo0eHhM70nl2UhC|J1=YTi93UfUeL3GEu%oADA$L+2_E{fB$f7F0}((%W{vR{Ik?Ffs71JiYcdPzc$1c_pBInBRayd)19-lQ`k3^Q_7(k6Wz}^ds(;+nTT~dW-FJcA!G75=?<>JzI3^O1HZ0oFuI`odaBjWM4g9kUN9pdOtS``MX*zYHcYVl-Lu{tz`xEBri=0=Eqc}J1teb4&j>ir&QZnO4f)Ql-VU-w+^GvCt1h22m4Z!<AH1l?ki67F=&dcu!?eB(9T{a?11_~+<@0U&>R20KGVb=Ey-(C`oD%jgu_>q|8BHFIXhwAknED&Ri7AAO7=2Vdq$-j)h-5t1}B&I;^E=a&bK;QJ4xKydt6ye;t}!-9xA<EU~`a=ScGN7sx%SudHec6*eAX{^Z?1^xI;b*yHh9HCqO(+3b^7{OAj!4cReUBS8e7OuW05hF_-M=QPQJWeRm@>UvzFva+UYN89LPCmj75elB_!#JLq-O@}s|~<<VrfCh29Zv+ABITYYN@qv|YyThLUF(_=8A8>{pEs*>~Hvaj$aN-M0%+1?`$!Ofe4Zd$K6dd6|%3lY$V9MgkA{{?nwVUcW1yq0=R8E98dNV4Pa!3<i#_X>aM`X8!taw(OHXRG@V<<@GWSsuDEbE@iP{URjirId|k!{#GuJfJoxq0(OE0-UX-0$1A%vkpyfC>GW`fTt07=c0a5XT5^oi%Bu>Zytfk%x~iBSbn!+DxcMAUH1Ysj)O1XY&5X#)XPLYN|y676KGN1R-wjdJ<a9dp`RyWdp?8fACg@S^#RbA_tJ=O2ym}~QPoAXSujHX0Hry;8d2amkr^Yd4cjgFMz#?-Z%j;&@S5yO?tV-{CF>k-p>bX5wER)75KWK|ZEF-ohfP1Gkk7Qumk#53JQwAkT(fSFuqbPl!65frLQURf_wj0zPjf_3*WZNs>RRUlW@X-j&h_aeIn)|f1^n9jTwOjiNv@rJo>&*dN!6-9nBC$I-@Jx&du+NT3hYguY*4x5*>jfyb)f53r{pMWT=4h&bQ!dP&!ZH1MUN9rtOrRT2jHu%9LU`sUP^3im9_k9N8tuMe_2}qG|-lqcl)G+u^vEkN~7(HODdPM?lwl!E<U!;o7YX})NWDqcJvqA$5zwiRuWEoVeNd(@~2jLlrDZ^RQg?O<x{)(Ku!##%Ea3FP@A+@foz;bdU814!;{mVYgOfPfg#LI8Vq^w?Q?21z4k~%gA~x*Ug?oEkSiSBW!JYRxY;9%@k?}0x<4;^C-Q)UuF9(Pd2dnYG4p7E^|=_8T_Dt^U!Xdf8*8R<su}yxz%%W_H32GDOR?1Zp1%9qj=b_}k;x#kr2&3Ed(O|*_2YsrF8Um$P<vl*RB2xj5;o<7@4MMyNwAqw;B_jX(_fHKK6J&SW>3dwmO?GK?A_bb40){EyR?YcO#TeUDt0~kUc~`6#7^7~9PTrS+?R9BLi8LV1_Fl9y9|@#)Ry~3_0tDqSBIaBLX4$G-ye6Rv*b6r;{c3j=r^OU8k53|>t*{v>Bx=T2OPh=>Ha(Bcpc-0=`4S{4w=Y{WG&i$txoa}p+}`;|GvAtcVo;~t0$+(C2TYVpUjxxyi?&Fe8&7`673i1Ydg0-e7eIPF18Mf5Bg;o!)A{X@AM$KUWcR`4XU5kW68K*e32stxji-`cp?H|o|%j!dZ|O~%`B~S(M7XQCyjN5kUJ}eU}#%DL@v`&)gFD@Qx@0kwGZU%>>RA{e67vahwQjsEl(wr0|313OsElL%zkkOQOjFS=)sQEsJ}X&J;U`OJi?t%Y-!p(qm*iUt!QC`^k7(j%7(WXknNbKSv)kbQRf(#NjWmxZ!H<9;{t3ul3N=HOgR~0jSdlj*o2e|5iKoN1GTknAL{yI+0<Mu>&CcUlNMcsSw<GAH1Aiu7Srp_&jfpF5Rg&&v}3zDWt%`I1%et5SEhBR%cpU)#QWROy^c@I+bh0A`d%3KiG|b*&A79d%}sa-f}o$HY1V+b`&1uFwQ#wg4UESe7MfKR0(Mj6>TyTn76bI58}qr<29ega=&4Y_Z@(S5h37epmHOjmyEXC!_(vdOJzi3$k?Xb+dZN3;d(%9`LgT6%UuMv^)3d%iA?HZ(<Ctw+ualE@@31A8AAP#Vl|D5D`Qeibv^2=4r8nhm+=e57y?j_+-lGgc;_~h`A$E1T$#d21a<iR90pP>!mUMjVtV&63>1%p+p2L?sUb*5zJM5_}J)euqtzp^kWARuR4nJK*`fpRP*v@@AMR(19_<WXsOS<}uM?Xi^sIP#<Tq3#^V?TwVVou<w%WP&(_&k9|Vmjmv^wSNv(Bl9snU;mcz<9j|I@DJMrFUR2QF<N{*1`y0&iY{>FX*lojViUeZ)Z#~pt-!b2n${bCo_X(YYlv|3#-1tIu`F8I`0&gd2##z%B29jx7Ojech2Q>`@D`AJockwe~8+6`!JImK;g4#P%qN`>B+|Xd8>Ajwe3q&D}$zRtIgZcq{`pq@frjHV@7%t3hUob8{lzm;_=X`1?>rV-mEcC>92O^c9~V$yH->k)KA{T;djxiLl-h<^%*;}QFSt9R;04GYW$Z(pw})P`*(ITaav<@4{%|pHB>INQEsXDq_Q2C*{!=7rM2R`o}F2)Bh~2A7g=Q91{`%n4>n^`ZzJRR;T_B?Ty658s&rhT=Y<}^<}LqJqN!q67s5_-ehDXWd(1!@T;4jI8pnOQGI}>w2<Rl-L0+F%Xm!4tN1ImPMg?kq$rkl+w6P}Lx8?P#7iSlD2Df}ay7@`zCJ<<Ou5+z8x<Bse(wFTTf-6MMDC2t-il+*39(*i(574V=i=oaRi`(xF9FMC+=t+HWSL+RX>uMOj+FNfNESLVxC$M*|(tFy)20UX-&A;tkZVA<{$^kgzj*+29Vc3}sc?i8vy63mQtirb1oZzR5vMj$vd%pZU0m>#T{N`3#8|v^RNd6#7clI>fx7k&@4!(+FF=}XTeeOwcU+N6sEu)_b-OFb%8PV*Z=~|rI7hch=7prgLd~)O3sb*a!vA=royWHj*Ou2P=T?w^<CS2QAb5lH?D`fgE@-8+Q?m+n34ph6}p=(lEZSc=?OBFUZVRK1<;WiI~jea;#&Y?*wZA(#=?IQo|yrjCt_Y|n_nB7Yi%TImoaYE7`T*mcQu&B$kB{8p*7j40xQK%+E-I<{EnhgxV!Yu=_^<)l#(yMTLr(vJyp0&v`zr<EA{OurvLw=bT$J?g0*`b4_=Dp_YAysYTb*w014~1c`i&Uie$E~HMDTEN1BHU-=4iRE%XLtv}Oq*wm=Ooc95;eVkrh(Y0ah(cFZs$@Tk_1IPP;cTkxL&%#vNhJ)Cn>Ja@s_>HE)~un)5Ww@et=eK8M@=aFXeB>b}`AT?Dk9c_X=Ge?xIp19p{)!mAGfV9*xOB5NIWB&+o`}$t#N~+AB6nG@TKME{nTfr#f%rtNK=7wLG&7Jx?`S<u1`9&8{tsA9JGGG-G&Wc5a>KwQ>6PrRt@vzjxWk374cMOnqQBGSW@pA#1tn$6z1WMUU{nIO5){R<`V}D1_5fV+b@U?PYeAJAxPY%|lF=+Z=)T_;&(TzYIG^tm8}XqJg+<{G<(}nlleuu6UXbI!+ZjH=5WD852E{B{xyrRa}rc4uEmyDysa;Fcw6)Q<sl!n#FD~>>m2|n~$7<jKlaP=Y;{$S(OH7Xug}LUUkTPkgbhu&(JdXsHf#TsX*`js718o9JbZ~MJ4eOl_OZ$?JL4u^4Zm@#&*HU-85#y&DtgXN|6gMbzcr|)FFCuP`+xu25Pgeso8doztng!!5QLnk-fa+FMH;2T^ir!3(%=*7x4b%pErQn2zjIN9oU0MMIEdA9i)PXRAll5Tgj1W!~V-vMR2X3*5>;)yhxv6o=*wq!MW&1k(A1!EfSCrp`GT(UQQq03&I>bV;a_{Nmiy+!a{&4c6moz7j$+LAQEo7&uA!K8R+um3~912@ARUOrgO8sIj>eFA*t6Us|cuHz6J<3NVr-L1%aepT#-$d{bBFjx;li{oB5N{Daz2RFG&U2x^p6>`MDVSud+|KzR-G}olo9~jfU>6cZRe0yU4~Ps6Uj#>1J9siFm@T@@MknYF!QNh?%(FH*-MmBwNb$ijEtM=HolrT{qS%9{@UMzisNYh>TAIbPp-;;uZ8EtG0C?)=RL?SS@A_v!6gXffb$#V`kEx8NLa#*6AlaIsoHduP?qW?aMLKd0u-Z%4MGm<}q6g4?i4!O~is<?#_Z6+)7Jk^vYQ1ZM+7hH+Q$9?~IB`S=^K58f&A!#KMr1{i#)M98L{KXWAp-{cU;!665>Me!FM-FIK5Cyk_lIzT0NhmPp*jBiAT1lUfsPT>Z-rW4Bi!*6nI<u74UXrotLLt>X4H{4wrW9fxyuo*T(2j8^qFXRY?)HUT`Hu}{6KaX9vT*@akgZj>nQfc`+QKTN~=b@?~~UbDR3R90v-6Y=SMhUDWzYteWX6_mTVy_xoK(;oLdu0O1rHYe0^zL^qIW!S@taImW$x{H?@+_g>00@p$8#=8Rw`!S^A+A7`=Lwr77M{MXnsZ6wpyX}m4{ZT%LN<%F*%VjcaR}U-kK!_4rK`<%*GC*}i1I6n-Pw^1lvf0XP4U|lf#dtEx%*KzuS_IL@$|*7#@)uCLtG8wM0yD99#r?y<po;rXkuZ_KVK7_!#YA7|Yn87J!L+5G(<6(+`Y6@BE{<N|TCh6!SrvYE**R`rC&7B;<WqOLs9zMLSX_jfCE#{$g_|o#bl2{yR^JUK_)8OTEv}A=aMG<or8V8$Ek<eG>SJ5N+ikCW=e7f{ku28jD_jSLM0)Dj*mwJM(^$X0E0fQ{u%SL@sL=K_-_hhn5qhd26#e7X-c*X2-6$`@<R`4CV^0hi$bNRFThAza+owpgNYm4%yEo}*btgjf264@nR%Sb@);1=U;8fXjag7&cSEiZ-?LzQe;aRvbD?ew)zEgJ(RYh~sHcDSheo-wmKqPgVNo5Nj;p^!{)LQ$ki{I)Ro~l-1;LlB$Qt(z)5XZ$&lDD{GtUhXyWs<!Z?U4^eEBAP{l)?TQ|Ltil<_DW?7NdVXVH2ZGWTmZ$&EDpue{XcaUUHr`fL7H5g{&3QasJv%eE=3F_o(}5G=ci=EKO${>Zt`_){HbKaTGv|y%_KY?&Te1az{}b4)!5JIr)GRwyMpaXtNr-En^f8rv$YuwaJHY>Mw%VB_(1Va}_OzmyPZMrgOQ|TDtLRO7pW@jEUTJJSFntCvz4kiIsP$)Vebbv;J1IP}_=GzwdNT&&p<lBkK+KS#S6KiAAKVsAu{a4KA3yZf;bC!}gPVt^>IFQjND$s&_msfB4{7YNnNjb!09mKPundIkf~E<3%#oU*p=vnDW9f-~RBdhV(WA=+O`wk<s!4sj+nLQ$|v@>fVWx4a}!9rumB#y=tAcH)8f<OC4acbb*FnYZwB=k1y*lmET;Ry(NL|pIup7l%7##`PDWdKN*+J@#e=n0O%IKE)hm@P<{AaAA1<Ybw7Q2dplX6HV&=8u<G@1Wd|;WS5ur;mWtS9b_k$Y*Hjyy%hsr<cjI%Lek#8d|DLP|ir5{Y&iS?v;6xqesowy-GW-*uPMYcGK-eru&7a`rQ(#qw15~%}433qN-!^V2))*ej-Y&C7(43bfc3cUXL;m{-DopJN7n9ieWy_t<wsZ#SP*kJ#KS?&2E!WLigb4+pKWBt_D(N<b#s~K1F_CzN56%AmLBc@7;LTf@gWBtGq5)0Q_u!xlD@!QB=!I6-*Unn=^vAH#(r^#>asJ_so48KF##dobix7%l?J2+0SYIA>^aVBiO=|(f30Xh~eu#}1+1m=UaMrmm9*5>0nby3ri_9w&7-r3pbn&N$gh-FtPd9bcezlu+OuSjlZHUNVJGM%$QBn_03K0dDN_&7=S)bk9>IrMOvm%jO|2J`mKcV6NK;seEGBmE94v9D!pSxeR)ormRgtm9@tGDPa@Ols}aNpi3;yIaoLd5G&AX$)y!3}Bj2EA}pzZ*@;tBR#+P`lP&5%!!-WPzK3l4A$Ns#)pfBr0azQ*$fAWYHEOK^u*18!yylEj~9#oUnwE+Rwr6Hm>5sZ{mFryH0ED)OjB#@@2ncIX2rBqQhL>VI_$Z`3hCVcOTIf-St=F2~IkK-<B@6?9J2$svMWJC^sun%kt1~aH9@L6OZ|HgP*-=^*F@*cpCTT-be8g!Rh#CX?VYB4?KHUdsL%7gbtHxkOvPB@pscc?-}fA-L*l;j$viU0$_TQ<ATS#mDA5J_2P-`wSE|c=651=geQ$*MfvOn;z?nyAFz^ielbXhR!mVlQVgXpgH{r(-hp}AFkhl$^4A}Rd8~r@y7T<i1HM;bbRUqzym(Z8I$6JBq4{FbxgSaQ+E=ATAH#NR`T%~;pEYwbB_2%uMLPp!y!renO*@C7&9|6Q%~-P@S*!6C*?9MzA(_EfPU1rw{|IOz61#6E);v_0;W6?^*Ebc&&VAcDaJSQ4EBrNtAAUGSt$co>_}U+9B7!^Aav_ZxaG_UiQL2K;3+1xm=!s7fW}Q9^AXS7EQRic6^f4!E@<?CtW~oOC{$_HR|0+<YGstDBFraH&TN3@nPs^{n$a{7dtC$Pbd^Cqt+Sqy?jL*oeZ(d6EBhXkV>%<|C6j1gio~|*y$9t)vujSoX^m;b_&>mt$v~6s`eA+uzUDjuCj&GD0a+SwXujdNJ)zlZ^NriGsUZ+=&j<3zy(uc8^u>#d!{d(iyyyw-jC8kAwCtwI}*9<aiTzLi`eo!%q{G!4PUh1hogLEo}ew6XKE;S-xZ_2}}*r(5*a^p_7vk#+7m%IgE@PRWNH^0E(<ykH6l#|x$V(3KdJcSxNRgOG?c9{l65=cs9UsV#B#&qHScvr|Ev^}pgcizx0sYk&9<O;&{!gA;3=2KCgA&^7Cwx>gryRs0-4s_)Xn@3aI%W&R&4zyBv<r(tkHlFAgV6=>5<yA^EkRNw;;<@)w_B#dVK8FuNz@l}$?3~M|B{%gqDSzh=h<_+$eV~Drl5!aBZ#{iH9{i~EAm1JD)h#mG|G112lf7SQ@X+N$BadP*y{jiR$>gsgc`B#gB))$_o68S)!PTh$s{xQ(7Hoyr`Z}=2!?}Bk*2^-Zx^q_>Zd0Ok+DS{B!xd$yV<8s0@4QEzjL!K(_pfXUx8n0Caf&hb2)mZbS*;3J*FuS3o;$<-W&*m#vFWk#`mvFJ-*j0Xw+q)5t=nTaYr9<t;u}tHrNaHotfSt<`KQSc8?ss&_A2i#ytSUgYWq~~=*<z+Nd%xv-l~iF6CoFuiqN|8qZ4hKv-XyK-a7Ptj!!tyzs{#}b>HfAtsD~sXQx>9RNmu#BBiKIhNjl`_Sqq%v_FB4fz885Z@U|hOY?UAo=MJen=|?KqpdAMmh@k-UZGEGKOEve@oO~kbEC9u&1ca9+}8(Fv_u_c3RedqxR{BQsBTZ$``*S<xOl9nx;iIo;j4fE|4F;0x6ESFp53ZRSO3wL0^!R#x0sT5Y!V`|j5Q=hPQF(lIomfeM~nBgd?&)y$y}tt3{1^6zUrXyNyVq^Gcq_{5bvu&?Q-68s$QLLFZt&%-dmk=_610#wa6Nc*~e`;qt{ZO0{!x@Y&8;2%SQd;{p#tbu8O15_a<M329Q$c^{`Ln&GMma_F0m=ZOrw1b^V-3y=V9Xn7xfW$faBu>~ncrFv`kcz5EFRW%#(k+_<`3IEh`M65fgXa&o>b>O;ZBf3v1Sy<V6^76%8u6ZTAcCg58dw04zO5$n`><}3`P;`}zAk^Fk-kYR9GcqpHtfzEg}@`nM?_2G#;{H}~RPiZs3dWyHc((!0IKS=k(nsnl8l}%Q&K2)jHp;2b^2&P<FJgHZg+RsZr^j*py?cS`uX<Y7sv@N>MD!l$Gl@j{PNU_wOG>M9SP_;(V+mH3{G7R#UoxEWAj*_`pue=BL>pQ$u4{f@Pl`yl8*xws!)=P%~$bzWO<+WcCbMEpr<8gDjZOMN%<cKi+lCeF>`I%d9Sq;%+@cBFNbbt(!E>KyEWFfSJc?snug86z~>kd^n3p3c-w0Wc#8+AAcdtSCM=Vbv>Nbhz&&|9y0{!zPkjz*TxCx&0XwtZ(`!hdT$h{zi1&U#E5gtsQDS9`yMGwvkWSKHe00lqVm>YYo*4OrJ}wbe-DKS{5|_LtNwKSv>OCvEq(!A5{`V}TCA4fgqcbZ8i?vZkiBjtdN&M%}MW%#G4V`j74tsTl2SV}P=NqxN#-dq@^>8g5W1*m+L8-(eD2J!<1+{}+B#zF!Z_*=EA7?AIA48p9o{^X<FuKZx~xt|HwDsI;@Y*m}2ut;O|_y>bQ=1KCubtIKNB-Ar3s(bsN$^!Xi#ro{J3@wN<$6?j==+1)lFwrp3b&W@SyF{c`y-K}1qT`KiW751fFq>}e|44k{_{WP~(94rkN4zlXHK%eY!^+w;cIyrWzwd~28*EClzqA@EFzUx@92LN`7i_KPfJN4-)ca!!lAjyaqJlueboxhw?N)w-q`nst`3dV@ji8b?HIiBH%6TXr*`>?Y~`cqa9RIxzc5QIe!R4<n$hMNedkS&xx_Pmd#%g3~Xz0NJuKV{J30V2-)GgOZ8S7_AE`Arv}pIUhD4NB?{%Sg2?9j>xl>6kATux)vp^6jTmUL`vU4?a80P>Wemo8M&3>g6_c(ev)pZA;>%_DY%Y6^<yA3zVx#LGSaL7-1W3H2#7mf($!N|Gny;W)DQZv*KN?yi3mu`jSm&?<&!IBVI(g8GWMiG&w76JhOjObfC32)2YAU%gwS2x>k~5sgXW=-gbf`xtQC?`o+~(EP6=}z)s|c&X!}|=JpV_rDcEHg3!W(g0>BQ^!2Q#1Ya#>ypRr0@FBF5mD|KN^oqXi8Z&!5!pwP2oVg{KR)QWM$yuS?E5vg37VJIqdCq@;YwX|Tc<_AEMu>tNTWbA|TEKW&<h@ICfVPF;<LcL){i&VEz&#bKVU<ls+?N~z=uB-eHKZ%%-LO?Zke^4oDqA2;mAgimW+CyMTxOeBeSbeG_xI@L%D6n+>X=f6Yv+37#wcHYH^Xwky=$eoXsOz<TGp48DCXL+sP}<VrJH9bUK>UTX;o37jZ|gmV+`BXYMu&DBAXu4PrW<>ML=!0Eb}gnvPn=mwwz?}xRsY`XZCGg#6HnvbLM0UxBlT8?WShGqEb#Km*wX)0h$9@a^db8Wl|)VfZE$$IiItj9#&IgpKq}Js=VFl(-qho)8Ta`#tHY{vvnMDeL$rS)+`)lo1$l7%cNy=H|u$Y*`|U5p1XrNo<C}v>Vd9vt&VF%rI1#RzMt=yg}zERg7VO+qsjvY1)V8~IGz1u_YLsd@O1VCV!GKPs(zb#{nVjsTwmq1{(^4%`Orcdc^v?-IbJC(%JXD~&c-s^X!D$nU$u#l{jk7fdniC~1Q&s>BZ??F16!I4Z@>IB5l;o7J=!x;S|z62Nm~J}E($2EgvW@P{ki;(PLi{cbXKz8k;Ln^2_rM(RfWV;Ivix!@Oq-730)Q2R0y!EQLE41>T7#n^XiizM8fWYZ>$>PxV`?n`q%#jYn?~T')).decode('utf-8')
aether_routes = _sub_types.ModuleType('aether_routes')
exec(compile(_ROUTES_SOURCE, 'aether_routes.py', 'exec'), aether_routes.__dict__)


__version__ = "aether-1.0-tetsuya-fixed-route"

_ROUTE = aether_routes.TETSUYA_EP104466724_P1


def _get(value, key, default=None):
    if isinstance(value, dict):
        return value.get(key, default)
    getter = getattr(value, "get", None)
    if callable(getter):
        return getter(key, default)
    return getattr(value, key, default)


def _seat(obs):
    return 1 if int(_get(obs, "player", 0) or 0) == 1 else 0


def _farm(obs, seat):
    farms = list(_get(obs, "farms", []) or [])
    return farms[seat] if seat < len(farms) else {}


def _copy_action(action):
    action = copy.deepcopy(action or {})
    return {
        "farmer": list(action.get("farmer") or ["PASS"]),
        "hands": [list(order or ["PASS"]) for order in (action.get("hands") or [])],
        "market": [list(order) for order in (action.get("market") or [])],
    }


def _route_action(route, step):
    if not route:
        return {"farmer": ["PASS"], "hands": [], "market": []}
    index = min(max(0, int(step)), len(route) - 1)
    return _copy_action(route[index])


def _act(obs):
    step = max(0, int(_get(obs, "step", 0) or 0))
    # Farm coordinates are local to each seat, so a seat-1 route transfers to
    # seat 0 without reflecting EAST/WEST.  Step is the only runtime input.
    return _route_action(_ROUTE, step)


def agent(obs):
    try:
        return _act(obs)
    except Exception:
        farm = _farm(obs, _seat(obs))
        return {
            "farmer": ["PASS"],
            "hands": [["PASS"] for _ in (_get(farm, "hands", []) or [])],
            "market": [],
        }


def _kaggle_submission_entrypoint(obs, configuration=None):
    return agent(obs)
