"""MapleLeaf 7.3: heuristic Kaggriculture agent with compact CMA-ES tuning.

The compressed action tape supplies a high-output production schedule.
Observation-driven logic repairs route-breaking weeds, protects inventory,
times shared-market sales, reacts to opponent production, and recovers value
in the final turns. The submission runtime uses only Python's standard library.
"""
import base64
import copy
import json
import os
import sys
import zlib

# Kaggle's file-path loader may exec this source without defining __file__.
# The packaged artifact inlines heuristics.py; the guarded path edit is only
# for readable two-file local development.
if "__file__" in globals():
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import base64 as _sub_b64, types as _sub_types, zlib as _sub_zlib
_HEURISTICS_SRC = _sub_zlib.decompress(_sub_b64.b85decode('c-qx{YjYbnvgmjI3LK_Rh2teDQnuwpYo<z(X<HRp(v|4sWK}w&5jm9RXvm>whI(wu|NZs@&v}rPA6vVwt&NCjG#ZUYqr1@nn$70%RTidqK^`UZ&LoZQ!nv3Q>1~*cU_KF9Fb(rZaT6}nD9fX9CZ<U$J_L(6JPd=W*y;Y%Z8SzVp-7Wu9*R6zgd&=Y%gb31&AW@o%S(|h7mGLwGZBa^Pm}qzSft5hImRYMHogfb%Q)<c(M^;!W(ocfH_&zrHF7|_2+|z?3UYBB&X>_Vj331$T!cU#AV829$QIYZEZi0MVK~X!jbyP%=HWaS;lm=ymTA~ly^3awV4SysNa$*wq>n&Nm@x?aHH((BP8I+Sc{GdW*X;(f0ov*$(@qu!88n%O<K!+(AG^@ad^rcGtqhQc++AuBXiw%qXCTH2H3(b)M(2%WiWFyn{sx-8N#Y6gEfM=4_Bz9}zjKF^I2u1fE6Bpk@V+yR(kusdzlWbm8jXWk%#$2CodfHHWZhMG9n3|L0c}WR96V-B7xv>G%G2-;*fkN;G?_Ug`MlA(j&dY;2LE|E-T8U^^R@?ENzxqPfy#6_CzdA*0sXj#Aqk-gaTSbjuYlcB26nnTjbM^2@~kV~gmH+K@1dt5u{Gi$+v&alO77DLD#%d`U=(Hxk_!Ae5APXaV-ii~Kju(?RNREKzr&x{ZW?y-FhlggHL@yq>xtz&kB~+8z_SzX#5@er4%EE@fuD(11~LOe3H|8Ig7FQ=))vU)_;!&*^Sl!$<69J25LFNl<SF290OzlxIq<&IkwY1z*sUB#BnK%9;xr5<kDa?9jwS)NIt#}j(NQ+b+B6J^CQj~w_6`i~Eey*evUe8ThSWg;QWabwvq(5@!*GG+Q7Yo(IvRtBfkdHnWewzD4s$l3*#KqXLms9;Ui44GCH4*vJNtVlXE3h7p<te8URMlJe03|g^W>_5b11{nc{6;w_wjJ#pX{CPeE^XJF^jSCG`a>Zv|u_0v&@6W#vrON3NV?+FoCvk{&j$_<D14+2wDR8k7Ay{1coy17ocxtVJHf-1}NGSO~%}80N<7&Pxv%sRRNT_WZ7Rpa({&BriSGzyb122ByA`zwP<FL^kS<hZh@FY(`lHZhH$0V16dh@C<r-u#B@1lO%)+`SnohJ)Im{(?CTH@ui!UmPsAUAy1IsOZzzr<6F~PtEmU5j6?U(?SR1~LQScrR;Ai;P21SF|U~<O6HI}{&;w<z))EYD7BBIAZ4IfY=zz>ZSn2h7Dgb#T?L0#SOPfmx!4<{r4!`}b+`-jIzL;uae*=X-*e<-$ue>yze`%{-75YJHPEim~1!f_6~y&;A3*ljeM%|-(>C`=}h*8HZ?_yMQ8;3ArysEJt90^5PGNd)Q=*+u#WiN~1=G8Ims@@;T^9fy86zl&gHm_cu#T^NwyIuxx-s!{>cg&$cLKfs(@#yC3xm!!)n#z_lRK{CQikH+CHiD&}S8q*mk3mUj-&H{H6AXN+0k;yUxs;^Npkls*AF4ROVDOtk03;K*&6G-!L9Sd^60s4LxWf@9Nt7)s*ou&tK3iJ*No;cHBXP}0bS$BAPdVDIj07LV4Rv?ICxQH@fr<ev2Fs`XoCX96~;$Sj?dDz<SZSQn?KXtaZQD8(!b9|BFRQN%_kBl{IkW2NMCrey>L3N<^BBcTHcSn@-S^}Uj5TFTDRHZXyvQcVN;Hgq)z<_&JkF11H2g~6AX@Wj?#c3F@{6bp^AiAs_*Vpj>zwrNGvebaYM9}$wnVPf4$GHm@!w(?xvjlYiI81X`1)%li98C@q$gL|>;s6h1{6-CeID=YPLSL`bU_x^U`f!yz0H&6t8CGW0=E!-}*p{+TvI&|2v_%`V4$bU%+Tp5zWSqotM7+L_a?*Q(MgmzYbtR1g5TY~^F_3!X;jqmCOMa6quWvw?NIqu7Z|p_@D_T0kaZk_!n1pv~Ms>yAb6nm-GMGTt0gsaM2zX%h5veSY5de**`045qmOxM!9sI*yPH|qT`6~L|=iA*^g69*^|6%X+x1mzWTW9Z&PtLY@^7|ln<8bTb^Z=B~+r#7IQ<P{4f6xOZ4eK9LkR`nK({Qp}vX0Fh<4*GZ$BgJ<Va-rJrDTFB=2K@LeM!8J_2krVd6x)_*shX12Z>6i#N!Cr%Ij<ZE6nem<D<hrr9L1-K(v^qF*6`g!$AX&Gy@t*0!=!!kRsHLbC57xp{GDAOp?b+O}AX242E4)ql0hv53r5o(oSnCSYT;J%m!hD!Yo;)uy~^>nlAI3HVMXZMq(hBW<OhmV_2EH-<YySVHqEYzZwGm{h(}bxp;J9SjDg`WQ&l1ni9s(ZeW0XxmGrJh5Xm=_S#i|AiimCzyNT&4lr5RaAN1DYQSk4kap0(+cizY;_j18q#&Qyz(sR^y2KUB|CB!h@OC8_xHUel@4j{)0QQB1okeMyq|~OeF6`c5rzNvNn}KNzCL$Wqpv$;EmiqL&z+1yu3q&=6?ExIyFNj>*Bm>aIAX<|MSp}-9MK(;REeo}XdL`UA`iAu9?MeXuCJgRizRx4jh5)@&26IP#`_)fXAoiH=>}+c$kqQG#EP=Uxy$sTc8WAY=sn}u@u}D@-Xz_u0gkBr0S?MBPX1Geki~&axf0ZTJ;<N@TNw0WW0aFlM@v8T-2t;z|j{^fK*#WEi%U!hPJK&AYz%I$cE$%kRSeSzPRq~#R7OwMT6WxH@15-2ruLSK(Muffs=oSC?<itN49v=D!qajRl&^-YgD~sh7c(>%YUM0yb+Nl}Y!V#F+it&n)a`VtQn%84=FR)V`_R@`q1@?Qf*IB6NtN-EP@HgH4UblirHuN9I$A_CkpN&rU{`eK_w?CoITIdf$u*DVf3TPIvI>P(w;0vU$g)b1l7QR4!86MW1g)6%|y^`Fb+N1E$qpebj8&Vcv>6(#S7e}9#(i&zY>WiNxmX3ebQ))ne2SJ@!-+wB82Njj4V6=s)f$G1~6p)x@aRRnRFuz4%YjF&zlc5-T;6+Ws8Jbzk6fA=Aqqq;F>l+s4Cf1R26i{SEjX^M6-4Ei$O+ek>HvPw$nSqtwfq5H@qx_K^(<xd{q?3$Sl7;N223G(<b$o(oc~ZZcB1iG`G#wUzJ#f!^l>kQLyz2j42Cx^XpDPg9+Q?d&?sl-h$zm%{?&qCxh_)UWWMI;D#*gEeXT6Ngao>GZ6+VFg@*tNQ;0N(0oCe?pisQF$L3(aO=@BKstdu+y<>Ie!c!_FixTvuW+pN#`(R`BJBVYREk5|cjnMsxd!#<<c_uewk>%849^oq6|x7Pgyb{aV^+D=!_9^30}j^3nb;E^$1a1@mQvC{{bCdnB6A7HTbYNbqJ==c8Sk(os%v-Y9esL`Q-@Uw~BZ5VTZAo@M{*RcEnENe6z4?<gm%|G4`_eM&*{%WG;#9uHkMDw5re`?fFfPgQ0_!oH<K1OVysF{5N5k`|lmV-!NhdB-1PY6w&($H~oO~9($g5K_ZmZQ192j00N%+U3`p01Z=y3h*_v8^Iqpb^S+nO>CWdZp<a9e>yx9hd0Z>DAG--FpIEz3z)A(Y2%La#j^h7n<KSboHM$j;|`lF~S&cvt6RAZ_(wfUYf4$m$h^~ub|6FOo^`TDt<9=iLU1sUBh?pj2UOfaRpt^x4&{6H<EkD`Y_{IFJJxb?Wc_6&KHiOW967}?5&Wmm)~z34Zq$FPe%ub2mctJI&$B8(tI==*k~N<_=V7)X}O^QjZw0{?)^5TiK+gbll--n`n`~yIXU>pKlXgAEMd=C9@<*(l&buC`tfN0y?=J1lw|>R+ffaw)}MQ)M_`B^pAL0HG{EXRt{wZQ!@UoRm~$ITTWGQh^aG>!_udY5PtTPeR}g0(j*mz04~Dvvm53Ge+r85d!_zaL$B@X-y^@F>*0?>TWna!wkuAV3$#^g20eq<py`d2<$~>HCnmlZcWVj3$>Dzf2w#BDq00s|ummGcya07|g=qT@sX=~((0j#eW&!M1Ss&-owamj*l2`*DG=a4P#f^j$umV8{~*-!!xZxMDI{`-TYcSHZ(-oX*b&QIN5qtTdz;N#Kv7Rp~+Jha7Va0Gs#w@XZV0MJ?R&_XLoJg@;8O=&X)DO1wA3oag5Fwn^o1k5uYF9ji<RYFNKRYKvWL>CKNRgJ<#-xUR5C~U#PEB+>`YxHrt7Hjl-^>uh?nGNzA+D0P`8IHv3f#{iUcK>wY5_tCjUd5<U09itV_GmmaEMAHZnh&0M_DpOy9JD-Ic38HB7PGYj-sUi2W)EPq*?dbOfFKu^)z%fitIbmmgHFvpgboXX2+fvp(8b*%#I=A9$$dj)f@AY}=Sa*2!J(Q2(8W0`OfDqr5sE-<a>0mykK|8aui46f4d8~mQ;E!I)eHR%yi@zD)Rq^(Q=(!^i#G^1{Lj-BIVv<@u)h(WXBIG!+p#$-Yld+amI$*Hcm-jO8h<Kbof2V&NgaX9j;yH#`=MnGGlJ)>G+E9kEyC-86Dg<tsxZ5joyu4`sI@iGbREtoJg3XKiKMqK7eM-0G-VZ&lJa-!@9s+SnwQ+^jiU0ngCZR#_IS*O;Z2aue`E*W><@OuSumwqxJkE_-A0RD-VNi8wyd<90nSv&!Hn=>5l7(N$LNgSCAZ<EEm;*%+6?Y~h0`g<Oku_`2lU1f`)zu*Jz>*y-Iggc3l=4Skwsn0sT&wGrV7$=_6D{VS%Fu1f&*7gv_-2DuwBq5RhXsOGZ6F#^9TfvB8;%UItZ*eiXihlN?CyEf+o1>`qq}%Zretj`Si^B0zY4RuD&l&SFM<7{jT{0yf8l+a_Yl$ZCcX+gw)xESCMyT|GiTBnJkrJ(rx0r_g%l;9!d7@jU4zzkKXy+APWo79l!awKf=#ECKM~)`}J@LCHZm@hb_M_u9(K~;o##3TuO?@898&d`G-a$RiS45U;p&?jt)NT9ir{q+&}&U?PUdg_I@}-n~!Tj!Mo$*Gqe@SV*T9k-yMD&`F{)#-n}0g+u3n!ar4Lcl;F>`wa3Jtq?-aBg5&4)yD!_8@80h|Z(AXTK3A2I5ECtQd<!ZDBKJ?(v~O)}ifW31QOq5#kL=NG(d+;qs0+;ecslfdJ2-m7z$bfWSVGMmgXs)l|L^18o726c5d$0%vLk{xW5k3ElTr5e!PG~v{_}>f_67HkkKP`<`*^xHIygR}@xt{fI|<V_0qu*u02~+_JiAF2XJH&4V1)3FHh|QpeTo_uK5oAt%lnY^FWDk3%1q*IPm|!}d4Cra{>)hUlE#;I&V)mX8Cb<9K-?r6=Ph?fQ!SIFgeko=o=`dzZRC$(MWJj8vrj8Bn6p-nl-h_TeMH7O{3cW;_Y7Qt`#I@-uPgRx3#O2qC1ggHN;tq=txRv*P)>-U1(s>xO0dwmYP2B}$_$jV(cWlCJ<p_DB2$hC6{SMpwoQ)P_gNk;27?}N@^j2ElWQbpm0gATeHhLqIeC)kMeI6GuE3=9Pv}=Yv-xXxxj@P-8}qNv@*C0O2fU94Ali&6ec072Lly?P())c&d;1>_FgeF37Mvs01xaWeWVitlVko=Q2O%VL2SdGoeQu)@ff*?93(f1#2HV;DgSR6GSv9uFGA#Zk)D|kv;#!ZYhA_%9t8J-gHFSJ(a(pyA8u_C?PYes1%lYjbCSJ4g?K2tnQErnf%!7>=n8(oKZEj36qYPur{R8m_sl5#sxy*`D5~uTtF>z#`NQ0-7q!XQJLR&V;T%q&6dCCKc8yN8|N^EQcncx>lO=7!T=*eWXIK%8!z$o>W2ugFEK6VkOjf_PeN>Pst@Q)zRQ-!ICengvuP&=(S3volE#g)npad|~6=DXd73n#md3e@M#y%zsRw!=Tv)Rw=j$t&CVOB2<c2I(xsut5xVj;uj!P+vT(e~#<YS@Xhco0@36)8@-LRb>INVQJ=bF;0COH`is<7v6=1m2E5x0U4~TFiH3Vs?R#20`sW_vM%`}``>3DH*b*;!DkrDMI1ba813s3uAYqdpqnXlfChQO@Q7F`I4I13=R~lDk;(xfkR_?JX`ruiz5_L+AzzC)oVVzU$1VS5dV(8$!5G(`Ru=tJiTF(rqwk9)WJ5c{+@h}?0h&ksg|;sKT`n<jE{vy1kh^(62NJ`*bi@xS2VyKXnE}vt^&PH=17WkC3xQQ2r!1}#Shk0%_jZ?KGwev;@ffjW+_nXI6(sb8S7L1Q{-}-E>!PKfwLES@`S5s{!X80`z=9}`<s!)<PNNuzbE=44Z|i9V6@cI#%p38{AeS&a32dAkvj8h4_f>iZ;H{XHZEHqK%qylBn<P<O=%XZqK9sx0qJ{%yOCHK6RUp`Y&oj;+=>3PbO*{@sI9~$2XbsrC@|;*6)fB%BNcc5JsR8GcH4+5}5c3V9`7$(-8;J$uJ__MEA-gC>5v>J6fr9uWm)h(&c|?g#n+FqhdkqD^ibrT2WmQ!>CpmCR`WK!}PYY{#Ox9eD05pyTtsX`?AEl0vV}Rx)l|R_!=Z_cOIu4oO)f48HH3E{Gm6J;L#uf!6)cOsqpvdl<Q`{YJC<PM&xsws|B#jEa1`OlP@Shy+?GKyu6}e+UcqmncL8SP_z`@hMa3GMq=uk^8pFg;t&B+$aEw(&5?HOBT+Bqh7?=wwcB*b$`o7%@_pgWe>A~n*iVgCYtvmUsGL2A-M=2k{|GEg$zuOKm%QbRmQAIp$w_-V-phgjxq9&UqT0s5;3;5n~yeFtCoFh;YpHF{ixLo`g=;&(KL=<iLbw8W?-gFCZm-jZUj$@Q!-u4X;j0G`*j#m$a2SGK9*U$m11-*QTVQB)N6Cz52Qc5~XehY3q>ww$%}de<f64+P$Gr68Ck%XyAfO;?cHx=Eh6ZEB$;KwP`bKiw>E9H7qBgxD;h*gT@JZ43?i9UPTob>uLMW>FlZ*uyP-{_y*F6-qU;{Vk=<5qa717O6@EGJ2hVf>M`T6jG26P*qAvUMJKFJ9>+qzP9)|$<wC;Rely-&jXyyw1jIz5HtKM*7vfRA*~E_R<Q<n?M?;$0&70+iO%!2hL2`ir3s|^;z>(H*X`oTy7{DK>XYJgV#!2(xlLmyfK;BV7I06;3WRy*yVfsme2fB|(V`bVf+x<4Tu8IE^^Bu_U{a|79{yPf(_sj4IDFHTi``=s#*@tv%327NCieui+8A@==d=JpC93Oqw@}ii!Iz%HITT#%7Ii?u;<1*F4fX0cO>j32){~Z5L9h_lvZm*Cmx~3sw*|dLD@>`HTzFPg#09KWjaIc4mCy@EDuGQr+Erb{@^b{c5PusK79caM2Ex*|h7tnuaZ$@G$FZz<x%=zsVZhZCSukHi6LA(ODoS@PZCIg#GKC7QEt(d!2>7#wq8yC4Pr#W^F{psX0#AJ_HXv0Ne8$zXFJ8YE5i5(fnB)0B$Kfz>b22{^fJ9>B)w%@34r9Vd$CVM>=ou^?a}j*AV;0;&sw{bR!CK%8l!}d)M;!6Wv0sC?9Q{xWg+5vW4%`$Rn-tTj)#8@qG&lR(UEEv?t}<HM5b#`&2&khD?_gt1yWF#oz|g)TBo+oWXn^5=Z49Q|>t2CXNUW1HIbHyX3$>Ur9y3U|+R_J!$^N31D;SyNKVpjcHEn+BRl!JT0!?gVpAlG>#tY=o0`07Lah~iZu*7U%V3Gb|yE!pJ!YasX&;=RTsav+jcI51KXs*}&iSz~04)uF7{M6lksev`8Wvyp48F17B7@{j)J%hHm!p{FQTC`Mm<VeM1_%(KUD+Rd7SY2$Kd|1s9x93hZYKHLIey66ig&m;f3Oj{UJ07Dv$>`d1%CZrr3$8@rQHTwCNga_h=0ZxiDe#=w8{yW$)EJCRGeJzS@QHCf>Eg)fof9EYVaFaO6a8#cQZ+?a8G9KUo2x;{0F}K{*LL{IY_>W`F~@-wqpJzx_0d1Uc&Ey&AVg^Lpp{06`;N_~_n!a5Z5?YVwUh6raS}Xr#r-0)$ueX#(^0$Fbp29HezS+jm@ih9M#1;Pdt-3COMCl7<OUX7iD-rN%juRFDoK|!N5Pss5l~h>-M5oU2}8q#ErY^R*Za?wOWWpBXEjSTIbyVK><|Yss9fLC!G!<~M&GKUOc-xF8gaaBt*F;GU1+wTwEeS>Cntx0`fpATejlEi1QMAaVs{iHaGuE)u|IJr&Z|0AVW_o=Ju4r@0LXj~%0VvZTX_gC8wYX7YLuK??k$Tc&N`<vh2S4>Spr5G?J|~Elx}Z@CZA#2(V#FjihEdKKk^q(<v>JfwyKt14GJ}ZT58bE$CZSlZ5d4!_Ft4`qv*GCCP~F&e2Wr&WQ8rMbg=;|adHyo;W#%u&mR|(*SP0yHi7Y%_^&~ENnXJ`JW;7*DxnN*RI{Nj!~!iFEU%sB>$d%!1K15c*$kRr2I9pAXu$gM*+y?xWXsl7Lya^E(g|iAxG*@)db=hq0s3$K`urV&f2ZLhcm&Q*u0j4eQvpnGnKL63Vz~JG1Onv^4*p~rws@1dEd#uKjaW3lmI4Mg7)HS^%%T#|qQbQ-Z-X|lr9BBS&eo4cN|QrvSjg>fij>oRRQOwMZlIObw2J#wOeR^QE;et447k$vMPdC;Lv@iHhnaP4yW=(ZI|Ea_0HS(V3qm|lh{`$rwTq$Zh8URohULq=8!Rv<MY7V?Ht^9+U5cjuJiPa%jI}6>iB(Bk;H?>tF#X4Ly@IP*$Wy~CC;ai6m`ine=`$%q90fJ~A|RmK!7Xh-`gU$rz9924T-ZGzpzkpEK2SbTM_%;f-XkLLqKI!k<y0cr{`=wnZzsnGGTRYPWxe7(60hMTi%Es_#8k0%g_+ZTGM3K`JJYP5lG-%03Nrdn!=UXAc|!?j+!dF;>Xl82UA5F#q~ystP-!9-{>8!UY7!Lt!c%A^Pi1mpWj-K_xjp01$*hnVwmadw+(DO<NVa=Xn0e;IIaazLqo*7UKxM?%hktTjc_WOwi66vqYrLpvo+F5L#21WzHUF7ONE_lUU^M%LRa!x&4axg@HWrVHEXrD0DS<vgR5q8J+F9UqyG)GaL5h}y?_B$1=PnhEMU)*J>FTSIE=s0tVAe7{v#PmnPFFb#gzg@%4``_3&q9vO$||o5H7p6zpfonBh$IS``Pb(a{n6=!RT+ouV(^+UD5nn=67w1>Hpwxy#O++On5|{HrdwQLp;c^+tF3gIlc31E5b97!<H<a8`K2-h`N}E0o+9&MTB*A*IaH^tiJK&i{)wVT-BYqRd5~*77`hTdi_Ao)LAe;qTgRHZ46o`KsNa@hT0n6Q$S*1f%@ILt8?9Djjl!?8EsBL;iAHnoThSCnqRttHO*Sl`#<@@?8dxKU<=ce-E?1L0Uo*4YqLO3lXS&Y3D#P$)E*H2oNTaU`CIJERR_O~~Oi-3<mhnwi@zuJfIImWbLmoWRVb+~pJLT#+0>;qgFc}97>HJWIf2kdEzBzSJ7ly7!&PSHy?jEg}c5AEtvA1kB&p{QEt6v5c<5YD6oN?e$09@);4(OBAp`29wiKy%MR$(_@)L>;Y?m9<wqshEm?Z8=c*Pf&5b8#kfCUvK3KI??wG3BLle8udtNQPOdyKQ+>T;?PS>&{AzNeb?H8_x{dCrwx{)4s;jG_(>tub4Q>c-Cy~k%(~uvsq~KGzwzhl@%!j1sHq8X_>5W!R?)wI!QGgz{?QbvEy<#)2ljXz`{_a@Cr9BUTo;V(<N@|sI@e-oui7JmZpxd7xq<_Dc&MmtS?izK~|JWpgL9BU~v$<Cbg!|Vs4rdNhiu>yrfjc&eCuPwTkCu)7h}J{Ef~qlm|jzk$F*p59#UK$I-1}eO587`WiW$vo5+4Hzg-t%YX=FBwNB>(s64NO-)S|#W`o?q(+t7E67BF%Q~y^Ndo~oi;=sy<$TsS8OBx(5~6TId95MsLOS-T&4=^de(&OmX1;4twiSg{S7tbijceV0>loA9!iA~dKBUA)_zDrF?fwp|4H#G2-g)6Q>~nrk4k@iW<hOB{=L_+FHsMQoHS0Hu0j)R&S#<EfB;d2IUos9+K7v^n3M!BEzaSD+cX96*M1xB7f2Uv&UwDD{cbGeWTh>XoXj<4B;uHV`;EQ;i>w$}ws#=UzUMlP!f~%>5P<HIbT&~POwc#5}tgB`O@4ZT?lP4AGqbhn2R#m79%+To@4e{l1nBG@~VJcP)Cp@yw9ceq4AUFY(f&<BCBfQ2_dsY=JSwF1nefNqRwpWMf)~Ul<xsi?9J3BldJ>L5%$FFqopmcw>6*(A)62#iL0bS)jST&y;mgOjgU77(1({K%X`m$kk$)ZA=y_lNUs4#acb{O4*yoETFMb1UN*KB#PU$8xD%X!1tu&(X8k&7=6D9gjiYY!%Wk;jj&eT8paabULMs4HuRyC9+i>8=4x$go0j=DW_H?pjR<A+ecX!T1WM7YySvd8Wt-8zffHKu3?+<>HaEYU(l7fa^we(@1y84{^Dt+Phd2Y&K^6#^yWDThqY5#6&+U-P3*bC@)3h`?`TFzG+*?i@L1~P7tg^SDXVTx}f@-TlhcFV`%s=REFth0p&yINyYtnc%6lOd_X-u)#(sbz|N4~O&TXDKC6VO>*IJiQSU<OdnLy~ikF3V)a8(L4V(v@q06uH8+;-T?~V+CHF1bHKLxpd9%u|-vnZCYT+sz?m^G4s4f{AB^RqTl-fj5y1y#bmuSywlQAV*Vsr;OK4Xms}`dT{3{H1v%v}NgBJEe#rIq>P;c2-U{S!$iGBH6wQfo$q#Cz?;2a_aI)T+AU<G<fBcc(xj-U3E4+O)6>W$&56!&9o{c*(e^RCTO)8rSA@Sthn014twef74c0w%4N5twYYUPB8M>i11H#}Dt}rg`N|NPUvWEHsb$Yb9mCX1i-<SD0*b?I%r#1)pugD{a=QKK*o|8WfpqWx0zOQXJ*n=E3fQc)vM}*xD|du*&TVtKkC*4W=Kv7QJ}5~L<@`UoXG;-d4_SdE=Rz)wP7oIOk8a+N<h5H;)cfrf$f~aLY70jCLb6+`?SYnex~1uclg+6+yNyDQI7zE>*&KU^01SG@bBr?;k5*NSNBpUAJQ?D$Xv^&^4u5M~*%}I$eKAYl?5Sgm|5ayd@T&(;<zmIHXZGlr9-9so`%`Gx7Im(q^M+At*?P1<kgYli3P+<(`|1D*0jg;1CaRcftX9DrY2ELvKEFyKYT0Mif=?i9tT@b?k~wEWR%tlURY(D!x|R=`u;EG<61F5Z_2>ycf6@n}ZWxC~5~c%Rl5C<-&Pyj3IAdfJI)dUpm*V=^P8SO|XDJW6?!A?jZnlFMdh7m%v8cYD@VjK4q{%%UQ*UiJ$=ae5$%AlQ;6~`>IXLabnqzRvt&2)ln&bT;J=F)q?C?7Pb+aVJEkAsGBpi&=rF3j?MEIr+yh#ioG5ys#%|Z>-IUwir@Buer5k(cLtXR2sj<?P@E^4DW_A6feOwLA0R^_L^RtnZv?-zgdHvQ{0K6@!0yud-niLTYh8*Xko>bZ?i#u4fG-*3IsS)EH=Az_$T{jYFOk82-=`}TWDh1b{cB39>a+}fL9<?^mmOZ0YXi{qP?Ia>c{oPHusUgD{qh^u)V&Xefs--v59&(wuL6ETFLPG<1=gq}$U;io6$6d@8>`Q<n~S&eQoK8Mlib$5P(p-vN6$&e#k$eu03lPzM1dL0j^zxCvuyz6l7Q*>SXQhWb|rtGxtIXF6;`nlOwfHiO!^Xk4-@h)O_74E`gZS}}qK*HXC>3Pncl??h;z3f(2en>5weT!gjELR5s$Bfa?s6#6~636f$T2|FTgB%)lED?E2KOQ`9F}pfcrbWH*cv!71<tz!!W)s&p<j^I4y!=r=dTmT9oCOjwMxp|CSmZ6fXs|bot&dmXtLMt;-cs&t$GNxL4H8}Yh(qn0ToSU@7rq|m?Mm{tm>hZP4`>(D2&NKUR8QB@6J7r;jB5hcI^OunkLi(a!`u4t^vyLasxg>~yv$4i2X-=|02E(eDJDsn;nVNjR2t3_e1o3PBC6P2DsL_hBADic>(chwFXhF^cw;Z>A^jX4-A%kjk0^BT!C{#H#7Qcl7u88hIsS&-YJr(U=kV3@0Fo@cVVQ33r;BCrteSP-28Fu#f}%W%2@Wk5SrsVb@+_H!2@M<SJrPVMx|_JGpszjFQ?4TZOZ(8@&&O6x|926+6N}z32=P^c2z?LDW6PY;ulMB3!2qxFffbyw{}%qY;dH5?y2oKO?T#$ye2OuJYLyyWqr=*QUnz8hvB+(cNbxkS2s$;HPBT0Eh%8AeGq;*p{<ow6bEjoc#JQInR&E)Q(?^jN?X^CjTxT~;$x}-n3iE1nho_u%KHA9;t~oeuSDHlG*t!XiRx@;rw^*$3r;Wv{tqjo4>R0u8>P5R))5=^`ufseu-G5dD*QpiIQpLlU){6f%UbAZC$+BA@OFp=HQJC`F+h=wHOz9y`H@Cyyv~b>UmJUyOuYZ$hMCqkxH%-6r#&c<(y<jnUyZ^$|FHhb4{U)xieTVYeoN+KB=BS@2H`+Zq^2JW9gY(?+SLv!r`?J1r#Byni$3Y5#M(5rc*9|J|R<B4xy#iD4w(<2@#ai*H+`3H_ud|q~bk(uN0)T0DO*(o_HbBjNpM@-N<zZLu)R)Im-=yj+(-KGdfOm=3m5INo_9d>i&LXRLmmS1p^S$`*9k5vU@^rWH13k~6o)!*gizsFDU$pcS!_Pf7&XZ*-j{i6klshA?!}$`_J#R0A%@2quc_bN+m*B#U@y#sDAqtJ#)9>{-;DE1s3m^^bbIc1TDMdUlo^N+v;QPMO1Y}OqBVB#@u3-o*<?;>y3OXQ7%6$h#9O2>ic0)S;a;5L6*CO(+7`fh<XrZrC&{uLFpPpX=RQPNcOlG~U4wPpCFO=S*Tc6Dhz`!fIW4D7Q89&L0e3vc`_ApMeT<ulSdW2+tT82xQ5#nH;!7wP7vnrhOBjRZKcl}pBUcAfE&!!1m?4p($;|oxE8VFXd$yB}a(t%C^b|uY#3TAbJm)-KC8knP_y+xzW&A{F#OVBr{!Nxa0AuO{vC+Yb~rHssLmuir^;siWZ6qj%s&NF<&rzPJ<Lsu#gN5emeR1_o-wK4jCj|pBHNk_CK@%+*^KaNgMUr$y%5su@(*(2fKJW*sHpWgui-HO8?!*}L^-enwi#=vKkXxS^6cpwST4P-cv+5{)gEP$Ti*z)iI%fQuM!t?}LqUWKujN7AiT*3p!mnU2&$wYGvkc2@>>Sv;!A&St7N%5XgMcjl%r7M0-lVGBfObUw}4o`${6P3s?8X*8t!RI4$y0!}S2B`*o9SCnS7{2k}ecU^JW5qW0lUGi5Q{@9#@)g>rL_^J+^_y%FSTEdH+k6&4jn(HsthM`|WHPBM#cJ;FZj_7ymmKTJq0U1jjFoHpzoCu#pJy@Z&0A)4$1u8VP!=bL(+P>lKJ2uyh4}@B*ycu-LB4^R^+~5u>S}G-HDg&>66@GjcB`LCX_ikn>ptn!$+95m%js*GfP3yTHPRaB&On#`8`yv&3hRR0#nGoFz7B`e@q1igmCJ^FtD#lu);h<ot7eHg>;83G=<5@izlk?&-CersNV*g;>xR>H_nT^ESD|3rrK=P+QGZ3n_qSE)Hq#||J!p`qd|`RgU616AwK_UU5f>FoPxfwiowl-)$m@JYHhBjY20C`2sHI$kdT)~Fyyq%iM7V*TQAtuQnKGlFjj%LE7hkz~ChP}Et<U{#;kYpUduC#cwPArizmDW_{-S)~e9<D>E#^>;hg5_uqE{iXAx$R8ZTL9g^LALci~o1t!@G`486r5Iei@@m4k<-Oii&ZQ6|7LDMx#@^ZeUO<j{gsVMysI')).decode('utf-8')
heuristics = _sub_types.ModuleType('heuristics')
exec(compile(_HEURISTICS_SRC, 'heuristics.py', 'exec'), heuristics.__dict__)
_ANTI_ROUTE_SRC = _sub_zlib.decompress(_sub_b64.b85decode('c-l3ZYxhE2+wR}rpW^B&jWFCpJ2awbqm5mKq!*${*(9<_yU)J<&syv83Ue|h&ht2a#~A+o_up|8-V^8XaO{7qTY5#tNpwdh*(0_7u}<kVy8V+{cjuq%e<mEue+26uIDuoG|H1#;`tQI0{`;T*T*G^mr2ibPhl6$g_sDxhxBuOL1=r(${_`JZtSlr^{)hU%gZ~X8%YHQe^UvS*KNJ3IJE#A@l*a$N)qjsf_kT{>PUGJblK7-F*f%5VE!;w5mE*n18R^<OI~9jQ^E%ySMpj{(!uT-rR`BB#5&jO)H=9TKfaXIJpzLEV(>li{;q>YN`-(2VCGnNK4{9g>h^{Nt`-={qhqf^-Z#%@Nj)LH@duz9To4>Jo9!-wDH{FVZm34nefPMK$&ry81z4?z4`J#cU4p<o;)dH#l#_Rs2;JAHBPrFyqGbDF*tRP8YrV$cqoyiXAzUw2qG$E%s%V+OQ+3In0T+XFz`w?Eop+?TJ#`~UJ;o6Y@-Q2D~zg8{vWWGm@Y31-6w{HwPzeVN+1;O{Aaxk<ed#J7ek$Bn2eB3mrUx`O#*2w0Ur5iL3HNrlK!wyd59_BB8RzX&N?$UJ<tY@ab!EHxfGOF{64Py-}ZyCNs&$t<)?dQ8Qr_AHH0QzC)GxUCm;ne|Q`r35Jo7^hNKqIymHztZc05nV_3iD){FQ*q02Kvo}nCbWd_O8z@+x2Zn(q?_K+*X#yo-<^Lp7?9WlSf*4Zq@^5j-I!p_p>|95r~uAC3yUfvp8Sg>m!mD2yB6VkjD2&09tnFj$w1Oh|fB?TwVu<0d)b<%f<Ekg#0MGbM@S1#QCM)Tv+Khtu!`JyXs(?pF}lfYcAr<fi8i68X5YQA|RW8o(OLFzSP4_eXI?g36Q$btWo_4(rI>?lncw92Ghl36?R*oqcxHB*!T|n_AjkKT;|chyqUJT`@_*=`{O=0eN8Lu3RwThbdZne>+VK1IcT-HRoIbuL_qm(x$kFgW$)YM-PLmB=x->XRC#H-7F?xF$mOA3vUr_OuXPE=q0`+PZ#iunQ1aU@dZ)P>2uyc3QJXwwdTg@b5d@*&;q(j-MYHSEhXyxqpOsUnj%2?lZ=N*j3*Y;Z8A(O|<u5ABK;?dR3~x6Peybm+1wzDYuf_N_orIw=unn0YxdG!n>%a2Z8;BkDv17M&5-)>i^19e7ab^sE+RM}XgHKgr9;5I~DBC>^S9Pq?1jd^$sM5e*SNXwj`>OximCZ7^4<i7=Y^(7wu-mJvD%A8{@oBdmSe;pCu-?b`AX`~t!1ktxN;A+2HgWop`$SMBzo-3d^@JzRqT3(~OL|<9y)tZIXzMxTq^n5{WZMv>Yl7ery1c%PH{-s|yq+HJUt$JZ6l}oF3pLR95DcEhZxq3u)6j}OqH`j!Cl>9%-!n_;7l_Wa@Zn!TW07<h`}JWtlJkdA?e29NSgf=SgsFVqlV|#7_SU`JU0geCY#f&^4X+qqhKU(STW0BIRc^o=6Ja$IjYZm40Tg=z-+Jd^uzPVZ7`5lsdK_I_+9h6y*S<P-=>v=Q!4MgL;5T%OKdwC{YA1Qf^4qvs>`Bsu`oHcKodfOnC1ZL`&VU4njDG_HAqR(|Mp7>4qNZS!J^RCfEVi%ly{L~4KEcJ+e83nfwdSGd3Z3IcKM?C|?n#*LZ0>pI7#*>SvuoA%#WecqJDz(UlU;Sda7hu?pZ<H1LHQjSJc!@4l|peE8#2^wnk$gt0I^u02WWYIJI7BnOr~a`x^5aQ)ePo4-|j@C?35Z5VoO;!4(mC0ZwiS!uAa<fqIcq<bYG@J+yi#{d={12%W%MAu0OoBwK6BY`EiA%)PlS9+x^vr7%g$&D&zNa51SoiW-;vy!Hct><$0tbTl*5-+_m!}ZZ&?-sr$Z;G`3ou+*o<&yeC>fMhQ0keul;**rnLpr}SCjbvxJnS>3)-zZ)FHly5hxN|me+8=ZM%yIQLl9GmqqeC%va^F}9yTks+6T`R(Zf@+x7PP|y(5XAcQmC7D@7iKY8p1=4mGQwLX-A_Y^QY}FHD;_-99ET8hqA8#{cR|w%n-B<c-<#H0#w~d@tMipdlkTHK?Awl7`}C3Sb`=IM<*Z~gyEk-O<Sd#Vwiw-b*O~hK#U8&!eJe7r@%rJ<*!qQ3wa?UJ#k)*a%K@|VZ33?idsZ=SJXAH#cZ=bcz|Hjzp5o1}x1a9n_`M9o7t0Bs2CJRc85>7di>l>Bt$x_E$8cHSaIe9$ZB($`K+jNV91nhv%gfK8Z8K^+;k9|QWhkd-KNdt+<coTP-!?%e#eG|87Z=<Aa3`yoMt|ZPbJEbF>69C-Lq)D@v7!|i_3Z|LTs&poSNv2TPcSBFC|zDZuc(+CJ*wbm_(JZdrvm%DX=2IU*#pWT&Dl+TGJq-n)Qq35pTK@54{P@p6ce4<OAsi+&o72L^y{@<YuX17kkmSCSulTew2JgZ{AFi6IY>QOs=vE1Jnghq@O4&Rongm|!5)_&hgZ5K3oV%TBLDe5Y4xO5IBCNhmPvgO6bJOqy|+#4C4=dWwy2Ve`ip*+85C$!>ejxMAIkH<PFcwfc88pA(}(D8@0&Sd7+yCGX9zrLG@4Xv0Hf}?eXd0EjzU&UYz`VeDl54%xjTPoCh;{Gn=qFhlCUW7sGfDR=*--HdCR-g<nTp8RKQpT%)(FZNBo^R9G2s*L_Gw*AWuU2t9|Z4y8<P757FGyb8`5Mh}V3GFCg<EUtB}5WOMzx#Frt{+>q61_UUzw)zat|XS23~dZ=hcWwpKDpP`<3=^amt+eq>NiN_dwZv>DQ@W!*HKCyh`5pJz-@}}bVZ|eoqsxPM9NkjQ^A(=9aqr4i1RjJmn{{DGvQoCmzvEN5()AoG)TYai{yp!d?ZZ;XUOP?vakY8^pWik%>RMxP3Gg((Zf0gcYebRcuMikRiM?Ic?;m*OvDmZIJqcy)AbgX<R?NYPcZ3UmMJ}UJbfAV7JgJ#gKRXUr;jZxxCY}vE-v#1J1mP-cGxjknhwS^!@r|zA}+^3jx_>h)+wMSh)uV(GDpts}2>EgWZFuo<H`D5Wx>!)7i-}pEZPwaQ_kkPG;7t>xkd>z~&C`g~TG(8ff+4_LHOBZJrio)j!Gw7GfbXU1VxiVI3(R$Qtc3jo!-Yd;|#f(<T?mjX<f7IsyVq-F0fj!?x*UG}}f5!Ejw(ik*Q(J9{&fRcsahu$tbX<N`va8On=ioEW=xM#kQsm@@>aN@1^fNy%2S-#RHdXVq@`p98e|tWa*%-LYwbpD@>muZt{8UW!_9EDdp+e>)ET6dLkl*ZWaJ?j`?vC!0LdWO9FP6u`uWHgLCll^bdqSgZetLiPE_WpOwuo<t;{^bYv!XTj>#^0xQm~cJ32^L1)K-AIls0U#>*wNk9Q5Bz*d7t4aBTL0RU@8)-gE*LqeY8@@wTS42_U16o6&T$8f?F7JT9ZKI@@@5(|Bd)4nLO`%3`AwgZEvE)y3xZdU<$xDNArYsVs@)Of^9l%?69H2}9_@Q><+p+1dGNfG%jV>5ReKIEi~Y`{Je6jd?i6-L_?9>G6rQ+jbng@x?^sdTXk9zSrRQT&oMS%H_e8i!a@5+!7#DlV4VGy`Z@1d{t$-;&rIFf2HGW@Y{lBR8ltj?Z)ig;&;or+3k2;^K_lwA^rABc4?hnFAl)*5WIpzILSRQNtmlZzGUBd8-CCWx-wQ$KI*C|-wK~y@Hv`XadF4A&*LdEa+B>^UFv>hJgHgr^vCx7GdfWF^2`{GeLe4cwfq5@E8`uL1^x;qjR()IHB6p1ybpd|#Z&e<ezCl*qJ3*I6J7S^(uGZ)%WvhRXwDjBC`&!1)rKsV;ddo+n`(dvr*mwm{N$8vxddy=Mt!F+{YDU4ou);lGk&$1d(GjHQcSkyorh2SN*2q<ki>E@TOJ_V-`PKgYguDzj1lc*kRm{ovARpF?A}>~v$2aE=fVOZ#X}{`X^lGO*R)k@2{GxLB33zU>m#ryZuzvmBLctSJt(}6UZy=kYrreEX<>h92=Qg0qXD|D@X{haEr~bE+s^R*s%h91;R~;fl`pfeJ~sICxT)pXiQeYhN}WyF0gZ_!G0HPzv1GQW=Kpkf9w?Lb<fvo%47Y{P=4|niukb%c0lEY1+|p9W2X|q`o?(MK=b>%Db6T7deJA)|kfeSiVh#zN`D1m*74&Ml<VH+wZbmmQcw+#(MsEMrCh3K#+=O(wq7Tz)58|Ro5x1lMH(b|F#<W+pr$;oD&OMhKDXHYR80rn!*U3`Ot)n-CJ*EBl@Df>5x77#HH+IcBh#!xLKH68Jemu^GRkY8ZSZ5Ff!ATg)6}l=`00zIxFMGPqT4#J#*PBQ!6Q>S*Sque*uBOsZ`Sy8m8~1Pbuy!Q7t+*~ZR={qF-srchMS9pS1`~Bc49JQ)@@EXZT=kbcS2Nl@eRK&(3B8}|%Dm5Q4(D6Pa~{5A*kre+%;|&X)&qAeW^?#l?#9CmgvQN2{vNERb;))r8eMbs`lpbF(#CM<j7R))P5VmUX^;Cz)5bj9w^2dk*Uh>raTz{S$R?94ql?nY&kMX-9g}tVUSy9iLNQx$EX7w}q{WZgK06TAS;b=3^lVzV-p<~#N*#toSZnZvw7nkP#_P|Jwjz+L5?dX;!aq{LS~YVn2H+j^)-p`3l0NlBl#D>MHa>c~FIl^&4_Nv*=2`D6WcOY^U)5Wn?snLvvGczMq_l&lz}1(Hx=;|+1cP1I9#PZsSJPW(tzBDurC6NozZ2;(eI%{yd9p?`p6Kj@F}B{X7v(%mc6K-Mr-f3J<BaMJ@W*5^hWuMMYIOCUSJ5LY|8|8J(;5tG-(LU3^{A<QupU~?J@jbgp0f32(_KeE!;gm3fLh`7uq!0O{-BC_kg+YIRN^7q+gJ-bT2j}88s92lbF!2l;@gDd27sPxOH8_O8!Y>}=DE7c2nFA$hb;R230x+rY|wg1`NFxY{dM1o*j1P2i4ypATgkF15`Ce%Xd4JLTt(o*ZYFnkjJW+}XQzJ2DZH~6>lqe`&iVZ($pkf@;#x&@Z<^kSkS@+GQtF%KmVL7%>bZa{)Q`|Lpo}V7rtQ(_j&N7`cYWLwZ*<{hjlbbtZmhOWj~8~rJg5&Xm*d&91;+!SVz~x-yoH3(G4a)Opr>;9QJHW68PY0$)sqUJNtvSI@*HWV(}s?YKbKytSRn&L?;zDh@?`>GV`hPLMEabzQ?L#9aKPRr(%I&bi*)M(RZ%S1GrFHfMIBk;RkoMkuHgMNn1Sp=vd~md23S0ANvw&<^WuEHW0_L4==oL_lTOBdU|1I?ZDzDIT1|cHuZZe;y5IUV<wA<m*tR#13Vu85zocKj@#WHTAEvX*#0PLjBK~_7%tpA@U`;2gQRp77=-=9=AWdKWg+B$I<j`t!r}vDRX-A6O--<637|^3Os0WQ7Fc;y4{ApaqJGLJt*$HJ@)6TjtwL0NRZ(G=NIvs5M#U8jWE?RAu|Dg&#al}%tlqZ57h=eoU&&7GVM~UlEsE2%$FMxfO?fxM(ydRHF=pO>60tfF0aMTg=CP8`iV!|+NF@_Tv>NO<mZVgB{E4b@J+4PS4Le|pj<hwz*<K+4yRZ@d@U&WnXseV9n-vhA&(njI=xj(L%I0_<-C*<m~0JF0D_TKmw2%EKiPhCxnqK2FB$#FV7r+8qzru#su;Q%GgXv+}~lTop~h1l)xb(@*>uwDyTyR~Kx_pvGP1K=Nby{v28TBwVtu-fdo(0Dldoi={=do_(k<PfHyAM@-em}8B`YTfxm4CS%%?fOTEM&&MDOy$+FB~-NM5!eRhBqb($jvf(2{HcJ^@#TQk(R!QYBe_eHo(nKNu5s#0sK>UI2~}|Ocj`h?kerSEaf7mxVW;|{N7p(1E`^QrJE_a47Su-*yv1B*>T>-fV9WgZiw9=!@L5wv^5g?3f|CzU3FwFmmC;@c3mksGe|~wuy5;s&FV!(}zwNN&m<x$Jg-o2nvMuIVoF^wFXeeRpi%GVNwtFW>+D(7OG&4@n#fIg|Bkbi&vvM5_rwr0$GydK8_v6{5_~1g9$A-m7;R1Kwsy!>@-v!})Q!Gn&Pdm?tHL~(PDGBn=a;3EU9G~{Ku<{9M5WwYQ{V}Iv38J*%FKTQPVf~F=0pLk}eavIZKa=#(+fD!6ZnVPm!Thn|E*w#_uW_}(-=S{{n)Bgo%$Ba-2V;>gd#ZVmz}xBBi}>ka-MsdNm&LuVH>TON!W<fvTVun4`v!!lN4-3?miF?wQPb8?-c8tU4`5ZW)7ic96GN3}9$#E!u(!$@jNY4wwU?oP2KU1ejj{eQeZS;03P7T5K2i!?*=F&61Fe%bPlNAd)Lv?```9Xn&4c~Kz1x%WEx)zj?eh2K{v3}H>RWn81!(;FWvg8eSG30c)rxTKjU-!U5B)82|18-4%Uz=euUm*`TQl(oB+F`3Zqz38&m9;`<<2{q+@uQJAGI%~G}2>!0%{!8kjI4x?=9Kl>(F;8Z9DtXd?T%#Skb4^Ai!$V%1{{Wv-=DV>SMrb!4)PKNn}QepA^5=S&;6Gtb#hxpK>XQLoY4vc4ypbt|Vg?>buHzK^fodPrIhH)G|jDHY7TjUliTgHPmRucJA`JLN2!6z8jWKXo4qPto`{c1<Zl@W^W(oz`>t=fYbda=*F(z2WzF{HUqLG_CK{BR;+=LEat(pp<K@0EpbsMZ`?x`S<0ZrqZ^{b_^*&lIP97vtTX|BTwd2yB}wO8Yn2DhtoO>_op4z<PgGTee8`WLqIw4XNPG);<Jv|L+|Zue>E<g$B}>hT6T7>=n&L}WXA|N2rZHnvNdeU4awVeyrs8*1FQ%Hww2}46;pl~RLb>06E?4v2dpb~*6>>)cuXoP!?69~6{`&Rpq0{RtsN7_<F&WamP8)oE#PTqs3uuMq-hrv9kC$rkQs=BJlsQ~^!QHCsPf}__jF2AvK7cI>9xOj25FV51H@hkB@M>@0)$ZedA6!bWw(e@bzksu=w64qp>}{5wEbZhkzva12G<u9Lw8g!(abS?Q{+u}WlTh9cQ_kBx06M6VLhF&ANI88$7_P(bXR~>dyO8RfzRO*Ln5N!9X6aKniT&jciYWTCJT^yfIk74nP_DS(u@5Kx?N5v3rIvxIx5!n0P|6Z)w$_tDAxovU@4(Eyj#=ACsWGg#hmt^2R&+Lu2rrUP^Ql<>UTz?}yBOKCPXF}*08Ica4#OCkym${g@_&J{6(k1<f4TNG`wPr1ugJBJnfDlmGgI2CREqe5HkPmNbhsw^K(0+r^`FF@AK<l4VF+3R`@>|u5=hWn-V*+!@1AYuE(|BvFMYv~&0gq*)4MeI&F>)g_rCjoezUALwi&gKUS9&1LE}^odhn*#F@F8Wkpw>diFN;EXIusb;%#c<X;6x-5C`fDYBufAg6Xl)gk<D;#bUFg)o&X?B5eQ0b)p;%mVc_=L!U!uwpPDa^c|qBdGlc%o6c)Cm`ll*eIn20?PewY3nN2~hDFbhBWE@sA>3=>^7xKdpD0ATsaxL%qZj}}g)vgHI}_>*zshO+hjbgY;qn&r-N)E?pTKl)NRhmHoHw_mSG@vzv-6Ba7qIrjU|%eLb%;-P{-r+IBn5i__k)=VcjS(TGr7|+pK*gmqLupm<#B#kBQl*o(Kd;0v-6a*_si7~Z}ZjVug?>kejs*7?Ev52**lK3w26>Lv~@H26|U`cpC?d}S#csJnXrxJS?Y_5{M;`Fm+ozFj4R1_AT!r`=g<of;PmEvtFSz^n62B-qk~Nrui>%HypG$G+!;UFroEALP^B<_SZOqT_ETp>J7-F0umKa{usB~s>=b+Mk59#8LJNI*^%Ul_VwgOtwa&UCw|3h<bEtV-(9ZMr<Ju|12p_bnfv7*wk#=h5^^Yg*+y(n11->t$4gIi&B%B)fGk|2h)nwD(9OdpNI%adixzrvcZcew*M0k*UxDSHrv|1HjUz?}Ua5y;rPZU8-_Dls+cH9rlR9v+<w_-L*?=`AE$Bb!zPVNbJk>XOy&$EKwLT!T7DMAg-ycn&D)6?Iv`H0#I0@>*o7|Ybl=``LP?*jMy?b-`+#|C(`QcSY@R-O~PpR9+v&H%uY*o0wCI-TXYca)1&7<CWrhCT9umc17~-k&w&`w=PZI({^sUF`T<9}?2?LSV09YdMM|oqKe_MmlN7W|F4s^ts)Qx2d;kt-f}#E81JB8jA~T{C@1?vz(bpxz00oSb1@Hc<<H^#9>ul+WUq>Fikb=<}So{Z{J4St`zMdPcUORn)D>Nl|M?U_g7DXGTsI6{#H#E#t-fqa!A|NCf?h;?zF{vCkBW@!kVqi>k%FS$s37`$pzDodNa$vZp54xu#gZO1d-jpC&5K)F`zd<WBx^|jXGn(#z!yEPW62f2PpAg4^{&F<!*Y&K|kIQn-_w3ZH1~z#wHCmyMMKplefyUp66Z#4BCy;H&uuoA&SUnjX#*ra?k)>N9(QWx;0v9PIjX{{cD5n;1E7F0-KLKax!(A^Ch^Rlv}31d7GHJ#G-&!SHTn0^HKKh@{3V=Hev#wjz8`1o%+MXp0IBWhv_Ie{f?3=o#){<8eFS?;MRy%*5a$0>-#I#GIt0dvT)IrTYD+A_-)gxUckwsE`Ltz$(^dbOdlyMD6pa77haZs+{WK-drhhhkN)KRP^7Uk;3^kp{6_(mgX88e7Y3g*(YtKuOtSrp1R&*I3twHWUzf+>;BNZiUnJQMCD+^B0PTbK4X4_Bt19u`tChvAQJ^%)u6M18Mb7B#eU+=vC%o3ndmR+2MYC&t`ql{FRw6QJ7)&c%!cvVxbN=uv>8&sfe|Y(3<LM3(O6^%cqo4MhDtv8poU+R%&@`?SlWg;w6GN;k-#V|(Lgd7Zc7L+}o23=>_<Jknl)GV9mmE${3#SpHYEgtk9z|Vb57`*&YCr3Sy*uU4F)Ehy(c^488o|}=2(skL$Xi?{c=aL7`%Ys>#2S9|@pYmYWH#_7VRgG4Rn$-C`X+MTdetz=@!fB<(hmI%d3_iyQ@}PnH@PRxMfHkc>u3_Dz!bU3{H(MUr@iyIToc^CHfM<{6_m#Ia0upJ`-|R!CfgvfC;iuO%i;6F=-IH2>=sib!i}gW$<eRc9~9qmvSUoMCq0&IWyQSiPkdDzaoid#tt7pvTua2iR&}W(VxTC1oPFgx-+R6CiMbhAwIQo$FLrL!FfzXP?bf?{RBLUNL7ZAT!iwf_l}vhQC5U&O3NV4(gMFVDzy08;0UP1FY(Bu%Wkg6^lRW%FILhr_88}C8L##$)ShPH8;iJJDiU&sRZKHmRsoNX<Qkr`QdlaQ~gSGMgGym|B)Or1h{x`P3Q9f&;?Pjtbv);Nkh=$H`d=@<7@t3{MxrXaT?;OBE$E};-Lj9qOeP9tX8Xq*bD<X!CikO?<QyeswwRc9Nvv0yI!8x-DcNTSTe@p`f-A~%+TD~U^14=)?*R|Wn(HnCQl0S>~+Nu_`sIb9-VpcNLmVS?Ni^}x}buVw%<?!9ksu!PE{Tpi5-k11RP$n%r@4H*Vfd{Q~oCu?^dpuqzu<K(wWvs>9+&^?B=aGhV`yip@{6pE%lFfG0=SDs$0ZmHy8Q3;?^?8!OT~$q4dv-VCpn9r7SMI9r^2c;gi#FON+zh&+afs1xJ>D)Z^jwPv=O*J18tNt3@hS*y5D#!HZIQsNlpEY+H%J%GsIlu-9=h|i@<_Py{S$^c+4Vg%Sw$(jZErcL){@O{eFj$h2mzNvS7B#p^js{w;^cKmC+Y1BSo~Ps5nO>#T8g2gJ+bYTK$W&ugZJKfL!LvvDk{KrsGq1mg^a1>vELrQj@_+&u|xqR{#v<-36ugsRj|mnmaivV6$)0)9Ve1c_fL>*lF15!?niBV<)*FITtZV?Ykl(K^Qh9t)mS~M-}CaJ0up`5=X}XOvnKEP88fx#;yGOd&E$2)uF@l3^e*>Hgu3e(2X&?Os4n&^yRvCaxv==oHuKdf>ZhY6y^fb|=}(xw`X|fv=d4xa(pKzdv<r0s*bTTAy@7+Y==~VIp!#JF%JU5~o#~(1sHj4q;i?y6z1{8;ZZ{C#HK@Mx)=zsm5K=*3tP$qW81FN7I)vq#5xVzPCzw>l<i7PDl{wH9<(h+V&+mKt*4tGa3Rgh;x*A!%Wm6sj)4}A1-aDD!UPE2!*d%90!;8}y#6ASfYC9bfY2`<@p8vjQ{K`4{-`DL@Vpr%n+p%fH;}KS?F~)crYyQ_;Rmi)P)VNv4WvhSst1a|DzSr(|kUF%R=j)<!9mAu`Z@Xv&rTobzT@>0H_28$}saYfuV|Tc9Dj4L6t8O?L6xSM!4StZBJ`O~REi2nHy=wQ%ZhG4Hbb<k7E9*BlF>0$EE3Dd3gM)kJ0@J$kiziNG&2{c7-yV{u7P`2L!De2D@8|ox4&RGvkU1>1z@+<%xk+(|%}32hLFE}}ZNCG?DSt-}@7R@to8*Gl=Gcd*Rr!y+D7$(~-=@D)+^xKk#NUnP!*z8zbr;gNweF7qSESlqVmKT%M|GMDVS^`DONvg2#ZD+BrF`28xdvZ_2DN8`A#vm5Q)z~5F!aLqek7rYF;}kwNd0&kn+<W&i+fLwM3)<a(fjpU(DEt}m#h6&B`N7o@z@OH^BDG4wgv)qSNP0}M|}@m29?ThzkWW05))+b_MSHcF%D`4XLrrVvE0jNLF5o&%f#OA4V>TU<0F-i>byI6x#l5if}4hYolmosN{>t({nmJ{qrGJMjvc4@)K-`_88GTIWZy$X7#>)>d-%+MhBEPoJNQ`-g5c1UQhgudXU9ZwUoy7aXY|lY#9Uv14UT&%is5zA<VC%2`Yt89(u0C-Pgq4Bqvq{RDc_gm+gNR`B2bZieqg@<P3!pX_SZ}ObJhWB5gNb@?{fR2d;0FOd=IXFCwONw5tHwiHzu-A$?eD)P9Amn-oo*|*!YjV0_Uq7?G_Fyv#)n;QKz3ad#({=`)m@M!OA8r1vcFq9s@;Ly{63yxe9yHjBWMPqmwNL!+!7sb`#|WX>7-@EaA!%;ube01y?S#Z=IA;T8Q6s<NiH>UE8GY5VH43j@}&M^<Oxx<o$szHY!<2NJATG=-^^}Fiv6nLyWC0j_r9^>p#HgP2ThkyN!zAMEd7?rNxNM<q;o(as9Acb{-??Y4RR$yAK<{36PguSrX&*ySqP?lluPBe7<|<;#E6aCehx^H!-{~&l0rMr-n7-LFc$jx!>;WV_L$E5`60G1bmXgO06}$xL~J2_od~W88gPlO?Zt&Zkm)a73Datlc{z!KYGVrPu^l1&AAC;gxjXrde@M&ls4-6NyH+44PJ+RFrByDX(6s3?K7eEsLftBS*Y3H^RJ$HCnr2ce5wn<dyXS(=ifLb51qnqF1glxHls$_hDRs0GY<a7uL`I`9@y39C?c)Nirhm=%^n5A!RPb*P%UWiN}1}&Pio0}wbneO8^6_U(Ih=&e|}%6+%Xr0e2%!ndp`S=H)}MK>gKQ-!eJV4FBUxkr9kw&h@a@uwEMV&w|Z@UHqR^IJDPm&+Zhf>k(9KDJG{Pv_u#EjVSb<hZ=-wIq0n33kBJ_GZd&;&g+sv#>G>#`lkt)%n@*N=E<v%<7tRhH3cTEffrwgJ)W@%sbw_g?5;z#H`ImgRr6Q_O4fgg`4>(9PeGa*KPX&ahkhQw#Qk%`|?Z$D9DAsCx&3Wdxy{orJ5OtGa=perNYx0c}s^LNHua!=8V-@;G3Szm^c!yQ5JyUe582S2?a$B2Mw|dj7#eE*77Jsa9BOC45g=#3_5FpFX{75wO(R-^_w8bYe9r^;gr*;~)`ZSuOTGTa^rGJAj<*nQ+m7EO2MrF4)3)xN4;xWWFhYRGJ3D-!AMlU<+Jj(Ii%}Ze`-sUbx(_o);il4u7B6gDb2bQUIXZK4rN8jn{SB1aZ_e6P{-YCc7n$EQ4uV}nRccC-KXw#zIw-$ZF$GiqhatBSrhOw9>uWw5FaIP?Rjha<^OQpA7EekmSzS&k4><xdYpA<Pfn!YAeos$@5HTe4K`n4)D=xoCY!0v^fx_kFE9dbjIwjB_izvs1HcRcII7pq(Wo#43&f*AYl^V3a@z!mj}?DTf<np+_Wy-3juGEgKAW2MPai|3uhJZRwI`a=Egfpv3k*X#GAHm#<}?R4!=&FTZ9vU@zLj_>}=?C@s`n3uc$g(8$z!4J><!MYNo6?{0UMfZ7w<W}?KI_*sOsuQ|ieY^^^*1qq0P^LgmAg_3%awMJ|$!e~~{{Fab?q4@MCzvi|j@Efz7fq@6JWr3k)$*q-=W<<t`;^PwCyk^7lgC~t*YH+8THKeDB|CV^(B3xgWdBc9Iem|j$NRq^_}~Bi3p-2C2=OoYAMii_2M2z$J^')).decode('utf-8')
anti_route = _sub_types.ModuleType('anti_route')
exec(compile(_ANTI_ROUTE_SRC, 'anti_route.py', 'exec'), anti_route.__dict__)


_ACTIONS = json.loads(zlib.decompress(base64.b85decode('c-rk<O>Z38k^C<__d(6>CdIvRq_!oPGZZMw4ex*$46rr~81`Yjw}t=va>V|qs*H?`%=e1o40vlbTUGD-WkyCu{`h}qfBX5DfByBCv;X?>?7J@?Z{Gj(>H72im%HuR!{Y4kKmY50{{8ru$B+N~`ImqE^?x5f|9JM{<JZ4xAHMtYm!GbG`1t+x&DrAY-R<sdac;i;{9(KOH2A~k?e_iS*Sinf>-)3C<>c${w>P&xoGq5epMSc$egEa%{po*PJUskoG3?l<kMI8U<<s#^gP#3(w%dNb|Ju?YZtw0teEoF%YVu(`44=0*H>Y==Pv3cX+~8HF8N-*JK24_qy?*jCcjjRKj_vq$K1TiA|AxHj)6Mm}EgnhKm&4D^n<gzLZ`}Wv;W$p(@b#M?P77ev$H7<TN8z|`ucz-mEs5*<?cH?YOurki7`RxM(}nZ-_RDnP*ai8AU-!c3n@R836i$a`JhYQBI`!_|^?o@Xe)O~x2OUq%;%Tt#OAli({8czvV8@}UF{|IKTk?+mxPuWJ42GF4`x||>_M=V*ZuH#oemf1Hog#Hbf`J9wz&%L$X)@}7Hm>NPiKp(+Qhg-lZ{k@5L%2U%z#K*MrVrxr9mfxkC+=tTAvbWRac_C>{+D#p`#zsec$W?w{_o&TU7s6%_y&(1-zSTeV>t##Y2xze^VI3dn%Tb3-h!zmLVjuth(0ZNcYAZQeRu!UAGUY*A8$VX_xMccG<fBgB$i0|9W%|r;m#hk$K69mw`1~S=PKVk$hO~$Uj2#Lot{SPx*r?bevK9hFzt-#I55A#vK6d3#W96D0{3dauu~>7@58XSQ6Iwr1WtUy9A!=l{1iQqjRpD?K9G3>qV=e*6X1vXO)ff5{-8>hud;!tPae-d@pIaoUIk<d9|!&9gzErI`_m(>DHv~l3z!hgGHze$aiO6~P_kz>t6!hi|7r5Q4=kv)3TM|11K(D#hw~UPUrqq<$5Zd_7U49~amcP(>5#10568C-4y^p$DYm_(bEzS;IC|5KKyTM3Q-fZ!l|kWFi~~Yu+@+}X36qIh9mHHH*kW|SpYXmA6(zV;Fc>jdm^pN(AlB~(vU+{&>tla|kJX{8HZ#Wwt51J24%A0r)8h}a;E5A@x9>LID|6*EY^CTiCa{#Yz++?$RREA2B9&=BiKMqWvFw6(#^%HI-JiXV^}F#CNP!r;MniS%OL2&XW6?q@u!Ccxk4FkY6NthG{n)Xmx8?>N8CAzY8IDv8g#c`2wCql6^e`x=Sf@PbrzfJTX868=d9LFxQ)ULe&%hfhv1R*UONe?k8(tsV3J`4~%W40+w_mrrHKsP0-nh)zSbHPp^ZniR?z`>X-CuwuQ$m-*4!LiKWXtpJP?KxW9q648Gr&&Ih&H7z%7o20#+<6xrVk=i5vIAUsi7fq0+n)55=T#(*2eL}@$QZvr@?85t9P(F5wEplG_%PGnfAZ90=!<QzJ6+E)$l`~o*G(-qT0)hFxmwAb>?vuG;lV)-D~XXTSdYyG7!<G(R^7w6b?@zBo<f)#2!J1tKu_LmpsB;DwhfaB?cGZ?)LWPYmN&v@%De*PtfD}`2MVH(w*FP+}p(0($Tq)rkb%JI?+<5L+#xPVMp<-q}TFsB1G&BhKn}>!3U%s^)?hrQ^ed2EexjK*Am*)!~oO1mNo*E4RVHnm;}<APi0th>m@+snh4O*Y1B2>L<A-dXi?+Lf#zM1=)9e7bo5P6i^?`&!;C)Zg91(+ixW?CV``)>;FC<u+qtZ$i)8BSGRHrH;kR{cd4UAfv@s@fqBJL0j$uv66B!@`CE}U{Qs@2P;$;_^icu(jbTl;1*Y*Z?e#n3XH8GG)GDyIUGput~fpk~XG&_&MrGN+w4m*a7638By`RgDxnz6x;Q6-X|OcO?1tOd4jXvV0X7S57VlWPzBywTWo$>NJ3#Axxq_(moE0^4VHrS!7HY!rFAs^Eusq?zq->;<^&UArPR&bG_!xo-b*<_(3jNe4|V8Kl%!mbUUrHW~=BEuL^n3&5Bc&b7=qI}kM({>lLh22`hS=7*o<=N}%aw4{PfQ)+;mz5NXmySt#aX>X%U>$?j4id9D0W=IvZ)&Trj%F8I^Vt~7~%~0!<xOcp;hPbb1>;q$tIBrz8NHpy!)0Eq-n08c6+DJGA;IceU@WIgi{^QM`_AAfxjO;Jtw7nKMe7~ii-nSG%0trJOMrPL8DF%x!2_SHgw#Cr{FFUS7u;B%jnpCn)GTbC&k#<y+QZl|zCi>72o`53Oj^{8)B|C>WFT-ObW{`?$PN|Vx#jvP#*pP~qxDxTf+2)pknYI{_J;Ra0kJV4J=4dgpYB{j%g5f*Gx6NbDOb$&3@6^6>|5kHLB$v1Fp_(}!IYq8l)~j`78_?Oy`LcR@*op_&m36854iB6b3aW$?N!-EC%gnyOf;m$sJm(`fxQQC%ly@B4<kU_lHaW~&TGh%9gV=oU_DFeSvxWW29<AVRuf5}g{7zGqn!^tVHb&%z6TWROT&a8Ip<l{O7BROm&T@>6dzb-)O-k8iO(p%cq)#%3-LB$8jLQB*Pl43gH@X(`6TNGV*AYkul+YaND6~Qi#}?OVQNx>LJPHb?L!I7a$d+hx@0*nIhvlpfwCy!5k3{$f(8r7e3>tzw&p-~unzt2NUhrZmC{Lo7L_?#_Yyv0FBq)vs7VJu2wc3AXtDCG1Db&HXCUAi{Ch)ykrYOvONrhT6;wK>Agg69{E>VbaDaLU@=<GRM3S}~9`p`Iy&(Ny+iSrT$5tv>tp;@nk^}0RhfgfbYzU=dYN+mBQE^gaK<KjY0I_Kk}Zs@kI5+avd$$}ki^34<gC}vXu>t5w5)By65mziUAQ#Yx?N&^%|8b9KpH}sI^9Dm4;@J;W9lFHLuAIG}A47aAOWsp;CF1hPEe2W-2ZOyIXk7maTZnn2DLumFY;nW6MrHrDBv@6MSb0G29lp<a&+KRyj!eb3n0zrG1ZypL9SO(wO9{~{I^c4)C<EFli;cOcAghvuX7PgAUgV)xDN<FiSnJth|XcZ4Q!{EfxmICqw!vZ-?2j<zZ#9?}kjQ+RO6T8Gm>5imLG(VJZ<wyjWtRK`t%?BqtL%L@9C~&Dh(nVpa7E}4ARbs!8835B{W5SV94TlA!1<M`YJap7$qUlHwp>=B?qB*qD<eDP8uSvAv(m*6#$(shD%^*&{4KDz1Ef~f=YO|lj9Iv5LhiVXmgtnGPJ<B^lJ88gJCdtP~QIKlF@klVPoF2fjk#CzSU>TCScN_Z8uB+FHxnLrsVZGlJ%#aPb3y}HSj0(pzkOuj}-RGuNQs$J0016Y^uPTMIMklF$Il61Tmd(OwKGC4F{Jm1;3MpaK#((o17j98Z=!liDKXBxZ9f*ci<0P{ix+T5I8-%SuId5MO`0`!U4<arO!?_@oLLN##HZ2>Mhd@(OUgCOTb}-$+E{G*p8CWJD045#8jo`$Rh~+~4%m=B1jG$-xg%@muK0$H{TU?&HS3vD0P;=M;MX<zq2tP2Y{z6XqOOf%45fIY5W(_cH{d$XvbuUg^s;Z2Hi$-fIEn<*fDd(A-HLjheVR~%L(>EB4QH77E?Ug&&Bn+*eDB>{ZdQ#+SHneIAd?e;+rV;=%vh?yG%?Xfc(QT;ah4?tj@ylU*-UhJD{J0AsA*k_77xt}Lp?V%jotq+JE{c4^n`BxDwU6^|Itak0()sNID6)Lom5N&hlGqB;kq{8g<YbySf>x3lros(sRZ2NXobf(VC3YPjy_~nirajDfVcdq$&ugQ*D@xgkRFQ-sP4>JvG;D8J0z+d?4I^5$_`O2bWkTJL2=NZQ9nuw8`>iFr9y3Y&=p@ccoaD}hgQi9T8TUvFs<I)UtO7~QSX%?Eh5}<dVbX}w_{lNb6P{q6dESX|lq`$nG*&f~yY>3I@clSFzdRUyhFa$xeF4QNj5N~^se=)UmQ(Xm5QmG3E@IaiB^eb-m3i-;5gn!-?K0sgV&)Mlq(YMoBiN+-@aTR)62@=Bw|_QLg*Dxw*&q@3eL$k%;#<R`N*~DTDYS~4s~HW*?vi;EwSXfq?~BfT=uuTBqY)KiS`O67%2&tKLynr9gzljF;%Y?%KYX>NV(cVug7F4*?+@W|HnAw|1SfBLOwvlV1^y;V?vjeGXCy_&mrX%*A<!+5bWtS!Xp(QtmIn{o=Oh`zwyqxv71!y>FNP}F?$;bxb|_GUg%Ubw%2L_cmSi`A=s8;qZjy)qa|kxImIp@{17GOXwkDZW)+JE=?z~@pF8EWnJ=BM?AFOU+hlWx&ng}FHvVT4N!1F|UL6LIL23B+j>!}26>Xpg}@zUus#AF<$#jCHI9?fk{!pMnwwylU7CE)7iQ381C1-kh=LIN132Ey|O(`c$93LLx0&W90>1{ZpljMBFkRA@?HDEjbvm4{}b1>&qz^0+=)PVjmmlQURaLb@J?0z0W3fn}+j3PT$XbaM-r9=}Nq^Tk6;DoV~vOYK^am!VPX6U7q9Y)A_J&N>;-M1@yihx{}g<EIOW95wLEuVPnmz$-))NoS_5bhMiBBWhAsrkZJVz=aer4=U+_v?yLA219{F5#Ttlo#;}AQ(9tWl?t`#S~()mSfg?&#X<vZoCa3SdMKmtRTOx+&iMS)f%X|Ubp-7)1NCr1ULrRlom(LBB>>>XT(;-Spf}{~<9YM4Vz-xFys~Ev-R7!mH6**w5X3E3*2@vF73xYfwAg8;wm~B+8${~r^!Gr=i|4X8a<c7e8CU&#lGR9f-Fjv|Q#KjAyD<PHukD0Fzf?`Sg*}Sw5h_y}iNZyr&{Vi7)?l!*Wz-L$oY>Yq03tqml0gW1rE3@J`drk8*TkNJNK-ZbstDDIQCDgFx`bjSIm6sQ2c++I{xew}8L`SB3QGypT~~)BVUY5G_@mT;zii|~^TaTw(C9~ig+?!$eHG0irqO@q24+3_tH!odOOhfXW&ZS4nVO#K2?<0ZHq@}=??3)A)1&2i@3v!V_*2o{fu!1ncX@eBEbhu?U{RV^IRZH&xMU;cmr7EKCzsz&uKCmP8@z%$FV1PRgIa~dHUV-vB4TVKszN5>v{Cn*#g4jX(ZjJwXzR`tZ6ATQOU%*-`{MjXfkJbLA~wb7xwyD%iT4Z5N6EI^v?O3F6F)5Com8!zCpw=m{8+3s*d(+-UB6k1Us!`QD*Bn?C>QDSEL;>h-<|4dL<<U-#8UEjF>77pV)Gh}+a9&UnIDN!tbpvGPYLbkM1=VwHu%XEeSAn;N;*sE(xgU;x&l%Z7%iYQAp-S+>I<-~&E5Q_z&V056ZkI;5=T=>VvV`b3EPE4osy8ob#hnTfncc_Y8;;6)_&N#<{*G`&0}}OMTz>i80qp!5ev3>(tNp9#(|U&0v4<XSXv)$NKQDC>qxk~h;B|gtHsEm7EXjnyR7FT>{u1{_eA47!T)dLngWLQH{~Y)CqgDD(BjhV1O<>(T9Mxur0-gNS?JZrA;7I3Lu}M*lKtK2?@F0Vu^3?8SFXyn*(GMluz5Z}%wp9}@-f@)yjDCbsZGACFHqR21NOZTOU2O&i(GUoQf~@e$p+q!B8P^^?Fo#H`Z3We?U53|m=!{$k1(mfR1i<c9r%KvdPwQy{!~r2Lh?L9DBL1a7c<UASbHs_m<ikp5|8I7O%!U<m@E5dZ%WH7$pjJVE2b)2UV&nNqIW=87ow^F&ro5zPTu=#!7CF%E1Jgye$RL>g@!|@Mx#P#m7293kjYHA5K<GuD#OQ?dbctBF++{z_Jfj;_02(x3KGm@-0kRoZ<?>S)|ylT++lT^i1)(Qr%T(QK4jE8iJ6f}h0<iwX;sIl0CR2{YaQZg1*y~=Mof_^44JDtN51hwDpmu*Dg0^d29Z{385<3x(ks*>IKAsmSvu!yXP<z&z~`@J6~gqLpsK<E7)3o=h0uP_e4eh*O#)wwqqK67g^uMKh2f~N0HpjMl|P~-UI+lyEE4?;-_XlE%Jnidskh_l)s%uQ;T!VoNKDJ4ho*a)0I#pa8B=?q&;y$N!}JEISEkk`ER=inozijcCLUm!!((odT4oQc0HJxTd9_k4ou8lxAb7(QbyShgw5IxbBDIG%OjBx5xghz5lQp8|$$=hdiM8cMlQl9%`0-|wC7HWs0&FtWk6bMg`!`i%R`wy^lyMHNx`*0w#v~X(B)=}<ew`9MeMfFb<94t)d|KW85`oCV<A*1$2*64dmUqotL9$TEOQMcB7hX|?GGObg;+9kZl<6;S2~M`@tS9LqXd5-RX<ZSd)O0A7bf0X0SLNyKQy)|LFmDY_ld1D<z@F1R`7+9C1l%XiJ2fdrlk=}Lx-&v=TIf(p22zm^#UG7Lv<x9ibj)kaDA>*pbf_Zm6BGy)qm7F2V3fEMfd@3i5aL8Nu9v-&-ab^64~b8lNTo``M1^_Os(f3mDJjtj*&o*6<_ttR@|vk15f`kH^kO&}AzxNvS)xzz0tnU#$KhZq`>ZKHjOXJrLwAwfIMD%Y5R(K7bQh&%h5F&~6U4fP^HwRzSJ9xcs<zcMD&pqNgLrZ=mJl{8G*nLQivshA3n<`+GhK#~%F=Qr>}oI#ku07AX!^8gsV1G6ClYi=7Hp;Tg^;ww@WX~uFMy#Vbvh#-!qct&{}-i6PmiKXXD?7^tC~bSs-UUMu-H!@!dZjn5-NHw!FW3@-94aYH8Qe-HO+F<7z2kTsY&Ji<jGWQCX&UN>y0K;CM0F`=~qq%N2{4bf!yiui`|$j(eQ~`wGo(AH4U6;p5o?()~lII9j8*hCbafCFsrPNPMGnhlBMRXaa%{H<}K&jtv>EfD%bl0rF$4sGj>25YZe9OX+h@)YzEE90sukW)n*|ergH0X^3}2mEd@zf4$*`GA?FGv0NOkWiDfi~Qwz>|1+pv7K3jZtKE*mj^3Y|GgYXFO5GlGe!vW-alo0(UT2h?RC6^l2M0uFG?Xs`Md^Kn9aT*fsRf5JLs_8ns#E5qWG0t?=5Q-$x4VOafGV;<nlDSHcbXI~^D4O{%6>Nj!<}r@V{)N_xyF$i&(9#>}VveylksC~tm<zH~Ono~n*5;kr0#L`sTTv&{>8HFLc*Mu#UYFp1vouoHAW|-vR7Nhys<qOZ#v_-b4ng#P4#D5P2*&Riui%xOC|L+vC2B%jFR~DAp_cgCoZzM8pvj_2__iRyszz1J-TbVe=32=%9&5GF3Qj6qP}vGjRXR{D&DO)TSqUhg7nDI+LSG^Y)nBx+Ht^Q4et3^sWWtXl%QD+@mU4#4g%-AAf<Qb&OpVd6g`P;+X+i0rXu%GyHEh+Dh#(iGeaG+7pdt=MZ3v669=+w|J?sU-U@|$4mN_9};jlz6<E_O@SOG${u8ATRnpQ~$t6F?hnY92x@M~9B_t)DJI|R;^P(O#EpU#yAT=axUl0+boX)<ip>NCgbTA}#hcGe&~1+z4&5<82CD&$;im3#h<MHOch_`h!?ZBeE{PNIiF9Sn>DxBsDF*Ie`V^!z}&LjY5wY+b`odpwozZtwNFu<4$e7de0$IzHbD2ZkZoKRIJ7f!{hCKWk)^4%)-l_<n?>{8TYDByiptX6n;!yKHE;vtUQ_>?hP@deqUNO0zLLH<CD#pK@EYCsf%sK2;w3{S*)D!;^Ap<N`T+eri;W5tKm$B_e|pM7G+~J4uL&W`<SSQ@fU&K?e6NADZ}7#W@U_Ry10dg*4Yq;%IC!Wh)5_)3H!F4d6mymR_WwmG~vEeH-@i(mUuAOEH$vkG1NB@^Y*j8-1$CdK2>yDOX*}?CLTj_5@7eQECly=5!_J$lp#jV^&&ijGM^w2{i5TKDaPhZ?w6=K8eF;X;<s26sZW73RmJ%@$dpf`lgn@!f1$g4f1{pOSPUNF*3q4r3t{r&$Rv2jJlmx>?YO>b~~w5D2N~p$`6tOLQ=1hOkyC;Q_1}VIFwz$45EtiDQQKCr&+lI3PTG=Q?9YQ3`<~j56Ehz^fdh{C}#2Eg_dXN##uFm3Uv*Mo>FD`KzBTzv9yxAdgwObF09}n73rs-7#WTOYFtky)O)+igaWAVtz~xG`(^+o3z?N2yMCU@t|UZ81S$^%`y6<h3h8arvmCGneH?YB)XWjCy}|__Ux|$Yu@M_Q6bnlfBI`?Q<eJb@`O2JxTL)B8z&b;SH>|G{I_?!Ec$QdK=Z)3>C-(nJT4I|v4?L)v8UiZ2`~>C|Dc0nKHf#DS15E;eH9{UG;8o83scXn&wEzonHw7gN2)Jr^*mEjV9hDuGj7bxDf;OZ*Ee={LZ6&bvE;}HffrLKCZwbInGsRA%CvRF8D*C&stbef>gHY&=(IWatTuCdMMRqc!HIlr8{aRf*b3-=nstr=rN*l)dWO%OCvH-!-TxU>Kr36THKC$(nBQ~416IfCxjO*sbGZUJO1&OO=gXWXns5?ES=hR(8b~}6#_%muBbJM%2asGC^x4a~7Tx(+6g)fu<s3clx8j9@1`D>S$Lx)Ka;AByJ7p{R@Hg`>$XC^F&N})5NSH_UWP-&w8J6Bh+R<ekNu*6#j+_A+_v9_cET9t%IxRpev+#92k&37(B=&Zk5&H7Q_@C^)k8j=!AZu4HuENABx3SE}P>&79VJaW20*yzSZ>elYhXD$~C61<OL4hHiIe`QP=3J~)`EmCbcn&+;mu*n2QC4Jl;%aI&>^mny5g`noMjTO@{sKrPt)Y*<3rGWm$QU)X|KF@^OhyN>~03e^mb-ZFZWY$E%<&JXY28c0KjA@8K*Z3a1;HBN=O3lW`MJY)iI>RdIJJ;%O5<0Qn?Fmp=#l)r!L~j^2H(>lqqf9qU7@3L}DMMhTj9VDdCiDoUmR+3For+k6l?7?Hv<kOXrU9=c5r%Fel#sYa#Qt|FG3rE6ei}`KrR+-q+g#OMlStQ3Ya`9I<M*)F)<DdM`?%o>2o0jbLSbo~&iR+qP>e}&xgM<Rq%b}aRP8Co`$L36C-*EflrKhOSBq5urk6`#<=ROF)xfyItRzzsWX0CfKNfA%Cg~6yL3o}CVrSPpAtnxAWLUz_k@Pyu7&r{?+JUiNOK_&5$;?|xl;C_8)>(!@kQ6;nm*4b``dS6fgqFNSBJ0Bjn<@1;Ohx00Pz|*=vxu5^%2Los&w#uvF~UUd2#WwA?ESo*2u2DcXQdLsnvS=QoFkPXj1u0-%AMH@mn;+)?v(g8;jq~Ip9;d{WqU440ZxD~#&kyJB}5sPi6}3~OI+*O%VZ7H`J*^>Ebdm&WO1qcm;E!cX+N22ScRvVm@Pu>l8T+UO7GDxI|`UFHWw9dj1I~m_g9~z%gh{IC5T+wvSL_*5QyG2m1Q<!iS2YQnoW=HLF~tOlF!|syUaIr%8G7**kgcRumZ_ViP3LL_a7!J2{K#<@13n=zkGD%G@W@eWlL2^%ya-=S&?8<rvUMCKLo?n`cESnnC6zMMi89V?Q1|QEK8?(%5noZWKdIiSH7<5-88IOEL!OCyCec%3|ej?&@!CZES$+Vgjl+s^qKg3b7qe>0hm`*aQ866z&Tu{sbU(?@cXQHiXocrB~Ry&^Xp&tRLHWu>?Ym!0;-^vPxr~boI~i3F@W2kN`Cft5%ddthr*;WTSr}_skB*GUNKP;Mk@~(^V;6D<;iMfGAG+JQ`JJz?<>IXxbmGjuaTc4%$6Y4cb-a2HESQ1<zYD}BukYoleGW`E9s;>e=-!+CuVpoYLHaX^AkKV+{r||(?#5}M+c8BC`^h(i7zcVlUDrQDiUge=u&MMDK(h>(dP;IZO@G&$wl=Lv~5YYGFP28MqI_@(x^sC%ptaDxT5=|>JLh?Z%z7`irS}KLDjY`PF5ESsJ3(mx~c0pu0f&l;J{54P>x}?y7vtykAQ0&5Y$TqD8)_7f{G~Lm&O3Kln{v`Cuh$!C=Hq_uLGZ)h_2b{vsS&$hmpF>%&anLREQG<hAw_ff@<D?ztjq{)Te_D+6j4dYMofQUQb0^ti3vHDqA7^oJ~(`C={FOdZ~75%9s-CzJ}<DSg<{$5VBl}TxAC_<t90TWX}ghS3}fix7EXMHK&)?MrDf6G~K;<5e79+wN@y0F6YqeQw`5>Ng5(0h?2^KVPJ;@CML21Q-V;X5GA+ycg#Z$s<G`dX%)#dOi4{`Z1?*0`%03CttFFFwL&F-n!<je#ab(bopz>z)D@<U8|LNIG6ZQCsJTcfw7SYr3ak)YJAAuY_`9vZKdP*KlDJQohr(-W;v@Dz8j_i~LAvzUy+3dRIT$7-JsO`f%Wfc50pb#!IT}xv|3mtnR7+1};4x+nvo5R>mq1YMv2G>3f4e0uONmu(NF?CS#;b|cmAur8<&uIhC%r*S%-K|c3p*h??&1p|U3{A)!Uz=B(nw%KL}{WZTTsvF;-xzw2VwnCkSD4TX6VJ<&x_Xalj;xfblGF0iJ_w91^F5v!pyI--U)^AA{B%<9V590fX&OwQ-pRoQIHAemI*`Rn)H@1!n15y2{+}`31*D(ToiS(9*Q`0EZ|`Yj+E&EpPMwb^c6c1;jk8GEh4(8Y41cvrI<J#<btajU`+}?EXF9GRgo%@3Ob~mu87t^bw;EAELh$(iJ_pJ0ll-*xPdm1szN=*_q_^QIT;}n5)QU0^c4>+89{1?FQ+l)#`eK?pd>C6t7Zkpx->0*0sr8|*}FF@^#O1MUP80p-`#$aTji-Ac&(jcXH-1Ns}?un9CIC?t0?*8<Q-?-%ES#lIXjbnZ33Q_YMx8(VfNaJg<+cBPm<V~$W^3gR*u-KmZ74smZNw^G$`4Yh`ks(;glsBH79&GIn{!&1!Xk1yq5-q<*FmCeTHkC)clM+4f0xW%YsX5K!`Q=O6|SS6hQ`>X9d(=3;Jd)2QmSvw}JzTjVM@#`2iN{qCD?Ad9nm8DwN22Ia)L<PUotziRytKeriWVgz#EN#J)JL2oO}A$<O{X^>shPysyV)pnqT)O+ZOuoaKb;C)hDMzSDIGln<n-unfw>e;)oHVUXVd')).decode('utf-8'))
__version__ = "mapleleaf-7.3-heuristic-cma-lite"

# The promoted defaults below seed the compact tuning space. Historical
# experiments and promotion records live in Git history and docs/.

_BAKED_BASE_PARAMS = {
        'weed_replay_steps': 11,
        'town_demand_pulse_period': 10,
        'town_demand_check_interval': 7,
        'town_demand_single_shop_bonus': 0.0006157003847131392,
        'town_demand_multi_shop_bonus': 0.42366855104471457,
        'front_run_lead': 4,
        'front_run_start': 48,
        'front_run_stop': 669,
        'front_run_max_batch': 20,
    }
_BAKED_OVERLAY_PARAMS = {
        'premium_shift_enabled': 1.0,
        'premium_shift_start': 287,
        'premium_shift_stop': 682,
        'premium_shift_fraction': 2.507174265974758,
        'premium_shift_max_batch': 5,
        'premium_shift_min_future_qty': 3,
        'premium_shift_opp_ready_threshold': 4,
        'mirror_max_distance': 34.86886877003725,
        'fert_relay_enabled': 0.0,
        'fert_relay_lead': 3,
        'fert_relay_lead_heavy_animal': 5,
        'fert_relay_start': 353,
        'fert_relay_stop': 610,
        'price_floor_enabled': 0.0,
        'rank_sell_slots_enabled': 1.0,
        'demand_alpha': 0.21164025445907636,
        'opp_sell_enabled': 1.0,
        'opp_sell_start': 45,
        'opp_sell_stop': 704,
        'opp_sell_batch_cap': 5,
        'opp_sell_base_fraction_MILK': 0.12226358671010273,
        'opp_sell_base_fraction_WOOL': 0.19196433115965672,
        'opp_sell_base_fraction_STRAWBERRY': 0.26729391318181406,
        'opp_sell_base_fraction_MELON': 0.5838257424438272,
        'opp_sell_floor_fraction_MILK': 0.46780182162339207,
        'opp_sell_floor_fraction_WOOL': 0.11239281181508977,
        'opp_sell_floor_fraction_STRAWBERRY': 0.07987627492305109,
        'opp_sell_floor_fraction_MELON': 0.41240677828767486,
        'opp_sell_ramp_start': 697,
        'opp_sell_min_supply_fraction': 0.10081480241978077,
        'terminal_soft_start': 708,
        'terminal_hard_start': 708,
        'shed_guard_enabled': 0.0,
        'shed_guard_start': 420,
        'shed_guard_stop': 487,
        'shed_guard_batch_cap': 19,
        'shed_guard_threshold': 94,
        'cycle_sell_enabled': 1.0,
    }
_BAKED_FR_ORDER = ('MILK', 'WOOL', 'MELON', 'STRAWBERRY', 'FERTILIZER', 'EGG', 'CARROT', 'TOMATO')

_FR_ITEMS = ('MELON', 'MILK', 'STRAWBERRY', 'WOOL', 'WHEAT', 'FERTILIZER', 'EGG', 'CARROT', 'TOMATO')
_GENERAL_ACTIONS = _ACTIONS
_ANTI_ACTIONS = anti_route.ACTIONS
_FR_STATE = {
    0: {"last_step": -1, "due_by_step": {}},
    1: {"last_step": -1, "due_by_step": {}},
}
_WEED_STATE = {0: {}, 1: {}}
_ROUTE_MODE_STATE = {
    0: {"last_step": -1, "mode": None},
    1: {"last_step": -1, "mode": None},
}
_WEED_REPLAY_STEPS = 8

# Route-repair and demand-forecast settings. The compact tuner changes only
# ``weed_replay_steps``; the demand model stays fixed in 6.8.
_BASE_PARAMS = {
    "weed_replay_steps": _WEED_REPLAY_STEPS,
    "town_demand_pulse_period": 24,
    "town_demand_check_interval": 4,
    "town_demand_single_shop_bonus": 2,
    "town_demand_multi_shop_bonus": 1,
    "front_run_lead": 4,
    "front_run_start": 48,
    "front_run_stop": 669,
    "front_run_max_batch": 20,
}


def configure_base(params):
    global _WEED_REPLAY_STEPS, _BASE_PARAMS
    _BASE_PARAMS = dict(_BASE_PARAMS)
    _BASE_PARAMS.update(params or {})
    _WEED_REPLAY_STEPS = int(_BASE_PARAMS["weed_replay_steps"])


_SHOP_PRODUCTS = {
    "BAKERY": ("EGG", "WHEAT"),
    "PIZZA_SHOP": ("MILK", "TOMATO", "WHEAT"),
    "BRUNCH_SPOT": ("EGG", "WHEAT", "STRAWBERRY"),
    "YARN_STORE": ("WOOL",),
    "ICE_CREAM_SHOP": ("STRAWBERRY", "MILK", "WHEAT"),
    "PET_CAFE": ("CARROT",),
    "SMOOTHIE_SHOP": ("STRAWBERRY", "MILK"),
    "FARMERS_MARKET": ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY"),
}


def _get(value, key, default=None):
    if isinstance(value, dict):
        return value.get(key, default)
    getter = getattr(value, "get", None)
    if callable(getter):
        return getter(key, default)
    return getattr(value, key, default)


def _copy_action(action):
    action = copy.deepcopy(action or {})
    return {
        "farmer": list(action.get("farmer") or ["PASS"]),
        "hands": [list(order or ["PASS"]) for order in (action.get("hands") or [])],
        "market": [list(order) for order in (action.get("market") or [])],
    }


def _seat(obs):
    return 1 if int(_get(obs, "player", 0) or 0) == 1 else 0


def _farm(obs, seat):
    farms = list(_get(obs, "farms", []) or [])
    return farms[seat] if seat < len(farms) else {}


def _align_hands(action, obs):
    action = _copy_action(action)
    expected = len(_get(_farm(obs, _seat(obs)), "hands", []) or [])
    hands = list(action.get("hands") or [])
    if len(hands) < expected:
        hands.extend([["PASS"] for _ in range(expected - len(hands))])
    action["hands"] = [list(order or ["PASS"]) for order in hands[:expected]]
    return action


def _tile_at(farm, position):
    try:
        x, y = int(position[0]), int(position[1])
        return (_get(farm, "tiles", []) or [])[y][x]
    except (IndexError, TypeError, ValueError):
        return "LOCKED"


def _trace_actor_action(step, actor):
    trace = _ACTIONS[min(max(int(step), 0), len(_ACTIONS) - 1)] or {}
    if actor == "farmer":
        return list(trace.get("farmer") or ["PASS"])
    hands = trace.get("hands", []) or []
    return list(hands[actor] if actor < len(hands) else ["PASS"])


def _weed_repair_action(obs, action, step):
    action = _align_hands(action, obs)
    seat = _seat(obs)
    game = _WEED_STATE[seat]
    if step == 0 or step < int(game.get("last_step", -1)):
        game = {"last_step": step, "active": {}}
        _WEED_STATE[seat] = game
    game["last_step"] = step
    farm = _farm(obs, seat)
    positions = [_get(farm, "farmer"), *list(_get(farm, "hands", []) or [])]
    unit_actions = [action.get("farmer", ["PASS"]), *list(action.get("hands") or [])]
    active = game.setdefault("active", {})

    for actor, transaction in list(active.items()):
        index = 0 if actor == "farmer" else int(actor) + 1
        if index >= len(unit_actions):
            active.pop(actor, None)
            continue
        age = step - int(transaction["start"])
        if age == 1:
            unit_actions[index] = list(transaction["intended"])
        elif 2 <= age <= 1 + _WEED_REPLAY_STEPS:
            unit_actions[index] = _trace_actor_action(step - 1, actor)
        else:
            active.pop(actor, None)

    for index, (position, intended) in enumerate(zip(positions, unit_actions)):
        actor = "farmer" if index == 0 else index - 1
        if actor in active or not isinstance(intended, list) or not intended:
            continue
        if intended[0] not in ("BUILD_PASTURE", "PLANT"):
            continue
        tile = _tile_at(farm, position)
        if not isinstance(tile, dict) or tile.get("kind") != "WEED":
            continue
        active[actor] = {"start": step, "intended": list(intended)}
        unit_actions[index] = ["DIG"]

    action["farmer"] = unit_actions[0] if unit_actions else ["PASS"]
    action["hands"] = unit_actions[1:]
    return _align_hands(action, obs)


def _fr_state(obs, step):
    seat = _seat(obs)
    state = _FR_STATE[seat]
    if step == 0 or step < int(state.get("last_step", -1)):
        state = {"last_step": step, "due_by_step": {}}
        _FR_STATE[seat] = state
    state["last_step"] = step
    due_by_step = state.setdefault("due_by_step", {})
    for due_step in list(due_by_step):
        if int(due_step) < step:
            due_by_step.pop(due_step, None)
    return state


def _town_demand_now(obs, item, step):
    pulse_period = int(_BASE_PARAMS["town_demand_pulse_period"])
    check_interval = int(_BASE_PARAMS["town_demand_check_interval"])
    demand = 1 if item != "FERTILIZER" and step % pulse_period == 0 else 0
    if step % check_interval != 0:
        return demand
    town = _get(obs, "town", {}) or {}
    single_bonus = _BASE_PARAMS["town_demand_single_shop_bonus"]
    multi_bonus = _BASE_PARAMS["town_demand_multi_shop_bonus"]
    for shop in list(_get(town, "unlocked_shops", []) or []):
        products = _SHOP_PRODUCTS.get(shop, ())
        if item in products:
            demand += single_bonus if len(products) == 1 else multi_bonus
    return demand


def _future_quantity(step, item, lead=1):
    future = step + max(1, int(lead))
    if not 0 <= future < len(_ACTIONS):
        return 0
    return sum(
        max(0, int(order[2]))
        for order in (_ACTIONS[future].get("market") or [])
        if len(order) >= 3 and order[0] == "SELL" and order[1] == item
    )


def _pickup_reserve(action, item):
    reserve = 0
    for order in [action.get("farmer", ["PASS"]), *list(action.get("hands") or [])]:
        if isinstance(order, (list, tuple)) and len(order) >= 2 and order[0] == "PICKUP" and order[1] == item:
            try:
                reserve += max(0, int(order[2])) if len(order) >= 3 else 1
            except (TypeError, ValueError):
                reserve += 1
    return reserve


def _existing_sell(action, item):
    return sum(
        max(0, int(order[2]))
        for order in (action.get("market") or [])
        if len(order) >= 3 and order[0] == "SELL" and order[1] == item
    )


def _repay(action, state, step):
    due_by_step = state.setdefault("due_by_step", {})
    due = due_by_step.pop(step, None)
    if not due:
        return action
    due = {str(item): max(0, int(quantity)) for item, quantity in dict(due).items()}
    action = _copy_action(action)
    market = []
    for raw in action.get("market") or []:
        order = list(raw)
        if len(order) >= 3 and order[0] == "SELL" and order[1] in due and due[order[1]] > 0:
            requested = max(0, int(order[2]))
            reduction = min(requested, due[order[1]])
            requested -= reduction
            due[order[1]] -= reduction
            if requested <= 0:
                continue
            order[2] = requested
        market.append(order)
    action["market"] = market[:10]
    return action


def _front_run(action, obs, state, step):
    if not _FR_ITEMS:
        return action
    lead = max(1, int(_BASE_PARAMS["front_run_lead"]))
    if not int(_BASE_PARAMS["front_run_start"]) <= step <= int(_BASE_PARAMS["front_run_stop"]):
        return action
    if step + lead >= len(_ACTIONS):
        return action
    batch_remaining = max(0, int(_BASE_PARAMS["front_run_max_batch"]))
    if batch_remaining <= 0:
        return action
    private = _get(obs, "private", {}) or {}
    shed = _get(private, "shed", {}) or {}
    moved = {}
    action = _copy_action(action)
    for item in _FR_ITEMS:
        target = min(batch_remaining, _future_quantity(step, item, lead))
        if target <= 0 or _town_demand_now(obs, item, step) > 0:
            continue
        stock = max(0, int(_get(shed, item, 0) or 0))
        reserve = _pickup_reserve(action, item) + _existing_sell(action, item)
        quantity = min(target, max(0, stock - reserve))
        if quantity <= 0:
            continue
        market = [list(order) for order in (action.get("market") or [])]
        existing = next((order for order in market if len(order) >= 3 and order[0] == "SELL" and order[1] == item), None)
        if existing is not None:
            existing[2] = max(0, int(existing[2])) + quantity
        elif len(market) < 10:
            market.append(["SELL", item, quantity])
        else:
            continue
        action["market"] = market[:10]
        moved[item] = moved.get(item, 0) + quantity
        batch_remaining -= quantity
        if batch_remaining <= 0:
            break
    if moved:
        due_step = step + lead
        due = state.setdefault("due_by_step", {}).setdefault(due_step, {})
        for item, quantity in moved.items():
            due[item] = due.get(item, 0) + quantity
    return action


# Activate the CMA-ES-discovered configuration (see docstring above).
configure_base(_BAKED_BASE_PARAMS)
_FR_ITEMS = _BAKED_FR_ORDER
heuristics.configure(_BAKED_OVERLAY_PARAMS)


def _route_mode(obs, step):
    """Classify the public opening without relying on hidden state or names."""
    seat = _seat(obs)
    state = _ROUTE_MODE_STATE[seat]
    if step == 0 or step < int(state.get("last_step", -1)):
        state["mode"] = None
    state["last_step"] = step
    if step >= 1 and state.get("mode") is None:
        farms = list(_get(obs, "farms", []) or [])
        opponent = farms[1 - seat] if len(farms) > 1 else {}
        opponent_hands = list(_get(opponent, "hands", []) or [])
        state["mode"] = "anti" if len(opponent_hands) <= 4 else "general"
    return state.get("mode")


def _run_action_tape(obs, tape):
    """Apply the shared heuristic stack to one selected production tape."""
    global _ACTIONS
    previous_tape = _ACTIONS
    _ACTIONS = tape
    try:
        step = min(max(0, int(_get(obs, "step", 0) or 0)), len(tape) - 1)
        action = _weed_repair_action(obs, _copy_action(tape[step]), step)
        state = _fr_state(obs, step)
        action = _repay(action, state, step)
        action = heuristics.repay_premium_shift(obs, action, step)
        action = heuristics.repay_fertilizer_relay(obs, action, step)
        action = _front_run(action, obs, state, step)
        heuristics._detect_opponent_type(obs, step)
        action = heuristics.price_floor_guard(obs, action, step)
        action = heuristics.rank_sell_slots(obs, action)
        action = heuristics.premium_shift(obs, action, step, tape)
        action = heuristics.fertilizer_relay(obs, action, step, tape)
        action = heuristics.opportunistic_sell(obs, action, step)
        action = heuristics.shed_guard(obs, action, step)
        action = heuristics.terminal_liquidation(obs, action, step)
        return _align_hands(action, obs)
    finally:
        _ACTIONS = previous_tape


def agent(obs):
    try:
        step = min(max(0, int(_get(obs, "step", 0) or 0)), len(_GENERAL_ACTIONS) - 1)
        mode = _route_mode(obs, step)
        tape = _ANTI_ACTIONS if step == 0 or mode == "anti" else _GENERAL_ACTIONS
        action = _run_action_tape(obs, tape)

        # Shared opening: preserve the anti route's inventory while adding the
        # fifth worker needed by the general route. Grouped animal purchases
        # free the market slot without changing their quantities.
        if step == 0:
            action = _copy_action(action)
            action["market"] = [
                ["HIRE"], ["HIRE"], ["HIRE"], ["HIRE"], ["HIRE"],
                ["BUY_ANIMAL", "COW", 2],
                ["BUY_ANIMAL", "SHEEP", 2],
                ["BUY_SEED", "MELON", 5],
                ["BUY_SEED", "WHEAT", 9],
            ]
        elif step == 1 and mode == "general":
            action = _copy_action(action)
            action["market"] = [
                ["BUY_SEED", "MELON", 7],
                ["BUY_PRODUCT", "WHEAT", 6],
            ]
        return action
    except Exception:
        farm = _farm(obs, _seat(obs))
        return {
            "farmer": ["PASS"],
            "hands": [["PASS"] for _ in (_get(farm, "hands", []) or [])],
            "market": [],
        }


def _kaggle_submission_entrypoint(obs, configuration=None):
    return agent(obs)
