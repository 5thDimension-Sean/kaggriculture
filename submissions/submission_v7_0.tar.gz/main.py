"""MapleLeaf 6.5 -- Filip Strzalka route swap for Kaggriculture.

6.4 (Nikita Lugovoy 8C/4S route + widened premium market-lead) was
submitted and started climbing the real ladder (2645 shortly after
submission). A forensic pass on 6.4's first real losses -- all three of
them, HealthStone/cf696666/Efnutrrionpy, essentially the entire loss
population at that point -- found real signal:

  - vs HealthStone: WOOL revenue alone was a $9,669 deficit (us $18,216 vs
    their $27,885) against a final margin of only -$3,092 -- i.e. without
    the WOOL gap this game was a clear win. HealthStone ran 16 animals to
    our 12 on the SAME hand count (10=10): more output per hand, not more
    hands.
  - vs cf696666/Efnutrrionpy (same opponent script both times, identical
    sell quantities in both games): we actually out-SOLD them in revenue
    (133,801 vs 116,493; 155,367 vs 137,242) yet still lost on final
    money -- the deficit is in spending/timing, not production, and
    wasn't cleanly reconstructable from observed prices (large multi-unit
    sells shift price mid-batch, so a step-start price times full
    quantity over/under-estimates real revenue). Recorded as a real but
    imprecisely-quantified signal, not chased further.

Given 6.4's own docstring already proved "add more animals" is a net
loss once bolted onto an existing route (Fibonacci-scaled daily re-hire
cost), the HealthStone gap pointed at needing a *different route*, not a
patch on top of this one -- so this session surveyed the current
leaderboard directly for a stronger backbone, checking self-consistency
(majority-vote reconstruction only works on players who play the same way
every game) before trusting anyone:

  - カワシギ (#1, 3198): 62.7%/38.6% self-consistency -- too adaptive to
    reconstruct, ruled out immediately.
  - researchstudio.site (#2, 3161): 48.0%/48.0% -- same, ruled out.
  - Filip Strzalka (#3, 3154): 98.7%/99.3% across 10 real games (6 P0, 4
    P1) -- higher than Kaito's or Syed's own consistency in earlier
    versions. Majority-vote reconstructed and independently benchmarked
    with this project's own benchmark.py before adopting anything:
      - vs the actual shipped 6.4: 18/20 wins, +1,692/game.
      - vs main_inspo (5.9): 10/10, +29,448/game (6.4 itself: +29,788,
        i.e. statistically tied, not worse).
      - vs models/5_6.py: 10/10, +33,774/game (6.4: +34,428, tied).
      - vs models/4_5.py: 10/10, +17,084/game (6.4: +17,542, tied).
    Net effect: a real, validated win against the thing that actually
    matters (the previous shipped version), with no regression anywhere
    else tested.

Tried and rejected before finalizing: pooling Filip's games together with
9 freshly-mined real Nikita Lugovoy games (99.7%/99.7% self-consistency,
also excellent) into a combined majority-vote route, on the theory that
combining two strong, high-consistency players might beat either alone.
It did not -- the pooled route lost to pure Filip 0/20 (-877/game),
though it still beat 6.4 (9/10, +904/game). This matches the same lesson
from 6.3's own history (pooling in Erfan Eshratifar regressed the
Kaito+Syed pool): pooling a real but *weaker* source dilutes a stronger
one rather than improving it. Nikita's route, while excellent by
self-consistency, loses to Filip's in their own head-to-head real game on
the ladder -- the pooled vote pulls back toward the weaker source.

Also checked (not adopted, needs real route-design work rather than
mining): カワシギ and researchstudio.site's *actual play*, since their low
self-consistency ruled out reconstructing their scripts but not learning
from their strategy. Both currently sell roughly 2.5x our WHEAT volume
(~1,200-1,265 vs Filip's ~479) while running with far fewer hands than we
do (8 and 4 respectively, vs our ~10-14) -- i.e. meaningfully more output
per hand rather than more hands (which would cost more anyway, given
Fibonacci-scaled daily re-hire pricing). This is a real, well-evidenced
lead for a future version, but building a competing hand-labor schedule
from scratch is a different, larger undertaking than adopting an
existing high-consistency player's route, and was not attempted here.

Everything else (weed repair, the repay/front-run state machine, the
widened 9-item `_FR_ITEMS` from 6.4) is unchanged; only `_ACTIONS` (now
Filip Strzalka's route, used for both seats -- his P0 and P1 routes
differ by only a handful of steps, matching the same near-symmetry seen
in every majority-vote route this project has built) was swapped.
"""
import base64
import copy
import json
import os
import sys
import zlib

# __file__ is NOT guaranteed to be defined here: Kaggle's actual grading
# harness (kaggle_environments/agent.py's get_last_callable) execs a
# submitted file's source into a bare `{}` globals dict with no __file__ key
# at all -- confirmed by reproducing the exact "Validation Episode failed"
# failure locally via `kaggle_environments.make(...).run(["main.py", ...])`
# (the real file-path-loading code path; every earlier local test in this
# project's history called an already-imported agent function directly,
# which never exercises this and never showed the bug). This bare
# `sys.path.insert(..., __file__)` line, unconditionally evaluated at
# module scope, was therefore a hard NameError crash on Kaggle's real
# servers regardless of single- vs. multi-file structure -- the actual root
# cause behind 6.6/6.7's first three submission attempts all coming back
# "Validation Episode failed" (two earlier, now-abandoned theories -- a bad
# live-engine import, and a multi-file sibling-import problem -- were both
# real cleanups but neither was sufficient on its own). Guarded so this
# never crashes regardless of how the file is loaded; local dev tools
# (benchmark.py/evolve.py/build_agent.py) always set __file__ explicitly
# before exec'ing main.py, so `import overlays` still resolves normally
# there. The actual Kaggle submission artifact is built by
# make_submission.py, which replaces `import overlays` with an inlined
# in-memory module and needs no sys.path change at all.
if "__file__" in globals():
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import base64 as _sub_b64, types as _sub_types, zlib as _sub_zlib
_OVERLAYS_SRC = _sub_zlib.decompress(_sub_b64.b85decode('c-qxHYjfK;lHc_!aM}+mW+hp&^O*5QQ{{1##5IoXvz3{fb?F#df^42CQ6VWmb}Ik<`T>9dACjC&wsuonI~LezG#ZUYccTF`o6Y!6CQ<O1c9)N$(-9wn<W^>#aFNL<3a{m2B83JKiM$K%<W$U(cn*-uNFK{zCSG>;8m;Rv6O(v8hyT2oz5H?V<F3~h%Q(pZK8r=NT8MZ7e=S8k6ZbbkCIPFs3MRK#@j{9uUS$$6y=(;2c$uYL@kT}xE8pM5kxYX~iV*7GAkcH5<UR?ZLd-=$ny%){EL1-i@}3bkrr~t)*9;1fiW@oqJN$|5CbE;s6wwFQLAXdWx1LxnvM>^h_`cg{oN*@>GDtd5_bSN3xoD-qT#7V<est!+<R)Cmoym=y+%99_T_=hsx9~MtO|n&j^dbI6oP^imB8ZUD@H>SM33e+>!U-U1iy%s5Fn#RY1yMK+u+_Po+ysj-ou}}1L7iws@jcMqNy7A2+y{@y-g$5<se>Y0ErKg#R*L1fQZBJPOhgo4hZ7+mf=L!V0!0nvU?vxYHeNuPe8^-1<c0qvT;kyPxN~@Lb^+rG910d$>UG5sSnz0Cxn0CpjR=Gy#nE{)e0%Wmc;ufQoF9C+_`8?{QG}Ie;WcofwG5JAo_f$22-OlsVVT4enWj6}z{?Ksb#l|VlCv0ivI5=!`AaP0egXPcDkZiYF0TD_DJLkhJ3`*Y(Vc|9fw%+F<VKneVBre85o9pf(9m=RO%*7#zkm?`H5F!ruH;Q{7sg3LGpscSz=#AH2|&pU#5A1EWFi+?L6AKVn;}Sro;qT-T1-ehLuAxcE+zcm0`X466gk-;c3#2nB)miXVU~((5P^nfKJp_FDbxa4i$qIyue(?qzD-aD9}wV2_}3Pa1_$P86kKEJ+aOA%2U6FVBSR5Aj<0-x+W5mD1%9IlXgS1T04%@-|LlA?{BSn%KOFpze|UU)GW6dZU5pM+4u>!V{`v6u;CEAkKs;HYx4_{4lama13%{~BdF(ct&1Rz!&QUpl;AS_C#$Rye3ofFW3Ki$1i3G462%Cn9q+uY{gT&*c1@V$osC*k-Uq{lHi@Pw17jx(hv<m|gTuagVL{%z4y6_|I;s=<1s|Y75;8Jus#W;VVDoBR><k2|X#Uaf_0h4punZ!#PxLL*mcM~90OH`NfDg~;qQ8JKTse~A6qQX=xVKoMQMg<C_fh3Or58y~wSMxAUQF2;MTjRcLdN92}1)<=H3j=lm8flewhv(;~=VAviG=F7Xf+&W|Fa>ssSr7u_np%6pSVtlXrc;=bt=-=4%TDiy&h9P>jF2?lmkCaVzX<q|vXTulrAf1R1$qzk=mHfP=?{><JE9zC3@|SPB@4akB&b#A$mCqV&48y`vjGF{SyQq;LUpW$1EdN1+!g0CVEKi%VnFn%c3fY>|Nq4Q|B0mrBqoH;2h7xrl|RniFa=COG>>5!n8+l91p!)LEz;GJ1#;&K^*O);8NX12AkLr`R?ye$B$(11f<9cu4}htqXih*$g9st#QF&X+Ldzy-2GAC5&^k1;qgjWm0+LA#%P;ZzKFml33K|Jytx}sb3P6a~NW?(uk%z;!04&)}yt=*tU84Ay62Gw<0W5CG9LGHdEiI<<PS2>WxZA^(ULrWkI^fY#9s&<?eMBk?WCTFN8GgEYgw+t#MF;<|S5}-?dcKN&cW<}*O7MIF`ac|;|1#7ndFSH&>Dk2&PktZdZX$Qi&W}K;ygfcWJx7UF@JBsR(y$aF1!>G?01YS0CF|H!%Q&u4n(u#2i5?c#6y;M%W><XjsWXqhBHqV(YU;PVPY8?HuHq~MiHc{$;}F@(OKt!w%&(o(ljGl&J|LSww3wy|Ga%5zK?9F80~$pFO*%A|Lez~5kT6`VXFw}VlE+F-w_2hM$}XzW!MFPd*hXrVr!^Ifu_PsCgRnti8m|&G4rc<)ob0Aeg0Y&D7!+3N?l-2aQCP+Y;*W-af24Eg;cBiHk4^-u7?w#k4hg8KVEpt32FO=yWpiJsfBkN+T?Gi@n`Ai{0PfZS#!DMcy!@dWaFzt59SrbpP1CTr`(z$z$h{i4aN*BZxMKOAvqu2ltptmgOP|(vKf3`X1@<*||G9#lhe;AA)TXvB?A~Cf6|+H`ft3u_BHGiS%eX$4`t-ZN+nli$h;9Pg130!{5V^5Q2B3*Sw5B1l3RG2#Y#3=Q3%!VXCEPgrIq7@tN&x>x26r&u7a?dvfPPs9b4Pyn)elu5_L#qXxoen2Dhw>K80Px*DoCb!M4;HGVv9}0B2_V_#RujQ*k}`2vyx@BN^zBl7z2(X{whnb#c2anl3wwm0;V9i;#KcO5s2i_p9DFiVh611FZR)_?|@@A2fHMdJKSxMF`0n+)$*Q-7OwMT6WxFZ1XDBs2L<g+Mucty=oSC;?99Iy9v}NhqajRl&^-YgE6deY1WZ}PnY@bQTeMSCvV}u1vo+&2CFSO!aWt<d=xJc5I-q%R1vSnV*zd(&r_#(<|HIMoFQ)swZUv8Q=-*CHkGF@u7@Z&d_A}UTzeAmk&>x0ii)-W+&@5neg!ebW7f9a-Um$)Xe1ZHjJghrQS9V|aN^*;84{f#R(N?L%4J8Y(bj``Fi^9(<WeqbD{l!mXOUJ+JX*FQJgP=~W?>`vaBtU5tgB1}hZc&WT00c5RDGHbe{?Sy<(STYd7*BZ=_cFY`VKHrD9X0y^MOxGa1jE(+AX?r8)Un;XXE^6lu)jMnBZEnpJ(9~gL%WEyP3~``l0DGi3LvPCPY^9nY0kXJQ7Jt`hXr5{$zHD#AlD_Y`ahNd?4{?&3Iw*E!8PX#nm6w)JG9QN+d=bx$MN6XUto}sm2M1D?bWbh+UAHwf|d+fjRlWL^OL<Bz%-2~Xz0VhEB8&Y81$LAzj<T>k!(ZbEVfZ~K>^`sTd>>6?b?Cp_uyZ{GJLVD(Qr&<WA-$Edp|rFX>R|~L=}O*KukpQs0V)<)KGwc&wKb6na@6kCZMR9eufdnwO5tH2w%&L<n0H9rcN2?D843OU2Z||_P(g$JUjq5R1=odwO3Eqi!xp4?n!K`NEb|yGF^EuN_4$4bd63w9E?s&biM4=(Y4!q0$siC^C!{u($M9oPeT{lnKg9vpEi!KD#kIyxMs6mqN{Jw<)~>x*Y1m2y7nsQ$|a^m*KQTR7`Q~&o<-O2-Midg$;WXGU3<HKavZmkduN%=$FW|%`n$VN8ON7jIgZY9o{wX1jeNcMe&d+)>+SG-baZ_5kKwr^_q`|0$D9LOjbk0Z5c&%(Hx!A;mF&+4zYJ+&>VKCce{HRP$Eq`DNB{W8fsd6H>?O-X+vuHAm7mW)o*cgSFV3{GETC>XszKNK{oworEUwe@p=pQ)SbxX0<M4cV@Ie!EX=7;%Lso%)VD#a^+o9>{rPkvb;^M>U>FE8@&~&mAv4(zoaQ<O<e&O>N5*emf3bDf)x2Lr1t2rvtWq2!7-amK%ry)hNe}s!N4<`n;9(G15E`*Ep?Lx}7_`C|H2^f77j<W=~X~JuCn03XhHS)v&)>jN%P;?8oZO|Y{WATXv;}iG>!GdFxxbwqtA6W8nk>?mGxH3!GZTRnxPTmducLzr&AUi*FdyPh8D#4kd?=6(Sws>fZ(clCeAa9?T^Z=mX0JqTA5)W*Tg)`bUK+3eV?t?D_77TQ<1OfAm$4f(qXO&ROYEw`ceeYsntEy3$==-7o423ONc*WmDb&Wnw*J6!+uf7fsEwe#=L)&PCv9XbOJrKS8o83QCxB}iifRR0F6hKzcpgkJTau%;d2h9ghJbNZ~8xC3?Ej#|$LNBrnvULZxU7UdN#(PZm05+S=x8&;vnXs(3uJ~1N7;?OCmIvHT{1ZfIzKVh_Zi^tUC3Hybl_3)xo6oyMV#WlAY7#(~m#i?kkgP{20=3BnBmO;7KY_ibBjPoH=iHqsWVu!yn{VKT*<Y2m90N~@iX9`~AlUFf&s5~_$AH29MtGiCz(8)t=B%nIqg0j%vlMs*VU8MqDq)=xVL6jJ0+$_C(+KuM%Nk|`&ss^mT1;Dn*8`tQP5X86WFtG3L1R#B8^XpWZcTX3SBpGk-1@Y9%x>bvp6E<OQ`b`)`F}Tmb=T6@{KUQ9D*lXn1<G?`mnYvEy9v_8U)kZ!cfz{jBA8Jv+>Y8wZ^Pw2@B8qUQd)}JgEuAFZI=(rC<Jd8fMKBGTRCkjUIpl9(LRry%`iF$Q;vIYwn*4<Gt=z}+k=}n2bo#0Dglft>RMjiAh%<xARTXSV5^Zec(p4yaP>r6v?>AH1$9z|S=l`UL4PohK;kHt1`Di%z?!58vbdvtdYCV0gXdk}*%7;K+ltFSJ#)Um&ljGn@C(#cYi3%&Yd!%l@*fQ~_hG&|sV~lMvyL!3`^=TH&qV30if$99z3;m1_BgV0pG$#Xbm*Pm4KlC*-RYZ;ha>#VBSJCJgP)IwP?D{dk!<;eQN`{04@VzA;7U@o&B&Lttv|FGsR}jY|NOguaB}qF;22Hc=HcmYXfA8ui}%AJntWUf3f`TbUZAN+2J4rG|L*wX$p3A4^zQvAH=P~77B@L^mlE8$wsDyFlk!r)L2%r>e)mP&a^3sgy|xu$=yO#S2+3n-j%z{1K;+>$TlTH3Em1=;Fp9au^^rY>EruNc1a*O#AJ2#WFGnYD82Ieq0!yg5Q?Q%??7u%Ayg5HO88N^KAv+<63r0-HFzMpp5G;KJ>+dyuz5jK1dh+(@-N*BT(b4G%jTbIY>6uL41hoJ29B^du{o>*#US7y3I>KGgJKE^bpAIFK6+Z4hC&T-gwJ(_>ElS4W?Y%sw$MgO!C>WTs>Lq=z%p6$%0??5u7{zBm+%%kIEqCWmuac!4A+s``Q3eogSWjR*p{#*?KT@PHXRFeJP#cl04!;Rio^A!6!2N=>zSk9pwAE0^M-nOtNpGxUdQxh(Cn)zJrv+AN;7YJG=~=Y#AXTQt#pqx(q@JhBD^aO6go?KOaeE@eZR#|W%fX<>o7o&POw|fWiBwlIyO(mI$jRc^EMeDCd<7Pze@4IRnay9jt0huynV5fkQQwFbKj8f$05Mif>BGKR7g8ByTI=^M-R*xk!Xy-*Sa69@W0KG)NHNeZF|ga|gAkInlcMMUrHwuWW?H~6w64G8*e>25y&XBos<BO1viO@&Tc|i&X)~%C!YG@nwxyoc(COLP>B;b9<d1$o%URG|Ep8Vu@tTcqzhi%havNWP@g<`r?$@_?I~UWb!UfC>%y9$p2dTZ4%S>f|Xo*t^J7BH>szt2KolcxgO+p22V8jcJ&im$D`y_5)!?!4buMK2^Tc9+F?Qx+alhWc0vsVM7)LSB`tabX>MVvM=7I`Q|Ju<*Qf-FlkrY5=(Z4yG`v*IkoeUTPdDmTRC6|Lmo?KWIE)pb;$K5t^R_&=&0{-LL~`ejXC)y5x&sOBt4<`Sa@QJCr)#0LGv!}^!FE?qRoUOTUerh7_}9jeL#V8hbP=VF}tHg2xVsK?&e!pb%lMu2jx>o6(!0;(@2paS!$1+uRAqx#=x7dLB>5W!~{%OzNO5`%p`!qrpZ9`rJWiO(QU7#<O81qX#G@SF&?Fj6@n1hN!$HVyPu&3B-NG~{a$$wiC4c--<Ic~5ZLE12Ng(@MjCY7xH)B6NMRge+)hm|OI<BS7=$ztGafzsn^#oD1U_5>zq;(1FBoFCFni%7GY*P5A&AtNIRC#DTC`&xOD$kW&^{1+3ab)qA_op&9n0?|6(@GH%;~d<qhJ!mBX0dAHC;>~+!3Pg@>0p<Vb;x+9n)upr7~xs210(**|Nk}6`?+h$rp1t7Qw^F}<&kt-OU1U60%S%8(2`8o{&@K#L9wlyOa<~7rcO_DGw^ih#PAIe>0QNw|<B@gA3DiCbH=jE;+=>3PbO*{^XT&#dzv<B>6c}^&gYKor*B>aY>)PVEJ8i|7Y2c{vo?kkxGZWI;_`)Guhglt?4B3cWC1_kj)F16Wl@`w_fHV-E1?gk2g6_3z5%Brq*Npj$n^v9k}PYY{#Ox8k=05pyTtsVwCAC-<!V}Rx)l|R_!mycs_6NmEH)f48HH3Ev8m6J;K#uf!6)cOsqpup~%bKD$oC<PM&xswv}6pb3a0hG~p_|J|H4u?(pirldvJd~=!AX4;V;Na<x9SCGEI@F5Gmk;je{4j^*7F!;j@r<o9;~bN__k|`f65_d}&FqsR&>c%`ks4*zuzvx+Sr6R8AT?<rb1S1f<xncEtspU#QbRmQ9?Ou4{Ji3`GA#2p4|hSa0R2@1u*a)h-@zvzCTMoHMvqH5M8mW#enn%5{@#{KON?47v@;JEEhXlLT+fQ)8rGu?;CXFZ-0V<uWt%$sMH@-*EqkO{qo^osPsH(DZ|1ad3lo;!bTx08^{z|C9|*kXN<lD>SBng*=3PN<n<jbUwyA}Z0CDXy|4g&IZ-6?}5Mr~0Li32iwlNIocW_irmrF3Mp~Go752GN#9`0aVH%>7{=eu|nS~au%t)$HndDZb2sY(RO^*a9qrLJ};lpr6Ws#KD^NvJh;^cFjPWASq`qfZBi{4~5?1UQ*#2{(oyX0lhT?`1PXSsCc8Vh!-xoeKN~)_mR)U1S>#AH%dt6G->PQ<jLS+r`6Vi)kybPm0fpBop=JHgh`xr1Da?fLl6NAk4emw|;Ts6BOW-7Cre0o;WXZl4fh`8AtuVq|yOA{Id|I!w}+d_@=2AyT?#Q)9n$eS_qWH_XM=w7;~fNv;aXRs_S^SP|~KsSDwQq6pZ(aI-p?jSWCy2dUcY-xS0m)Nh@DLun^a>rss86%O$wC1-(TpOsSe$c-B<J1*}w!R<$*i&<jT@flWNxRb9jKO9UH>zYPitP(G|Vgr#kBN(jiuMJ=@)$Fkz(?r)}t0oPMx!TcGTh_gUZQMzks!wMCYX;f%!(X^;Vz@IG?<zU2p49<LlK?O7xc<NiR0j09wGp?3>@%pt0Sy{Bj0?)ZQ4o4n0C-XxCC?qysqf0RCFd>X|LKnevJ%hy)E`o1%%z`^el@+hXtOdS8sn~dV#1XF=`we)@(GR^)m?IS6z|Fw1NiexsFK%&0bF;tO#jUmADy5|j0WZynfI8~%1~%5T%RLJT4DBmIVqwsO1{nU=#*mkL-7ByPiFIlwM@t}asTVWGlMfQEw)8<^vcDMR3PvXRkC<?MO`Bh4RmdeYh9-8g&j@Tvqa|`^iFQ`Byo~o_SYmd^SY&?KZcc=dunO`TG$sQ(amzN?j-2Za&GouJkiH<=p?*(=pSrs*46xy}s`ZQ}1CCk%Lv+QfXV4Z`*!h2k%a-nr8mVXkza}nkl>iqRYl?FxA69e3?YUEpnjyTl-)SgqVFzfr!cO7TjwUEiD!R5uNj4(yf-6y&^1nqdsUvE}jFp7v1)dXoBitsK8iA3SPmnxV_{6xLa&c7j&WRA{uwxH%iGH*xshXnejJ=eN&GjH;fU4fb%7*r}*=%)?VvYkVMpqNW>!W{y@lKsrL5R@gK`RZ@A$yL^X7--{!)+aFDYbL&W>FkGb;bQEv&k}K4AW7&*mV6=%zd+mC^uiMDvg5gH(gCg3QBwXMC2A0TZw3m^y}$X7%E9uGe^Vbdm^B$e7qR}XkrON!-Oq^!cy1!&z4Ku=F(>pOEo!Sv}x=R2QsK!-_gN^01Zaps-jF7Z#x-ryltbX*Ed~gwxG2Ai;rh#$G`h;&X0Z_p63Z9DnG>TC`RDCJX^&6#GyE^>QF^atySz<`6xMn%J-lY<bu9cht1MS5J^^}<lJ&^Sxj-(Ih`p4|A5O1FidHevAm*mduufL9Mg^lg{e{8!vgz}zj!(aB23bCwajWzs0q|kgKj#mA{1@QaHg^Uq%9jwzm+mcDi-5gl<1=>>?oy+4On@TQ<=$0mh(J&Tq<7Uo_oFtjK9Qx4a!UM8s_22K@(GvDzs6}hPn_7w47sk?KEGv?e82kZkWlIqxoqdo^OE$tRJ6k^kzk}Y+W_fNYfyhV%C8RgVU_HpQj~2|E*tNzC-ZuTrPu0;QaI&<exJY!1Pu*Gb$m5i@#4GP~BAEPgk<Vo6Kz$;7ueZHiV07C17BKVH9kfFDd~oDqPF*HfRG|*^>a{Z2cIdG&%H!h1&k6NI6}>gunIX23lE7tGG|aWRf-NV)ItWfGh2e3+s0xrz@RBfYZ>_wmV*fzca|I7eI9HYC(tx8c{i=zjiUy-4KJke$Mh$)(w`JlcHE@Ya96JrY?mue<AOEC1WkhVq#U&7I-_vBTWAZT_fOX7V^|E%L#wHCgxIIUi$KsA&!FP{URWs+rh1DK>BuRRUVW1D3^8*2<SV^y$_TR)KM4Oxc6lUyb$4=PdS|kcKCjH_{-Vpk;-<&Ls_qQkHl*@$zn<&Juy|RU18?*pN!>8!_G9Tr=&K`tb&aG(=Zr&L*2x|8F$5{uX<(EVplEo6)AaY4pf?mg?~{nznTWczVH-U%TtwHSeXyVVs6hkbTTU>hV4%Hu6EGXBvS2;3o|eOaEX=1Wb~AS0jP}F`tZ*#D{nq=H}QigYE70E&2t2?j`)J{ujfBA328&T1&sMVVU<=;X+!E>nytm7B8#$CR!X2x5S8uargj!M-7XWOc#xna;XBvc*tttZV-aNsN4ok7pmE8x4f3_j%&cmz=ZCAD1;TWX*9SCI@n<1NW^I+%g&LLw8BiJ<T|^Rv%>3ian*Nw{!m5lzb}@KO7?jfo3yFD+HJjv^TH<!DS<KeTyJlKkW1&@Sjq9y+m6M>!8w-6Tr14~)x%|=@f_$|S-qw-&Fs<~Rj~uGg*2GPmg#Sd*qwZ<hn?9&D9t>RtVMJzX(x6<7<*j2wUAl^pPk($V8m0vlmw<d+IcSauV%uo7=GG|uD%+x12$pEL;Jy`2Q6%b;Vc2BD0&1KKRic44f>^#=2;g!x#q$j_yDcg?wt1$T%&RgCUu`nRr9l~eRWLCKkhe}>@M40pT(gXCvx=|RHN|<gjvVsfk&b-b*|$@!u0vpqPs7RqLpncH;a?huoNovn)P<qzk@JxywYx_vrrp}Qf9x$=&2vzN<m#tE#W+>nbe22tC;%>XYX|g6>QGH8{zTOEd+V_0UesW1GVUfvbgRj{U+utIbJw1u`g3t6b0&4CYCfBU;0fiWa(pG<Wl;>XQg_?xMzqvP6gHhz8j}><UK>vg+9yp|FVnup(=@aeJg=BI%6K+x?U9Ia0&~95W=R-CzAGzA2nsOvh|@Az;ey*cFLjcda{w>>bH|R$-Au3QoB<0%mBK6BEI8iMfv3yL^hs-FXgfz0IW0|}U@z>etP;E}wOC)JaD%L9lR$T>w87#acui`}oW<NWBa#l3t9VJNik+q54r&$8%cgVA((*St!%!Xwa~0&c0w2=Tw@;&6!}_dZSj}~5IA>jSC2lHCyjB4b%1E|^y`<wdB%0<mbrk24m6IM-Zm%E{1umPc#wQH~=qyI=;#Tw7;A9wEH7JO}`Q(j;v<vCjr#2rh_xru^6U}_rqHJplt8UD278}>P{njz2w}p#AzkNuFkMI>DO1u4+ur^>^Y4_!GuVJ6_dvZu=(;>gD!#rP!|4SaeR9BFGqZrVdV~|A$|7!w1oBE~V5alD7b)lg0NdF5WL3J0@enm8>ME`dR2Jv+lczZ{Fw{6Qh$rjEETSJ@zfB<|Ck8=%f(Nfim(b~&%-9vCSRS?RK-Q<@DGf-{##uDqQ8Nqw6O6t@}h5D$9*@M*;ssb}~`o=(feH^Cur@}B5tA-OE+2oG2ol6j$07}7u<g*c8<EcHX3YKgh*3G_q#ZA)dLv)+eVXfS#M(v#)o{t{y{gmTZCU{V~C)$b}3`7ZHW88qQEFY|!&kf6RRKl*z0EB6{20eY*GP-0@Va#4k&1+PcyA?Z(?m^x{9LgeRT<<ko9_&|akJ@tH$Zc5HcHPRwR|k~U;pB}6lfTO2N7uf>H?BA^TXEEtHN#yH(t&i>048Kup*Zth=g)MlCWH{%%&%a41=9<Lahbfl$O#+7R?xsikJ;tok+W)=F*SgjMs?drcgYWNxu@G3ZwNN$X8hLXJI>p@fq#jKeo?x$`sz{LiN?2A16h3Uv{2VpTNj)lSck6i226Ba^EbEf|3dG7;R8r1rke$n51qvo*XQAN7V46H{m4?MLsS7fCA|+ci4%N22vgT5(Q2ySKQh-!PJ#rl&hF^DA?X%44>$u*c#ll5pjS{539N}E-ux6~<{6v`d`-hhz2-#sw_(;u3^wfJV#3e2gju)Y+t*VG_qHl+#Dyuvu9Wg~?lrKo3h8U<AoJJemC%-@bM2HShUCDfTg+KG*<|T;x{74`Dg?5ro1JhmYpSWsCvh={P}AU*PvY5Xpmx>S_B5%YrKd8|@@=MdA<0JZC^bRr%_wtsz+=VL26oufRH%q=+EFgMC8Ncyn-MvL;U77{E?xQaD$dr1$oz`C(Mm0QHtGnbUQ$H74Hi%w`NmwMBnsx6eIKXWkB;5Al@Lg`;4k6BRNIsK-l%}hN-GN!Z?<wrIOE(lm;32WymZe2Aeennk|4_Ye{|25CdMAJ0!hw=To|1oEbt%GydSD-x0I;&+iQ?jUFFpljP$u;w^G{!Bky!e(+ww^Q+M_og&c8`R_C%g_6`9U^o-{iXF49Os}_&=Q{#9t#AVTr+gTj`)~>cSG%ovMmVUmcjxGLIovAUQ`^%on#fn?c?9s`4oOh_$pF+d7sB<NgH;h`#)}sZ2Y}H9nI2v`@*91riP)B38QN>hay$aq+>wahT`KJ`3k$qMz_yWS#iX&fBQs+#_It>T93Mt@I*Xnr>HeBgK!j{6Op8&zfK>C2x4dc*A!gSy}lJh8(^X|tOXN+pXL{QwvLtG!*>0;sLEbU>}y*{$m&2|t&Z{6Q87S-1iewVD1B)+F(>a8s&SzB~Mbr6mV+z7oo2WPz4{1}{e>%x+i=6HWdPxS#YJNynn-84>c%Mafkk%LjPQjQId2;a1UH;DlxroURJS*U?J2jp@gA8->EQB;x2ij{lkc<YQ~TpP`?U#sFrW421NDnD_xR<Qo`e(|5)rhmP`XD_9L7dYrR(Y5+`%gs$kJ-6{`G$I}U`>l66t8=L<Bn<Pa{}t}(Y3<`@-+nKt@X8oo#OmCQTYD3%THZ}+iP=tVaeUJ<N9!L)Gf$zZOFZ>cXf=<Zc?w<qTWGE3g}xAIDuyuB@f<#%#Q^jO!cR}7X+jjT@(XErvKrlFd<~=1>%RN}hB}F1B}0zvAbWOlp6n1q^eb>U{jI0n)Ln-gpIqzOciQ`BG-YRX&z{lY)Gy7p2CRX@m{<3Oj&~8et8f<{C96m70uuKA3(s@*tW?mq>IJj1@<VFb>{|wl+;VjgaLgDDjXJc-BXJB5qGeqjG{~V*#}ZMO^y9(v7PG5EWzIFQASlWKG$-Gj6+jK)w%Hz<n>aG-XA(2YI(p|MpVgenvnx%*bYfkyM2te4Ylr!cKW!{tZDoLV7+duK-MC$>S!VUKy!X$F(2C{GE0AhA*}U|Y-iCA&9t*ERmUb)(vghsp3-gGd8b<#nMuUAD<;Lv0WfUwH_!YCv+$7wuHU}J>m(I#hmv-5o&Dm|sI4CC87F;&x1i!nWl;Zwt(s{06!MSbx`TQ(1&vlkUy-sOtYvo`Q1%SMr4Vip38!0tcr4<tBv~g0o$x$9Sa|xZ3Sfp^2&&HK#U7It7YE9v4n+^Dir&~cTw%^A1-nQPRCoI9@qnoYuql|LC3}JxznG^Fk<DSRi_;{6w)89@6Z958Zmsj|T@FSnL#(S-4-z}a@R<Qa_@Uap7dIRkVm~DlAugA6;KKv<wG!alr9f>94dA_&Xd5$k5hEsg1nCVegl6nzJLQ9!CK1uc((xfdP(7Yj@3v4%(&7@Ycj=pF+>xz-P+aX#Q+$bn0wFN>iR{$z}?*wMA*^vOsQ-ODJ?$Cvq`Q?egE4rSrgAcp#V^+v_=3<CFjN&xYVLn=Hkj&33xq=xXjut5l13w2)ZHdw|>rMZz|H{WZ3)yjO<`&;Rs-+1&o{=SiU~L-D^ac4H=oDbr(%hhzlw-UnknbbM?M-|ShF*Qi^>;q7_wfo8463Zj4N#czTjum|m)1V{J7Ic|yW$M&W)v4WlZzCeKTvPC2h%COZ*VgFjo)DYi+%w8N<PMT-xg)JE8<bl((?m1=!gT0)h*xR^zB<%25+U3kQg_ZaQx-Hev*f)hUR%|7+&?j^>^4~JH(d@KtOjQ8Kn4NEzrA)WM=|=Mu}Fvf{6!`0Np@_^QcX6;>-i+363of53no|(-lllkR^IqV<(T;8XXt&fbqH0>o}eot^pDmB&2?(`UQs&&6WhOSkuH!SyZ~>=OhlMdVj94s^Rd2_^d;Tj9eoGAS(FqRz^2|pxz+WfDbF+A<*F)|J}!f^EZ}TXkH6(Hij$T4pHy-J;jl<p5)!a#H)C%*ERA=ul1J9yyA1c>kYjp*+}{}mYS<i8zn2iCC56gVNy5<W96FuZ)lYM=b4Bm?#+zu<cuy`kj2U2bV4Dr^Tf9{DZj!H+uq2^k#AvUeKr{=rdnHdEw`*HpQ|3bt$r?Ls65@Q`)smK%7S3-^{r(BZda(R5^JD415^5MU;~aS9%%nAcYm1o+^vSzsaxv^VAWIc<3Fc`{(KJDH*tThYv0zL=2IeOT@JVDYB;0pDimzHbP9DF^;cAUe_OXxIa`6(g9eFCwNi%!%}Cx@tE01@G_Fv3s(1UFw3U^ASLZXb$vdzxP{yXFmbPi?y-A+)o~v{b;TC#E?=QF1Zlk$z+tL_ad?4VNu-|gCKKHwYlUDTaSsp{HjRW-gVF`~@Kh)E(%NEgYF^9Itlp<^qy&8cHnQx-q%Etj8Rlvf1{J+Z{UK3f`T*LA7%NX^(S}7D#RE*oKV1+6*8lBp8^W~M|_<x)ieo+')).decode('utf-8')
overlays = _sub_types.ModuleType('overlays')
exec(compile(_OVERLAYS_SRC, 'overlays.py', 'exec'), overlays.__dict__)


_ACTIONS = json.loads(zlib.decompress(base64.b85decode('c-qxnU2j|05&SQD=7ag6uf8cZ(+E{8LzYXV24MtfiULLYkoK+Uf3GZ&m%MjpXJ_{uTIo|1nc_Y7eC*ksot^#spR>RH{M)a;{C4(-&u1TQK7Ksg&d&b+^FROkucu!;{rKz8zy0Hve?R^F`Ruz-KYjV|aR2Vp+sCun+2)7!&C`G9tL^Ob*$=l5>$Bj8uYZ2?{`SY4yQjZ?d%t=5Tl4FWKdjdu&StCqKYU!T-#z{M$MxO)`?J~k<k!0)oF5*u{qJn_KDTfG^y$OV<Ayi;e70GCe0(0)@Wb1i-AIQ&8-_EUh>z>LyTjwJ@nDyDunTvL`w1P5^8Nk8;}6e+I{dU-CHtr2aZaAIdrkGbzx#B1_wLKn|2}?to>>2jC!f?ue|PhCeVF7qd&d5=U>%?S>HXs{?c-++EBgJ{HDC{T`M_v@+&r!yyzhJYfqdWYlW;EfBYs)6(f95?#Aaf0MA6qBhF(}sJMzQVfuoXHL^Jf^`^c1pOJ@iC@&40ps=-VYmd<Xm!@&1nTUoiI(V6$}vvPxt8=ll@<&-HYtei9>;R@Q}4sQ)6;$`5u4Y41}VW&-hm7C2Yn>d-)!am5oe&asa4{v>wUVbu8I}a_Um%V=a>&C7CbUVBaQ<&LP|4HF2onl~~>0*C!e|NWj`}pPi^~2-s-R)nV7uMdlDUYbKx4<yS7wo-&)Ihx*-7q`JVejo+&jqR&%J^?8bCo}?U7qr726l=+;c?<FJUUwU;}C5c5}Jtea;qEkvMuWVw_bSczUDj^2oCO5Y%XjpV*^F}Mb1z!wu$IQFlT{b*p0u%gdgtuoGpe!QwHMO_3BWDSqKg7-m9t20+>QP36*h70}$!NgabT^?+Rl&Ol)Ot{HQ^GAFy1`jE4hcv2Ve?4O3IT0Bg^6-oM2{rybjtJ8TT`%_qP9`1o+M`ELF2@Y7dR@bxaJRII`SZuw4&Mku|eb}>$V=ypNQYA!m$KKtK|t+(Vp&_3FuIp1KuErm!k0I*h`#_wHn`-G!D*g`x-&G8RFCBp9naTvX=n=Y#81q^zdoguJz2)YG9U&HnQCn%08=}28<zv}QE_CxHUSZ87|tP`|8Wgre;GJ(vBe&_@qtf7Lsi@`xV{c`77MJZ4tM^H^;R`08tBS$VS=?lv@7>TQ=4pur0l%7(FMI!T?m^qfAH8!F4g_EH2>xR2|`14vln<!$o6YZsLx`g5&rB(TM@HHEG8i1jjhNQUx?yMs}CBKiA(xcbo@h0Zt@Mk!xwb|}<{c7>=+{PeyxbIS{Ci~7{;qpsKg0oK3;f0coet`0A4dF`WF(>jn9Q0sCcvKw-Q1wt@>W?fk-bx`}N4`TLj}NTu>B1%7CFzIGI>A^kr=!LKvrb32RD|zUnnt^W)M<=EIf-@?PoVVy4wv3=o4ou`+vC%(>j7Ojk$<N=dhYshv&F{~SQuFZ1ob4O^tr(b2ml+S{3XPpI4p(yqKnK`tu9Rmw;+Ltd{Y==nTH`1*Bd<Mn_S-Yl{$90vmi_&UoQh44Bu@49wwY&4@V!9)#sPn^3|BQZyBnTU@}Bgj6=*yUf234C8q*F`i0bkh$*>ynI;@%RKJ(=lJGn1*WeWnzv$h={Rd}(i7$0HEcf?!yTT4&q=(9mr%UIZG0XNHEGU2;ZNs{S7}hOvr&o6-c~m!i&#+_kZzj>g;cE>{HM!jrjA%cc0L2}Nea0>~W!V#Evyif_cq1=c|LK|#tGZGJUkmqkT@(?8=dWFY;BuBol6c3_jB-V=nQKf2S?aIclIF1~sWJmWK}nK7ofJ+%&y8ZXM)rj0AkCOZkeZ#P?v^r>1cCzRU953W;!1WKO>I7%lNqK0KpG*uqLaI6dP5+4qA@}gJJ0-2Feh{qCD(-|hCmWa-X1LkPn%NWiO-ODqF>;4CBQZ{{teuk#e)JUJzz6h@69^2jl2;TC={Fz=Hsi|fH=-9V;LIb@=>uSY~sn`^@pi-Aq>>YWq{){lgLQL%bz|L<xl#}wmk-52*VzEcl$>?lvZDd)F!)AJZmXcs@wuiPg8y{C936RO+7YI$dCqGF9RO;vKHUuP}@|d^uVG+pEIaH&j0p98zEAmF@hVBEvi<DI{(LZcbG8&8(nNW6j4S2Nhb18ii&WwVVxL#C!8l%TMsB)pC(QAOPWov2EzvFTtEwb#o?*mt<jvEw|C*xJ!yo(kCJ!ztuqB#3RM$$pl<Zol|142QInmk>>uD@1E=xuykXW&lo@XmhQ3=r2Ifd}S1o%WbX_7tSt)$5$C=_5MjoeF-R3gyJT%}i4RGIJDtISr<a>%EZ=!+gVr>pWaHK_;-p3c)im-`&6u?$m_z)~5)k~;^#2i*=rL!K+E_X)XL<HTk9{K!DYucfOlFEXfY>gs!>lfHn;9h;TG?Co!k@sB7AdtK`b&X3tvYb6fkG3n`vsM$__o17t8ggbgFSi9B4~?<J*^pQfkRGoU!1b>~wNqeyb{*Sq+ZDrxjP^mPX3;N=%|QL}qeVoYx(sc69`F$0ht1GQNFdk;e#novcYgvmAd3QkBL?<eODY37eMkZ=3hLrR58QLK;9(%?PEJyG1fcTvS7NPk0nkL`Cm60Yg(B8XIsR%Ev6QQ2Qbjq3-5eRS7G|;H$LT(~Qhgj9oDTKMnpfK4{TK)6YRq#xwP&upsQ2nf=meAZ<`*R%(^%X2vJ<?&aI)@tAYikOAX~sb)WqbT=mlv{2nI{pDoxd10O>Mb07!ywglI_oSbx0PtJ0WpS_cQp8(+mbA{HE}2153IS++-f<y!DegIeIyTQuxQJXu>0md(<`u&HJ>-2Z6z@bHa#_<A6>DhG0Ca|u2HR0}7f@+z=fR?`8}E44EMs;|(?(uJGML`5TZ=7FbXTWgC$$v26pak|Jbok1k2(X84x7~oV8cR2Mc>$pN;=ZL%jrcT=aijYQ~{u+Y1kX0y;NO*o~Yw{<~uW8<l2+_x+G==NH!s;0Qp9LSM!6<rPK{eUm*6!5g0ZEoI9sY6H`yj5TuQc7~7yed0Cnw;d=Z0p$O>RR|_c1$FrR|DM5Z{B;xdCT%Vgaccvp|Dlo53cuw#ITc;fn-#los<Rh1%4e$F3J^30*r(ebPeC3tjkN-wZ|og!9pm2_^tqZzu`N!Jz0Hj?I=G7eqUK{DOUFlj5Fdl6>$e+)BiWW{V8aM#s7b%rA{0?!O@Gl%#-8%0?@651DoP;Y7?^WnZ2G4fCtp1USq(SXm{2Re}bI23^I78nG=j6oziKj-&=#g^rPbcwtEH775j0suLvayTLdJq11BsexXoz#pmD>f(cj?9a8WmF^A3MIl{)GI-_tC6q4C)wOx8!@}#VV^{VuOFp?*TEfw|1(WjF%1P+rC<w*{6qAb)R_H7tOU=Iz&xig5j9mtU@zpJrgPAi?)oL0>|F-dXglsYKDR+j24*=%Ze1jO1aJPAtLme2=APt~|pNs(TL?~;^-+vKrGC(&favOgFbQ<GL@!7}Zu!bexoD(M?ubYsWp{N8Uc5e2qNhvLWoqwtarJf(n#N!K95g#_-z=yLej@#Vg7|7EU+pI5r#2bAptWNHe4QdVY5YaO{%(_>;5N76(LXLrhpBWCo{GG|jIc(jxS;?+w89M-WN{zy!6z#T8u0)Zu_VR6RSla&;4gagT&gu|8KV-tyDJ4JwvtW|x|j6BAFpIOrv{Ui#5lvGSWQ%aQLj2o2#31^d9fXpGb8xl3A@WWbAkU?oMO&bv(3J`q2j59n%?V>BnF%i}l&7W6&>39f%RDlidI1B}>ADjG)8RTg}cp@0v=ZH>zd`aj59qO6ZAS`6v6oKiH)PF*Je#SLn)-QJ;>^?HWF8~GA>pF&S8?R>N3|I_JYkFhZDXvPnF1BL^ml>Nv;*~O$@%ma}+|($#)L3Xbq&q{m`dx>ur^$h~R0b#Voj{RP%fsgcVbq^apY@a#N^#vt@3c~?4mri47D$XNL7s!k8Hu%)*;LtQ8<%?CxxEBY^<iawsotfFew_#6c#UAjVp2<+Q<AVjN4A-RTG5dSijPV5JcHni6|yw{;wGi4-Z=Qe1c5U5RQolAGc7%{P<+iHo??m+0AkgRfD~qZO4H;w<r-;)aE{NLZr+yLraEc}6xZU@ROKnFhq6U2eU-d(wa5`cIjR+E(0~fFXZ$yv(|pP!3))PC7it4Z`y0lBeKudK?Wt3GEw8B1!^@qk7MZ+Vmm+CDZ`aiF!~a^~ss_bhh4vJJjrDpla!%1}wRW(B)QERMJOIMG>-J9Hk!HT$DV(`?^@d?$S|RzbsgrU{U;`PynVPmv_`mE3u<Q{{5B5ti*sUHj)<|7{#WRzjN)HPkLGpHjGVJJt3#T=7X9at-0JGpt^Yf#4tnE{P#sIukCUK$DE7DCnLO}-_g%sHQOb8`BWRP=vyxAMBzjQE$1#TO8zNEVaQzk<_VvG%ogLMIYV-#GwnZtx(rrA;$h|#VL(M|_lRVHN4+OiP{FGK{j1jk4p>Z&wNheukSSxRLkC7sVZYM!b~vFzD`pjZzzlUF5bvRcU~7E}cir(#?VSXbe4TF<$_<z#It#@tOxVVX%bgq*6`LuslIztSw46R$RkUFF-qtDI3PWGr>Rz`Aj(ZCU44(U;|NX%%l!x;{%~Vhyg3xc@Vq1E7}_tbOH3*!9HXSCmgTI3zs|2hlH`1z~Qg_C)2#u|h&m1Bz5P<wQ;xB{U+k5^`S#?_dI0B<V#Hi@Dqq!zPhJi`v6RXfIc72G5wKkxEUf)myNO=|qXi*b;6xi`;6h2@syE!N=x3QeuwwTnN}G@^Yx|rmh?fe{*$~>u`NkjHsm(PfE`*rhHZyoD^aic8J7l4fAG%KdPYm#ekFwxJg2=GIR-Vw0vARFUEzyGhMub4s)hxuR(5E$eE`D%T%(lj|L5lCztNOgu>47ug>#brKDEjej%f7v=mjIKAA-!;Ym1rLS+37l%82kn9YAu9i%25<V>5LT0->Lfp_vu>~htjE#_SvbBO_z95)vcwJ;KazSMaYL_W~}W95-5J*=fXp0#t<$}>@-3&#p#?A^-g4&_vtC_6i%OuMesAP1osD7m8pbKZGn8FV>NS}0kxu;=3}XlO3##&Z+Z3S2;d6PpztNK-zuuxX^mI;1QNBn=^m?3s7GHRCE%rlr)BndZsYwP04YZ35t2JcZy|(G%K~SR=9$U<h`#&AbmgtU=}*_gR9rM-g_x#ZNQ%j-U>l2nPj+JCHQSr^9Om+5j}$HZF2mY*fBYHSCl;_$hjW+xJDm0cNT(N@7DL8^;$AfyI2t8?mdQ93JS^F-qyRC@yugwT$UD#*mh+9#c_PV%Z~ULKZU@vWisQ>uSF-VLaKXYlQwVB0*1dr=`4B=9CvpAd^%8H;4$C&zB_|3d(GQKqApXwi<<jN>;)X+tiZ9l5DV`2}0m-spu_VPo!)&y&9Nmn$RxAFWm(fwY%H+PLvlj$>o&Ff*Us@?}0?4(M<Pac^62TGGYIUI@F~CRmF^mtR*#OG3yS-h29h|W`g(LHdV~QCKbG@I*fWqw2=jxKa8=&Jk?QRVkLxS;F00dfeQq_7uAM&wtTB?;siLj@>(E~u(?ZMX|CSfECYuIQ<PwgMAR>)j&u~=!2mhRC2HdeLj1Hu(`5f#XGSG6o<P@TGJgfsA2?-<nP}sO@w6%chYi?{a;R4GNyhF$0;59Q56N*}74eMX1!O~CZY%AeN7v-lYm(AC(GFf&Mwm5xHavie^etrBw$P6@op|4p=8tSh%cJU`2n42%8BVTQ*=Mk|I0d|jEHWH|?p@l;Xq9~tYM4{`%_YiI0d7nfXOS##4|+l|ZVIx7Wxst@xbzZ$i0BQR+PJImDGnopDtzxE%zagK&{o?LBPKj>c(cc8t%7dhJVR{bOlVp)(bx-yF{U??^zkO7aC23tUIHB(#zaWzA!j%vc_DGu43}x2G3FxM4Gp3TQt=2?!&doGJjpsnmy1|Mh!9}ZEbvE3N72e;LRdgjp!8C|nR<7zd9DL5`t1SIQ&&KgwR9=d-L@9(kpCs&ht1dP<?8cAhOi;^lA>h`QtPD}M*!-B+g7~Idd8z2eEs_RWU0PQy(<&i6VJXnSgFi_877~!@6-<HDdb+AauvuURr8)shgamKH)&#~G|aB`15vdw(*z3c5vEU?D^-=!=(-jbn)!XVN*dksy5oAl0ZSlp5rJL@K?;>o5V)TJWj&HQX|(Df>fq{4g!g)<(pTdNc~ZzPHe0O~u7)wwc>45wrLU_M=%J9-NKT@Rs*^Dfk0?M3)NyRI9C_YJ!;b51sv)Tzy50muE6Q@)?sn4ji`uYh6*#n>iBuZ#MKOhvu<o_7gDkt=12GY)Cat2OSGfd%Ehe^0>&Tapv|eOj7k2{J3jFEhfVI+$Fu5s(i17~4y%t)55fEr<PF9fLE3%n@kLyiN;f|+^Kp<RrVc^3ow)^gQB2>1lbhur@qY4byw>?9}B0tcnSO9jpLK%tzv%)cD`hjluf<|3?I&qENu3w;{*e+gdD=oZ6ypcCXso^3G!~o`V0Me8?C{#-q8dWY<7r#H9d=4m`7lkTnxocU8FwbF$`@$BF^Fj4U=(5T$uDn9K#Kw1sVR~FmVmML&CT9@&%hsGA$KEGO(89E45U8>%T#^;UYq`F=e=ns$!PXBPqcnd;^H-V_FG!WDJycK%jVi;7N$S*6NNN~Tdp1@!?Sw{-&)I{dRRpCG{iRhb2K?$kq&1TUb^!5;cFQ_nB$|MWVmw-(IhJdmm>5MQD&MqLxFNk8400w(PiJhBS%HOj>a>0lRtgWKt;CR>85ZFUthxYug@7c$`1Ydgr4!b-RhAG?u&D{@u#VwA<FwqcNW|G~5&c@*E|Skg6&<tXaNhe&N5bh;9&*ad1cM}FtjSf{iXs;fevJ7y<Dp^CDz)RdF3C=!HLmnz*B|7P*c?Eh6~m*kjO;X%QiZu}Rm_;($Byr9YlSxXyk2lk5-k!D9R|84(~OQ%HN|?jT9%fj9qAciUKpBTeqJ4)hTRo<zD>Ls*I%*kAJ%S-me#MfBbqVRE&~x3h$JnV;kr4R&{ZeqRIRNkV=&esxEQ(@tHa*jZ}vtRiKU;eFUdk};N>J&73T#GpMy`ms9Sy5IKYvQDq#30V=h+>_SYMpPz^vbJd)W3s>?w=bfY!~d^2cHxxOp@z%y;)+cixQ6gp#WzN|D4&nb6k5`|R!i)wvDq~g!u!D~qimL&j+$C5`h>_v_mp6zHn%nNrZKGU<=Tevm|1n`t{Cr75lMS+Y|0U8tw6Y8YpiQ=sk*%RyXfA{J3?%kIskLB^xL#!XjOL@o(plWp4kN~gv>5t#8M?OtT8OR0+V5Iv=FICd*o`6gVx%ptiG{7v$tSijn=td1wzVpaU;ANobUpWxdrGqd*!-FU|67&`u0ZD)mDUXJ5Vw9o)FvxzFk9`%x%T7pf&fnNDP>}G0%P%yiQZ0PkLMzz}X?GR8DJQ1!t{N6oETxPnOkH&ig1rAmbCrqYG0{GbYn3@hwo&B{L3^b=TIKadOO4Zt=IE6c9FQV>Fp@HysFTecf!$WbX8GpZwT(R`cS<`uIcC(dfAw7o9VpVAIKUD!)O|3fSO-M3OGJRBB2Y2!z)fNebRxD<hS0B4jr2~Zy4J1F@DJ^h&~uPA$_u*%3)S@5UWqdF#~oiLz9WGkwWEYY=S<EmXnsJdf~p4w&5$l%taQR?PzI7K<-Ed>L}$NbbI%g6nC+6_x$C)sDE-iaULzGfNZK5Olx773AiZvK(;{spy%LM9BkP@I?Asz&SxGk+t9K(n0mEUQO;Ds1mB6BD$DicjB-#qTrigN~7$oM70=o|Qy+Fb$N;AXglWbyfd?dF#1LZThIW!xONwJWY+a&Z1ojtO@M1d9*p)%c>%GOfURM|KR4OKd*%&uNDm~HN1QYmWM^H@$4=$=;tUHEMmYJ1n1@qE(uD9o`UztIBctUeO*c!D-6UW%J?ulbbxUb?TSJ?A1eSyRInG->)RMniA(F_TP8wCOqDR?_JZ0a09C)u&`E*hKUfaa)($idYj&33Gf+%~K_E+b1ociOR}w0zWBVW4EiAYL>`}eY$lz{raMSBH1!FcELb8orK&Q!g>|?M53C*X03I*OvLS8aIAB(X+eqzf5i<m1avdZ=t5KCRK-x7g3B3+Iyo7+2FpJZ2`7v&&!p9o_CUysIy+A8O&S1O)UP6CIIO-}I7YfO@&?ppRH})oUFF82K=5E%f!squ{0RHC)BqGsTMAHSXueb?L<5zgDew;ug#?dkADwo$!Ila3nNq%Pv`Y1E%u3fUP{ku4l0kDvD@|;-vD=X<=SDb(e_)jwC`)0Uf?+eiV_K|UMf{1A1M1;r5|Vux@Q>3^<-{2kfoO{xfngB6W;;~1i{a@-np+Sy(k{5Iyr-$5lMk9Liw&M=J)~0TQtaoHp^1pPG6eQ=oa<!q4Rov}`9i9g(y#hPYwMKKJ?Rg=VRtsl%%G4>)ZR(CAes*pUBI$RuY3A3sW9HtiTkgdf6Zfek+HMf>SSgvrRy39Hq5LLrQFpCN={5UW<;lqMAEG|Rdh6g-^Ii@pfOfLC9;c!UQV7|Oss||V>wLDQY=e7&+xkFli{9MlMkIZUg#&gnM1i!UDJA^yjZ1!`A}+DBL+QizeXT=HkV4TnFwDw)MoIeaU8Mp1!Id63mZW-AT38kdxA|&2v*xxBJ5E7x5m6fCw(dmRcuA<QrR-fl0@vPwHsWZ63le^Lg13|&aBa}sttCc_9tps9Q%VH(=83~I-@x*YH<)o0ALPzMZ7Vz^`=)NDrLa5ZkrY1E^;iM3g=}E_;u_MePX5F#&VREhxjU_oMpsoX+j#34Vp#H4P}MugOhUp0i#A7o$JD$fH%X6RNy<v-fOatmj|xTFB9b<hz6uq5Ku^qd0)*1RtcVrNS?6wL$7X3K5swZTyOOJOd(@)?kKc(h^#d&d@-Re%Bl*@QI~2b%zRmxz}6ykCfYSTp<$P;W1&4<)?)6Nl5L=Ux)A&+a(qJML!kh~eqly>X)d9WL63I7ds6`UpMcXrxbkwdEG_zFAyGmQf4R+6Z6xaEI8T?xqmuW2d@zK2o1#@w$v+c2qO{3k;+s=Zfl16(-RVuqF6wNO4F&mt=`2a>rcdmYa(gb>pg<pt5%!76<jT;w4b@<J7*B@TdCI0EHIq)8JD&+7HlHH!0yrUht5w#=j48fmG8jO_7!_A3q9=JbQd}ZIdAZiHDW$lPMjWYc`=$>q#KMN8y6R;0R_$<2H}#NZND!gCN$qyJj?-r{7bMvwiG6Q4?$x%l8i_X11Cw-JkgPhbIEl!eWw(+3GRy7j>6u6iMJkX8MJd-0N#eiLa_~r0vk|l+UKUR|hY4niP!&Yy=(sG#>FDD7(Kn&BX1N|>i{aBMsd%+5DxejIwNhUhothI#s%(TsQ~<0ZM#bSTO`{{gR7(R4`_k~1fYcnK^IWP=q3dEVs)-s=WMaGxk*hgjwmNtJ@Q8DxFjNz)Aujz0UWQAZ8vliLe5#<nQHL8x9yryrE@5>NRm6!bmjda~$UY(x(VmwSLMx<33HljSSTG7^Rj)-EU$_-`ff!TlAJ@p##;HNGe%cSrI_ZyE7%8YR0emTG%z_FH7lKI!bu8}5j3q1HQqif|YuwEIEa+>AuO?v=F#OAIRW_2IV!(`XKezOe6}=8bt*Rl7;gX^&L9{x$jRa*&k#kc@MA7=_1`>=a@e<Is17(kRoWRLZ)wj7<#>$0?ds1w@jN6A7@t9V;g2`5H^oBIbdPsblU|UAgE;P~*@t%O!`V3V8ZYZhX;LJ6Z7DQsqT%K0#3{E><gY(m}53ys5Ge<HqS%o%x>{O~<m8roAO6%IHjMNfIT2MzR32LF7(hEA?B#kWusAy>JmfEPA?=)Wk&wT3q+r-{R5ef#FfGw6^=lMFv{VHEf=_=C{C2%*wlO0vsg6617C#-7~m$s`B!2T?W4~iXZSE7`Xqa7ZLN0o*fEC%0%xr=$Gyd|uABM6IaDIaNa!CK$x-kuA3cy=(PY{F_#kVO!rm;KpPMnhm`X*8yqY1_brSY7l9^}8t2w(%jVt_Drc23^(M7=G^laT6~&h~ltcu0(k~d^Q%(B*Jt`$1Ju~-w2`)SwYdM$rHG4;fSLKaJX46bCjq@mr*`R3R#B9Q+=uvrdiqpthyQbvi?8ja*l!iMC4LSRYSSCNws4`$D|Z1<{5`5S0&lG0tTa}5{XQpB0Cg}V;VdbHEDS0IW08D<u%-R=U^1Md*@oFg=;l6juK9EyOAC&Gj3e~R#jl%o^KNc|CIj0OZ&yFZZT))=efP5CW-}d{k#xB3{IzIBT?fElsbu6!({h)OsuOoU}J1_nj3}9UP&L2<}4=#MFTk%znxDi9&03>yTV5Kn@eGclOL4!9Y|Afd>k$k+pF+saa6&j#a`fi**PH{Mvu83&!HFLoHRFUJ(4(@Z;QYwyPfO+U3sZYGaTlr1yVy~ex;#F1zpTpRJ}Jv(IrKR3v_TY;>60*jWY4>!7B0z=sfX-5Bg4zslLjg;4Lm?IY6~R=5&ZxsqS`>ZyWO4X`;5uj^zh{ayi+qt`k=jaYr$WofuROS3r-@d&eSAJT<hKR1zP9_<ATJn5^8SwRLH7=9tD?T-q8VGAVQhZu<xhjAoAh4gKTPhC}<E^$K90(%}~XE>MqwvXO1ZE|Y?>>}qjvs;X{?V@;ybyuvOWFi7wc6+H0i>EH2d(@5<sl=&qCIRyLWp8#EFN@1qSw}sHQd-pIJ1d<#j5!F9RRE1ICG7|<C`bLr_pcQ$guc5{Ee|tY8$p')).decode('utf-8'))
__version__ = "mapleleaf-6.7-live-import-bugfix"

# ===========================================================================
# MapleLeaf 6.7 -- critical bugfix: 6.6's live Kaggle submission (2026-08-22
# 20:47) came back SubmissionStatus.ERROR / "Validation Episode failed" --
# it never actually ran on the ladder. Root cause: overlays.py imported
# `kaggle_environments.envs.kaggriculture.kaggriculture` (an internal env
# submodule) at module load to source its market-price model. That import
# works fine in this local dev install but is almost certainly unsupported
# in Kaggle's actual grading sandbox for a submitted agent -- it was the
# only non-stdlib, non-local import anywhere in main.py/overlays.py, and
# the only thing that changed between 6.5 (validated fine) and 6.6 (errored).
# Fixed by hand-copying the verified-correct constants directly into
# overlays.py (byte-exact match confirmed against the live 1.32.7 engine via
# `overlays._verify_against_live_engine()`) so the agent never touches the
# live package's internals at runtime. See overlays.py's own comment for
# the full story. No route or overlay-tuning changes in this version --
# everything else is byte-identical to 6.6's CMA-ES-tuned baseline.
# ===========================================================================
# MapleLeaf 6.6 -- CMA-ES-tuned revived overlays on top of the unchanged
# 6.5 (Filip Strzalka) route.
#
# Phase A (route refresh): surveyed the entire current top-20 leaderboard's
# real replays (route_mining.py's majority-vote self-consistency check).
# Only ReCurSiON's P1 seat qualified (96.4% over 11 real games) as a
# clonable fixed script -- every other top-20 player-seat, including all 20
# P0 seats, came back too adaptive to reconstruct (<95%). Benchmarked
# ReCurSiON's real P1 route as a straight swap-in for Filip's P1 route:
# LOST, -1,009/game, 2/20 wins vs. unmodified 6.5. Backbone route is
# unchanged -- per this project's own "adopt only on a clear win" rule.
#
# Phase B/C (overlay tuning): overlays.py revives 6.3's pre-6.4-rewrite
# overlay library (premium market-lead preemption, fertilizer relay,
# price-floor guard, impact-based sell-slot ranking, opportunistic surplus
# sell, terminal liquidation) -- deleted wholesale in 6.4 on the assumption
# the new route didn't need them, never re-tested since. evolve.py ran a
# ~40-dimension CMA-ES search over every overlay threshold + main.py's own
# weed-repair/demand-forecast constants + front-run item priority, scored
# on a variance-penalized fitness (mean - 0.35*std of per-game score delta)
# against a pool of {this route unmodified, legacy 6.3, a real ReCurSiON
# game} -- the concrete "steadier, long-term growth" mechanism requested
# for this version. Winner (fitness 3335.7, mean_delta +4,883, std +4,421
# after 53 generations, ~65 min at 110-way parallelism): premium market-
# lead preemption ON (unlike 6.3's original tuning) and impact-based
# sell-slot ranking ON; fertilizer relay, price-floor guard, and
# opportunistic sell all tuned OFF. Validated: 20/20 wins, +2,303/game vs.
# the unmodified 6.5 baseline; 36/40 wins, +6,626/game vs. Ryo Hasegawa's
# real games (current #1, 2026-08-22 leaderboard).
# ===========================================================================

_BAKED_BASE_PARAMS = {
    "weed_replay_steps": 2,
    "town_demand_pulse_period": 16,
    "town_demand_check_interval": 5,
    "town_demand_single_shop_bonus": 2.300216812449822,
    "town_demand_multi_shop_bonus": 1.1189036311966576,
}
_BAKED_OVERLAY_PARAMS = {
    "premium_shift_enabled": 1.0,
    "premium_shift_start": 40,
    "premium_shift_stop": 703,
    "premium_shift_fraction": 2.9642044932873715,
    "premium_shift_max_batch": 23,
    "premium_shift_min_future_qty": 2,
    "premium_shift_opp_ready_threshold": 1,
    "mirror_max_distance": 8.175368097055422,
    "fert_relay_enabled": 0.0,
    "fert_relay_lead": 7,
    "fert_relay_lead_heavy_animal": 4,
    "fert_relay_start": 154,
    "fert_relay_stop": 585,
    "price_floor_enabled": 0.0,
    "rank_sell_slots_enabled": 1.0,
    "demand_alpha": 0.9956143660096762,
    "opp_sell_enabled": 0.0,
    "opp_sell_start": 166,
    "opp_sell_stop": 656,
    "opp_sell_batch_cap": 11,
    "opp_sell_base_fraction": 0.34051958804010085,
    "opp_sell_floor_fraction": 0.25263219724334873,
    "opp_sell_ramp_start": 401,
    "opp_sell_min_supply_fraction": 0.39881985070649717,
    "terminal_soft_start": 719,
    "terminal_hard_start": 695,
}
_BAKED_FR_ORDER = ('MILK', 'STRAWBERRY', 'CARROT', 'TOMATO', 'WOOL', 'FERTILIZER', 'MELON', 'WHEAT', 'EGG')

_FR_ITEMS = ('MELON', 'MILK', 'STRAWBERRY', 'WOOL', 'WHEAT', 'FERTILIZER', 'EGG', 'CARROT', 'TOMATO')
_FR_STATE = {
    0: {"last_step": -1, "due_step": -1, "due": {}},
    1: {"last_step": -1, "due_step": -1, "due": {}},
}
_WEED_STATE = {0: {}, 1: {}}
_WEED_REPLAY_STEPS = 8

# Tunable knobs for main.py's own overlays (weed repair + front-run demand
# forecast). Defaults reproduce exact 6.5 behavior; configure_base() lets
# evolve.py's CMA-ES search patch these without editing this file. See
# tuning_spec.py for the search bounds these are drawn from.
_BASE_PARAMS = {
    "weed_replay_steps": _WEED_REPLAY_STEPS,
    "town_demand_pulse_period": 24,
    "town_demand_check_interval": 4,
    "town_demand_single_shop_bonus": 2,
    "town_demand_multi_shop_bonus": 1,
}


def configure_base(params):
    global _WEED_REPLAY_STEPS, _BASE_PARAMS
    _BASE_PARAMS = dict(_BASE_PARAMS)
    _BASE_PARAMS.update(params or {})
    _WEED_REPLAY_STEPS = int(_BASE_PARAMS["weed_replay_steps"])


_SHOP_PRODUCTS = {
    "BAKERY": ("EGG", "WHEAT"),
    "PIZZA_SHOP": ("MILK", "TOMATO", "WHEAT"),
    "BRUNCH_SPOT": ("EGG", "WHEAT", "STRAWBERRY"),
    "YARN_STORE": ("WOOL",),
    "ICE_CREAM_SHOP": ("STRAWBERRY", "MILK", "WHEAT"),
    "PET_CAFE": ("CARROT",),
    "SMOOTHIE_SHOP": ("STRAWBERRY", "MILK"),
    "FARMERS_MARKET": ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY"),
}


def _get(value, key, default=None):
    if isinstance(value, dict):
        return value.get(key, default)
    getter = getattr(value, "get", None)
    if callable(getter):
        return getter(key, default)
    return getattr(value, key, default)


def _copy_action(action):
    action = copy.deepcopy(action or {})
    return {
        "farmer": list(action.get("farmer") or ["PASS"]),
        "hands": [list(order or ["PASS"]) for order in (action.get("hands") or [])],
        "market": [list(order) for order in (action.get("market") or [])],
    }


def _seat(obs):
    return 1 if int(_get(obs, "player", 0) or 0) == 1 else 0


def _farm(obs, seat):
    farms = list(_get(obs, "farms", []) or [])
    return farms[seat] if seat < len(farms) else {}


def _align_hands(action, obs):
    action = _copy_action(action)
    expected = len(_get(_farm(obs, _seat(obs)), "hands", []) or [])
    hands = list(action.get("hands") or [])
    if len(hands) < expected:
        hands.extend([["PASS"] for _ in range(expected - len(hands))])
    action["hands"] = [list(order or ["PASS"]) for order in hands[:expected]]
    return action


def _tile_at(farm, position):
    try:
        x, y = int(position[0]), int(position[1])
        return (_get(farm, "tiles", []) or [])[y][x]
    except (IndexError, TypeError, ValueError):
        return "LOCKED"


def _trace_actor_action(step, actor):
    trace = _ACTIONS[min(max(int(step), 0), len(_ACTIONS) - 1)] or {}
    if actor == "farmer":
        return list(trace.get("farmer") or ["PASS"])
    hands = trace.get("hands", []) or []
    return list(hands[actor] if actor < len(hands) else ["PASS"])


def _weed_repair_action(obs, action, step):
    action = _align_hands(action, obs)
    seat = _seat(obs)
    game = _WEED_STATE[seat]
    if step == 0 or step < int(game.get("last_step", -1)):
        game = {"last_step": step, "active": {}}
        _WEED_STATE[seat] = game
    game["last_step"] = step
    farm = _farm(obs, seat)
    positions = [_get(farm, "farmer"), *list(_get(farm, "hands", []) or [])]
    unit_actions = [action.get("farmer", ["PASS"]), *list(action.get("hands") or [])]
    active = game.setdefault("active", {})

    for actor, transaction in list(active.items()):
        index = 0 if actor == "farmer" else int(actor) + 1
        if index >= len(unit_actions):
            active.pop(actor, None)
            continue
        age = step - int(transaction["start"])
        if age == 1:
            unit_actions[index] = list(transaction["intended"])
        elif 2 <= age <= 1 + _WEED_REPLAY_STEPS:
            unit_actions[index] = _trace_actor_action(step - 1, actor)
        else:
            active.pop(actor, None)

    for index, (position, intended) in enumerate(zip(positions, unit_actions)):
        actor = "farmer" if index == 0 else index - 1
        if actor in active or not isinstance(intended, list) or not intended:
            continue
        if intended[0] not in ("BUILD_PASTURE", "PLANT"):
            continue
        tile = _tile_at(farm, position)
        if not isinstance(tile, dict) or tile.get("kind") != "WEED":
            continue
        active[actor] = {"start": step, "intended": list(intended)}
        unit_actions[index] = ["DIG"]

    action["farmer"] = unit_actions[0] if unit_actions else ["PASS"]
    action["hands"] = unit_actions[1:]
    return _align_hands(action, obs)


def _fr_state(obs, step):
    seat = _seat(obs)
    state = _FR_STATE[seat]
    if step == 0 or step < int(state.get("last_step", -1)):
        state = {"last_step": step, "due_step": -1, "due": {}}
        _FR_STATE[seat] = state
    state["last_step"] = step
    if 0 <= int(state.get("due_step", -1)) < step:
        state["due_step"], state["due"] = -1, {}
    return state


def _town_demand_now(obs, item, step):
    pulse_period = int(_BASE_PARAMS["town_demand_pulse_period"])
    check_interval = int(_BASE_PARAMS["town_demand_check_interval"])
    demand = 1 if item != "FERTILIZER" and step % pulse_period == 0 else 0
    if step % check_interval != 0:
        return demand
    town = _get(obs, "town", {}) or {}
    single_bonus = _BASE_PARAMS["town_demand_single_shop_bonus"]
    multi_bonus = _BASE_PARAMS["town_demand_multi_shop_bonus"]
    for shop in list(_get(town, "unlocked_shops", []) or []):
        products = _SHOP_PRODUCTS.get(shop, ())
        if item in products:
            demand += single_bonus if len(products) == 1 else multi_bonus
    return demand


def _future_quantity(step, item):
    future = step + 1
    if not 0 <= future < len(_ACTIONS):
        return 0
    return sum(
        max(0, int(order[2]))
        for order in (_ACTIONS[future].get("market") or [])
        if len(order) >= 3 and order[0] == "SELL" and order[1] == item
    )


def _pickup_reserve(action, item):
    reserve = 0
    for order in [action.get("farmer", ["PASS"]), *list(action.get("hands") or [])]:
        if isinstance(order, (list, tuple)) and len(order) >= 2 and order[0] == "PICKUP" and order[1] == item:
            try:
                reserve += max(0, int(order[2])) if len(order) >= 3 else 1
            except (TypeError, ValueError):
                reserve += 1
    return reserve


def _existing_sell(action, item):
    return sum(
        max(0, int(order[2]))
        for order in (action.get("market") or [])
        if len(order) >= 3 and order[0] == "SELL" and order[1] == item
    )


def _repay(action, state, step):
    if int(state.get("due_step", -1)) != step:
        return action
    due = {str(item): max(0, int(quantity)) for item, quantity in dict(state.get("due", {})).items()}
    action = _copy_action(action)
    market = []
    for raw in action.get("market") or []:
        order = list(raw)
        if len(order) >= 3 and order[0] == "SELL" and order[1] in due and due[order[1]] > 0:
            requested = max(0, int(order[2]))
            reduction = min(requested, due[order[1]])
            requested -= reduction
            due[order[1]] -= reduction
            if requested <= 0:
                continue
            order[2] = requested
        market.append(order)
    action["market"] = market[:10]
    state["due_step"], state["due"] = -1, {}
    return action


def _front_run(action, obs, state, step):
    if not _FR_ITEMS:
        return action
    private = _get(obs, "private", {}) or {}
    shed = _get(private, "shed", {}) or {}
    moved = {}
    action = _copy_action(action)
    for item in _FR_ITEMS:
        target = _future_quantity(step, item)
        if target <= 0 or _town_demand_now(obs, item, step) > 0:
            continue
        stock = max(0, int(_get(shed, item, 0) or 0))
        reserve = _pickup_reserve(action, item) + _existing_sell(action, item)
        quantity = min(target, max(0, stock - reserve))
        if quantity <= 0:
            continue
        market = [list(order) for order in (action.get("market") or [])]
        existing = next((order for order in market if len(order) >= 3 and order[0] == "SELL" and order[1] == item), None)
        if existing is not None:
            existing[2] = max(0, int(existing[2])) + quantity
        elif len(market) < 10:
            market.append(["SELL", item, quantity])
        else:
            continue
        action["market"] = market[:10]
        moved[item] = moved.get(item, 0) + quantity
    if moved:
        state["due_step"] = step + 1
        state["due"] = moved
    return action


# Activate the CMA-ES-discovered configuration (see docstring above).
configure_base(_BAKED_BASE_PARAMS)
_FR_ITEMS = _BAKED_FR_ORDER
overlays.configure(_BAKED_OVERLAY_PARAMS)


def agent(obs):
    try:
        step = min(max(0, int(_get(obs, "step", 0) or 0)), len(_ACTIONS) - 1)
        action = _weed_repair_action(obs, _copy_action(_ACTIONS[step]), step)
        state = _fr_state(obs, step)
        action = _repay(action, state, step)
        action = overlays.repay_premium_shift(obs, action, step)
        action = overlays.repay_fertilizer_relay(obs, action, step)
        action = _front_run(action, obs, state, step)
        overlays._detect_opponent_type(obs, step)
        action = overlays.price_floor_guard(obs, action, step)
        action = overlays.rank_sell_slots(obs, action)
        action = overlays.premium_shift(obs, action, step, _ACTIONS)
        action = overlays.fertilizer_relay(obs, action, step, _ACTIONS)
        action = overlays.opportunistic_sell(obs, action, step)
        action = overlays.shed_guard(obs, action, step)
        action = overlays.terminal_liquidation(obs, action, step)
        return _align_hands(action, obs)
    except Exception:
        farm = _farm(obs, _seat(obs))
        return {
            "farmer": ["PASS"],
            "hands": [["PASS"] for _ in (_get(farm, "hands", []) or [])],
            "market": [],
        }


def _kaggle_submission_entrypoint(obs, configuration=None):
    return agent(obs)

# --- CMA-ES candidate override (build_agent.write_self_contained_candidate) ---
configure_base({'weed_replay_steps': 16, 'town_demand_pulse_period': 18, 'town_demand_check_interval': 3, 'town_demand_single_shop_bonus': 1.2489639593876367, 'town_demand_multi_shop_bonus': 1.1565825155483034})
_FR_ITEMS = ('WOOL', 'TOMATO', 'MILK', 'STRAWBERRY', 'WHEAT', 'FERTILIZER', 'CARROT')
overlays.configure({'premium_shift_enabled': 1.0, 'premium_shift_start': 182, 'premium_shift_stop': 591, 'premium_shift_fraction': 1.440498387414229, 'premium_shift_max_batch': 25, 'premium_shift_min_future_qty': 2, 'premium_shift_opp_ready_threshold': 4, 'mirror_max_distance': 49.547723996010106, 'fert_relay_enabled': 0.0, 'fert_relay_lead': 7, 'fert_relay_lead_heavy_animal': 4, 'fert_relay_start': 336, 'fert_relay_stop': 717, 'price_floor_enabled': 0.0, 'rank_sell_slots_enabled': 0.0, 'demand_alpha': 0.7677731790404925, 'opp_sell_enabled': 1.0, 'opp_sell_start': 12, 'opp_sell_stop': 645, 'opp_sell_batch_cap': 3, 'opp_sell_base_fraction_MILK': 0.8448447799390658, 'opp_sell_base_fraction_WOOL': 0.691233924338645, 'opp_sell_base_fraction_STRAWBERRY': 0.5456922406229124, 'opp_sell_base_fraction_MELON': 0.15742841094989488, 'opp_sell_floor_fraction_MILK': 0.4956694452850473, 'opp_sell_floor_fraction_WOOL': 0.07589735653232771, 'opp_sell_floor_fraction_STRAWBERRY': 0.08813406704229118, 'opp_sell_floor_fraction_MELON': 0.05867448503166997, 'opp_sell_ramp_start': 424, 'opp_sell_min_supply_fraction': 0.9243877957088804, 'terminal_soft_start': 693, 'terminal_hard_start': 719, 'shed_guard_enabled': 0.0, 'shed_guard_start': 490, 'shed_guard_stop': 521, 'shed_guard_batch_cap': 20, 'shed_guard_threshold': 99})
